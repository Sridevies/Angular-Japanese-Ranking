$(document).ready(function(){
	var pageLoad = '<div class="pageloading"></div>';
	$("body").append(pageLoad)

    new WOW().init();
	
	$(window).scroll(function() {
		var windscroll = $(window).scrollTop();
		if (windscroll > 100) {
			$(".left-nav-fixed").addClass('posfixed');
		} else {
			$(".left-nav-fixed").removeClass('posfixed');
		}

		if (windscroll > 429) {
			$(".left-nav").addClass('submenu-fixed');
		} else {
			$(".left-nav").removeClass('submenu-fixed');
		}
	});

	// Left Fixed menu
	var headerInnerPage = " <div class='container-fluid' style='position:relative;'> <nav class='left-nav-fixed wow fadeInUp'><a href='index.html' title='Home' class='menu-icon home'></a><a href='safety.html' title='Safety' class='menu-icon safety'><div class='tooltip-info'>Safety</div></a><a href='people.html' title='People' class='menu-icon people'><div class='tooltip-info'>people</div></a><a href='scorecard-review.html' title='Quality' class='menu-icon quality'><div class='tooltip-info'>quality</div></a><a href='key-focus-innovation.html' title='Responsiveness' class='menu-icon responsiveness'><div class='tooltip-info'>responsiveness</div></a><a href='cost.html' title='Cost' class='menu-icon cost'><div class='tooltip-info'>cost</div></a><a href='environment.html' title='Environment' class='menu-icon environment'><div class='tooltip-info'>environment</div></a><a href='baltimore-assembly-plant.html' title='Locations' class='menu-icon locations'><div class='tooltip-info'>locations</div></a></nav> <div class='row'> <header class='header'> <nav class='wow fadeInDown menu-btn'> <div class='line'></div> <div class='line'></div> <div class='line'></div> </nav> <div class='wow fadeInDown jll-logo'> <a href='index.html' title='JLL'> <img src='images/home/Jll-Logo.png' width='94' height='40' border='0' alt='JLL'/> </a> </div> </header> </div> <div class='row'> <section class='banner-cont'> <h1 class='wow fadeInUp'>2016 Annual Report</h1> </section> </div> </div>";
	$( ".smallbanner" ).append(headerInnerPage);
	
	$(".left-nav-fixed a").hover(function(){
		//$(this).find(".tooltip-info").stop().animate({"opacity":"1","margin-left":"0px"});
		$(this).find(".tooltip-info").stop().fadeIn();
	},function(){
		//$(".tooltip-info").stop().animate({"opacity":"0","margin-left":"-50px"}); 
		$(".tooltip-info").stop().fadeOut(); 
	});
	
	var MainMenu = "<h2>GM Annual Report 2016</h2> <div class='breadcrumbs'> <span id='AllMenu' class='subMenu0 MenuPrev1'>ALL</span><span class='subMenu1 MenuPrev2'></span><span class='subMenu2'></span> </div> <div class='inner-cont'><div class='menu1-box'><ul class='menu1'><li> <a class='safety' href='safety.html' title='Safety'>Safety</a> </li><li> <a class='people' href='people.html' title='People'>People</a> </li><li> <a class='quality subnav1' rel='#QualityMenu1' href='javascript:;' title='Quality'>Quality <span class='dot'><img src='images/left-nav/3dots.png' width='25' height='5' border='0' alt=''></span> </a> </li><li> <a class='responsiveness subnav1' rel='#ResponsivenessMenu1' href='javascript:;' title='Responsiveness'>Responsiveness <span class='dot'><img src='images/left-nav/3dots.png' width='25' height='5' border='0' alt=''></span> </a> </li><li> <a class='cost subnav1' rel='#CostMenu1' href='javascript:;' title='Cost'>Cost<span class='dot'><img src='images/left-nav/3dots.png' width='25' height='5' border='0' alt=''></span></a> </li><li> <a class='environment' href='environment.html' title='Environment'>Environment</a> </li><li> <a class='locations subnav1' rel='#LocationsMenu1' href='javascript:;' title='Locations'>Locations <span class='dot'><img src='images/left-nav/3dots.png' width='25' height='5' border='0' alt=''></span> </a> </li></ul></div><div class='menu2-box'><ul class='menu1' id='QualityMenu1'><li> <a href='scorecard-review.html' title='Scorecard Review'>Scorecard Review</a> </li><li> <a href='work-order-management.html' title='Work Order Management'>Work Order Management</a> </li><li> <a href='strategic-sourcing.html' title='Strategic Sourcing'>Strategic Sourcing</a> </li></ul><ul class='menu1' id='ResponsivenessMenu1'><li> <a href='key-focus-innovation.html' title='Key Focus Innovation'>Key Focus Innovation</a> </li><li> <a href='partnership.html' title='Partnership'>Partnership</a> </li></ul><ul class='menu1' id='CostMenu1'><li> <a href='cost.html' title='Cost'>Cost</a> </li><li> <a href='value-added.html' title='Value Added'>Value Added</a> </li></ul><ul class='menu1' id='LocationsMenu1'><li> <a class='subnav2' rel='#LocationsManufacturing' href='javascript:;' title='Manufacturing'>Manufacturing <span class='dot'><img src='images/left-nav/3dots.png' width='25' height='5' border='0' alt=''></span> </a> </li><li> <a class='subnav2' rel='#LocationsNonManufacturing' href='javascript:;' title='Non Manufacturing'>Non Manufacturing <span class='dot'><img src='images/left-nav/3dots.png' width='25' height='5' border='0' alt=''></span> </a> </li></ul></div><div class='menu3-box'><ul class='menu1' id='LocationsManufacturing'><li> <a href='baltimore-assembly-plant.html' title='Baltimore'>Baltimore</a> </li><li> <a href='brownstown-battery-assembly-plant.html' title='Brownstone Battery'>Brownstone Battery</a> </li><li> <a href='lansing-delta-township-assembly-plant.html' title='Lansing LDT'>Lansing LDT</a> </li><li> <a href='lansing-grand-river-assembly-plant.html' title='Lansing LGR'>Lansing LGR</a> </li><li> <a href='orion-assembly-plant.html' title='Orion Assembly'>Orion Assembly</a> </li><li> <a href='pontiac-stamping-plant.html' title='Pontiac Stamping'>Pontiac Stamping</a> </li><li> <a href='powertrain-romulus-engine-plant.html' title='Romulus'>Romulus</a> </li><li> <a href='warren-transmission.html' title='Warren'>Warren</a> </li><li> <a href='wentzville-assembly-plant.html' title='Wentzville'>Wentzville</a> </li></ul><ul class='menu1' id='LocationsNonManufacturing'><li> <a href='customer-care-and-aftersales.html' title='CCA'>CCA</a> </li><li> <a class='addCCAMenu' href='additional-cca-projects.html' title='Additional CCA projects'>Additional CCA projects</a> </li><li> <a href='pontiac-engineering-center.html' title='PEC'>PEC</a> </li><li> <a href='regional-facilities-operations.html' title='RFO'>RFO</a> </li><li> <a href='facilities-service-center.html' title='FSC'>FSC</a> </li></ul></div> </div>"
	$(".nav-box").append(MainMenu);

	$('.subMenu0').css({'color':'#000','cursor':'default'});
	$(".menu-btn").click(function(){
		$(".nav-box").addClass("moveRight");
		$(".menu-bg-overlay").fadeIn();
		setTimeout(function(){ 
			$(".menu1-box").addClass("menu1Open"); 
			menuAnimationLeftToRight();
			//$('.MenuPrev1').text("");
		},500);
	});
	$(".menu-bg-overlay").click(function(){ 
		menuAnimationRightToLeft()
		setTimeout(function(){ 
			$(".menu2-box ul,.menu3-box ul").hide(); 
			$(".subMenu1").text("");
			$(".subMenu2").text("");
			$(".subMenu1").fadeOut(); 
			$(".subMenu2").fadeOut();
		},1200)
		setTimeout(function(){ 
			$(".menu3-box").removeClass("menu3Open");
			$(".menu2-box").removeClass("menu2Open");
			$(".menu1-box").removeClass("menu1Open"); 
			$(".nav-box").removeClass("moveRight");
			$(".menu-bg-overlay").fadeOut();
		},500)
	});

	$(".nav-box ul.menu1 a.subnav1").click(function(){
		$(".menu2-box ul").hide(); 
		menuAnimationRightToLeft()
		//setTimeout(function(){ 
			//menuAnimationRightToLeft()
		//},500);
		setTimeout(function(){ 
			$(".menu1-box").removeClass("menu1Open");
		},500);
		setTimeout(function(){ 
			$(".menu2-box").addClass("menu2Open");
		},600);
		setTimeout(function(){ 
			menuAnimationLeftToRight();
		},700);
		var menuId = $(this).attr("rel");
		$(menuId).show();
		//----------------
		var subMenu1Text = $(this).text();
		$(".subMenu1").text(subMenu1Text);
		$(".subMenu1").fadeIn();
		$('.subMenu0').css({'color':'#ED700A','cursor':'pointer'});
		$('.subMenu1').css({'color':'#000','cursor':'default'});
	});
	
	$(".breadcrumbs .MenuPrev1").click(function(){ 
		$('.subMenu0').css({'color':'#000','cursor':'default'});
		if($(".breadcrumbs span:visible").length > 1){
			menuAnimationRightToLeft()
			setTimeout(function(){ 
				$(".menu3-box").removeClass("menu3Open");
				$(".menu2-box").removeClass("menu2Open"); 
				$(".subMenu1").fadeOut(); 
				$(".subMenu2").fadeOut();
			},500); 
			setTimeout(function(){ 
				$(".menu1-box").addClass("menu1Open");
			},1000); 
			setTimeout(function(){ 
				menuAnimationLeftToRight()
			},1200); 
		}
	});

	$(".breadcrumbs .MenuPrev2").click(function(){ 
		if($(".breadcrumbs span:visible").length > 2){
			$('.subMenu0').css({'color':'#ED700A','cursor':'pointer'});
			$('.subMenu1').css({'color':'#000','cursor':'default'});
			menuAnimationRightToLeft()
			setTimeout(function(){ 
				$(".menu3-box").removeClass("menu3Open");
				$(".menu1-box").removeClass("menu1Open");
				$(".subMenu2").fadeOut();
			},500); 
			setTimeout(function(){ 
				$(".menu2-box").addClass("menu2Open");
			},1000);
			setTimeout(function(){ 
				menuAnimationLeftToRight()
			},1200);  
		}
	});
	$(".nav-box ul.menu1 a.subnav2").click(function(){
		$(".menu3-box ul").hide(); 
		menuAnimationRightToLeft()
		setTimeout(function(){ 
			$(".menu1-box").removeClass("menu1Open");
			$(".menu2-box").removeClass("menu2Open"); 
		},500);
		setTimeout(function(){ 
			$(".menu3-box").addClass("menu3Open"); 
		},600);
		setTimeout(function(){ 
			menuAnimationLeftToRight();
		},700); 
		var menuId = $(this).attr("rel");
		$(menuId).show();
		//alert(menuId); 
		var subMenu2Text = $(this).text();
		$(".subMenu2").text(subMenu2Text);
		$(".subMenu2").fadeIn();
		$('.subMenu0,.subMenu1').css({'color':'#ED700A','cursor':'pointer'});
		$('.subMenu2').css({'color':'#000','cursor':'default'});
	});

	function menuAnimationLeftToRight(){
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(0)").animate({"margin-left":"0"})},200);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(1)").animate({"margin-left":"0"})},300);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(2)").animate({"margin-left":"0"})},400);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(3)").animate({"margin-left":"0"})},500);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(4)").animate({"margin-left":"0"})},600);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(5)").animate({"margin-left":"0"})},700);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(6)").animate({"margin-left":"0"})},800);
		//2
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(7)").animate({"margin-left":"0"})},200);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(8)").animate({"margin-left":"0"})},300);	
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(9)").animate({"margin-left":"0"})},400);	
		//3
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(10)").animate({"margin-left":"0"})},200);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(11)").animate({"margin-left":"0"})},300);
		//4
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(12)").animate({"margin-left":"0"})},200);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(13)").animate({"margin-left":"0"})},300);
		//5		
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(14)").animate({"margin-left":"0"})},200);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(15)").animate({"margin-left":"0"})},300);
		//6		
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(16)").animate({"margin-left":"0"})},200);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(17)").animate({"margin-left":"0"})},300);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(18)").animate({"margin-left":"0"})},400);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(19)").animate({"margin-left":"0"})},500);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(20)").animate({"margin-left":"0"})},600);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(21)").animate({"margin-left":"0"})},700);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(22)").animate({"margin-left":"0"})},800);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(23)").animate({"margin-left":"0"})},900);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(24)").animate({"margin-left":"0"})},1000);
		//7
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(25)").animate({"margin-left":"0"})},200);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(26)").animate({"margin-left":"0"})},300);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(27)").animate({"margin-left":"0"})},400);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(28)").animate({"margin-left":"0"})},500);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(29)").animate({"margin-left":"0"})},600);
	}
	function menuAnimationRightToLeft(){
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(0)").animate({"margin-left":"-150px"})},200);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(1)").animate({"margin-left":"-150px"})},300);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(2)").animate({"margin-left":"-150px"})},400);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(3)").animate({"margin-left":"-150px"})},500);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(4)").animate({"margin-left":"-150px"})},600);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(5)").animate({"margin-left":"-150px"})},700);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(6)").animate({"margin-left":"-150px"})},800);
		//2
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(7)").animate({"margin-left":"-150px"})},200);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(8)").animate({"margin-left":"-150px"})},300);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(9)").animate({"margin-left":"-150px"})},400);
		//3		
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(10)").animate({"margin-left":"-150px"})},200);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(11)").animate({"margin-left":"-150px"})},300);
		//4
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(12)").animate({"margin-left":"-150px"})},200);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(13)").animate({"margin-left":"-150px"})},300);
		//5		
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(14)").animate({"margin-left":"-150px"})},200);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(15)").animate({"margin-left":"-150px"})},300);
		//6		
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(16)").animate({"margin-left":"-150px"})},200);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(17)").animate({"margin-left":"-150px"})},300);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(18)").animate({"margin-left":"-150px"})},400);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(19)").animate({"margin-left":"-150px"})},500);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(20)").animate({"margin-left":"-150px"})},600);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(21)").animate({"margin-left":"-150px"})},700);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(22)").animate({"margin-left":"-150px"})},800);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(23)").animate({"margin-left":"-150px"})},900);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(24)").animate({"margin-left":"-150px"})},1000);
		//6
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(25)").animate({"margin-left":"-150px"})},200);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(26)").animate({"margin-left":"-150px"})},300);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(27)").animate({"margin-left":"-150px"})},400);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(28)").animate({"margin-left":"-150px"})},500);
		setTimeout(function(){$(".nav-box ul.menu1 li:eq(29)").animate({"margin-left":"-150px"})},600);
	}
	
	var LocationLeftNav = " <li><a class='toggleOpen wow fadeInUp' href='javascript:;'  title='Manufacturing'>Manufacturing</a><ul class='toggleCont location-submenu wow fadeInUp'><li><a href='baltimore-assembly-plant.html' title='Baltimore'>Baltimore</a></li><li><a href='brownstown-battery-assembly-plant.html' title='Brownstone Battery'>Brownstone Battery</a></li><li><a href='lansing-delta-township-assembly-plant.html' title='Lansing LDT'>Lansing LDT</a></li><li><a href='lansing-grand-river-assembly-plant.html' title='Lansing LGR'>Lansing LGR</a></li><li><a href='orion-assembly-plant.html' title='Orion Assembly'>Orion Assembly</a></li><li><a href='pontiac-stamping-plant.html' title='Pontiac Stamping'>Pontiac Stamping</a></li><li><a href='powertrain-romulus-engine-plant.html' title='Romulus'>Romulus</a></li><li><a href='warren-transmission.html' title='Warren'>Warren</a></li><li><a href='wentzville-assembly-plant.html' title='Wentzville'>Wentzville</a></li></ul></li> <li><a class='toggleOpen wow fadeInUp' href='javascript:;' title='Non-Manufacturing'>Non-Manufacturing</a><ul class='toggleCont location-submenu wow fadeInUp'><li><a href='customer-care-and-aftersales.html' title='CCA'>CCA</a></li><li style='padding:0 0 10px;'><a href='additional-cca-projects.html' title='Additional CCA projects'>&nbsp; &nbsp;  Additional CCA projects</a></li><li><a href='pontiac-engineering-center.html' title='PEC'>PEC</a></li><li><a href='regional-facilities-operations.html' title='RFO'>RFO</a></li><li><a href='facilities-service-center.html' title='FSC'>FSC</a></li></ul></li>"
	$("#location-left-Nav").append(LocationLeftNav);
	
	$('.left-nav .toggleOpen').click(function(e) {
		e.preventDefault();
		var $this = $(this);
		if ($this.next().hasClass('showContent')) {
			$this.next().removeClass('showContent');
			$this.next().slideUp(350);
		} else {
			$this.parent().parent().find('li .toggleCont').removeClass('showContent');
			$this.parent().parent().find('li .toggleCont').slideUp(350);
			$this.next().toggleClass('showContent');
			$this.next().slideToggle(350);
		}
		setTimeout(function(){ 
			$(".left-nav .toggleOpen").removeClass("selected-Menu");
			$(".showContent:visible").prev(".toggleOpen").addClass("selected-Menu");
		},100)
	});
	
	var footerText = "&copy; Copyright 2017 Jones Lang LaSalle, IP, Inc."; 
	$(".footer-text" ).html(footerText);
	
	// For Fixed left Nav menu active
	//var url = $(location).attr('href').split("/").splice(6, 7).join("/"); // FOR LOCAL

	var url = $(location).attr('href').split("/").splice(5, 6).join("/");  // FOR LOCAL STAGING
	if(url == 'safety.html'){
		$(".left-nav-fixed a:eq(1)").addClass("active");	
	}else if(url == 'people.html'){
		$(".left-nav-fixed a:eq(2)").addClass("active");
	}else if(url == 'scorecard-review.html' | url == 'work-order-management.html' | url == 'strategic-sourcing.html'){
		$(".left-nav-fixed a:eq(3)").addClass("active");
	}else if(url == 'key-focus-innovation.html'| url == 'partnership.html'){
		$(".left-nav-fixed a:eq(4)").addClass("active");
	}else if(url == 'cost.html' | url == 'value-added.html'){
		$(".left-nav-fixed a:eq(5)").addClass("active");
	}else if(url == 'environment.html'){
		$(".left-nav-fixed a:eq(6)").addClass("active");
	}else if(
		url == 'baltimore-assembly-plant.html' | 
		url == 'brownstown-battery-assembly-plant.html' | 
		url == 'lansing-delta-township-assembly-plant.html' |
		url == 'lansing-grand-river-assembly-plant.html' |
		url == 'orion-assembly-plant.html' |
		url == 'pontiac-stamping-plant.html' |
		url == 'powertrain-romulus-engine-plant.html' |
		url == 'warren-transmission.html' |
		url == 'wentzville-assembly-plant.html' |
		url == 'customer-care-and-aftersales.html' |
		url == 'additional-cca-projects.html' |
		url == 'pontiac-engineering-center.html' |
		url == 'regional-facilities-operations.html' |
		url == 'facilities-service-center.html'
	){
		$(".left-nav-fixed a:eq(7)").addClass("active");
	}

	// For location left nav active
	if(url == 'baltimore-assembly-plant.html'){
		$("#location-left-Nav a:eq(0)").trigger("click");
		$("#location-left-Nav a:eq(1)").addClass("active");
	}
	else if(url == 'brownstown-battery-assembly-plant.html'){
		$("#location-left-Nav a:eq(0)").trigger("click");
		$("#location-left-Nav a:eq(2)").addClass("active");
	}
	else if(url == 'lansing-delta-township-assembly-plant.html'){
		$("#location-left-Nav a:eq(0)").trigger("click");
		$("#location-left-Nav a:eq(3)").addClass("active");
	}
	else if(url == 'lansing-grand-river-assembly-plant.html'){
		$("#location-left-Nav a:eq(0)").trigger("click");
		$("#location-left-Nav a:eq(4)").addClass("active");
	}
	else if(url == 'orion-assembly-plant.html'){
		$("#location-left-Nav a:eq(0)").trigger("click");
		$("#location-left-Nav a:eq(5)").addClass("active");
	}	
	else if(url == 'pontiac-stamping-plant.html'){
		$("#location-left-Nav a:eq(0)").trigger("click");
		$("#location-left-Nav a:eq(6)").addClass("active");
	}
	else if(url == 'powertrain-romulus-engine-plant.html'){
		$("#location-left-Nav a:eq(0)").trigger("click");
		$("#location-left-Nav a:eq(7)").addClass("active");
	}
	else if(url == 'warren-transmission.html'){
		$("#location-left-Nav a:eq(0)").trigger("click");
		$("#location-left-Nav a:eq(8)").addClass("active");
	}
	else if(url == 'wentzville-assembly-plant.html'){
		$("#location-left-Nav a:eq(0)").trigger("click");
		$("#location-left-Nav a:eq(9)").addClass("active");
	} 
	else if(url == 'customer-care-and-aftersales.html'){
		$("#location-left-Nav a:eq(10)").trigger("click");
		$("#location-left-Nav a:eq(11)").addClass("active");
	}
	else if(url == 'additional-cca-projects.html'){
		$("#location-left-Nav a:eq(10)").trigger("click");
		$("#location-left-Nav a:eq(11)").addClass("active");
		$("#location-left-Nav a:eq(12)").addClass("active");
	}
	else if(url == 'pontiac-engineering-center.html'){
		$("#location-left-Nav a:eq(10)").trigger("click");
		$("#location-left-Nav a:eq(13)").addClass("active");
	}
	else if(url == 'regional-facilities-operations.html'){
		$("#location-left-Nav a:eq(10)").trigger("click");
		$("#location-left-Nav a:eq(14)").addClass("active");
	}
	else if(url == 'facilities-service-center.html'){
		$("#location-left-Nav a:eq(10)").trigger("click");
		$("#location-left-Nav a:eq(15)").addClass("active");
	}
});
$(window).load(function() {	
	$(".pageloading").fadeOut();
	setTimeout(function(){
		new WOW().init();
	},100);
});
