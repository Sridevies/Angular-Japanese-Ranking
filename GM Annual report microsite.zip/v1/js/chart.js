$(document).ready(function(){
	// Safety chart1 
	Highcharts.chart('safetyChartOne', {
		chart: {
			plotBackgroundColor: null,
			plotBorderWidth: null,
			plotShadow: false,
			type: 'pie', 
			height:300
		},
		title: {
			text: ''
		},
		exporting: { enabled: false },
		credits: {
			enabled: false
		},
		tooltip: {
			enabled: true ,
			formatter: function () {
				return '<b>' +this.point.name + ' : </b>' + this.y ;
			}
		},
		plotOptions: {
			pie: {
				allowPointSelect: true,
				cursor: 'pointer',
				dataLabels: {
					enabled: false,
					format: '<b>{series.name}</b>: this.y',
					style: {
						color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
					}
				}
			}
		},
		series: [{
			name: 'Brands',
			colorByPoint: true,
			data: [  {
				name: 'CCA',
				y: 1,
				color:'#602277'
			},{
				name: 'LDT',
				y: 1,
				color:'#9A0549'
			},{
				name: 'Orion',
				y: 1,color:'#ED6F09'
				
			},{
				name: 'PEC',
				y: 4,color:'#7E7E7E'
			}, {
				name: 'RFO',
				y: 3,color:'#B1B1B1'
			}, {
				name: 'Warren',
				y: 4,color:'#DBD5C7'
			},
			{
				name: 'Wentzville',
				y: 14,
				color:'#7974b6'
			}]
		}]
	});
	// Safety chart2 
	Highcharts.chart('safetyChartTwo', {
		chart: {
			plotBackgroundColor: null,
			plotBorderWidth: null,
			plotShadow: false,
			type: 'pie', 
			height:300
		},
		title: {
			text: ''
		},
		exporting: { enabled: false },
		credits: {
			enabled: false
		},
		tooltip: {
			enabled: true ,
			formatter: function () {
				return '<b>' +this.point.name + ' : </b>' + this.y ;
			}
		},
		plotOptions: {
			pie: {
				allowPointSelect: true,
				cursor: 'pointer',
				dataLabels: {
					enabled: false,
					format: '<b>{series.name}</b>: this.y',
					style: {
						color: (Highcharts.theme && Highcharts.theme.contrastTextColor) || 'black'
					}
				}
			}
		},
		series: [{
			name: 'Brands',
			colorByPoint: true,
			data: [  {
				name: 'Warren',
				y: 17,color:'#7874B5'
				/*sliced: true,
				selected: true*/
			},{
				name: 'CCA',
				y: 15,
				color:'#602376'
			},{
				name: 'Wentzville',
				y: 15,color:'#9A054A'
				
			},{
				name: 'RFO',
				y: 9,color:'#ED700A'
			}, {
				name: 'PEC',
				y: 8,color:'#7F7F7F'
			}, {
				name: 'LDT',
				y: 7,color:'#B0B1B3'
			},
			{
				name: 'Baltimore',
				y: 6,
				color:'#D8D8D9'
			},
			{
				name: 'Orion',
				y: 6,
				color:'#E8E5DD'
			},
			{
				name: 'MSC',
				y: 3,
				color:'#CC82A4'
			},
			{
				name: 'Other',
				y: 12,
				color:'#AF91BA'
			}]
		}]
	});

	// Quality - Scorecard Review chart1
	Highcharts.chart('container1', {
		title: {
			text: 'GM Portfolio Scorecard Monthly Trend'
		},
		xAxis: {
			categories: ['42384', '42415', '42445', '42476', '42506', '42537', '42567', '42583', '42614', '42644', '42675', '42720']
		},
		yAxis:[{ // Primary yAxis
					labels: {
						format: '{value}',
						style: {
							color: '#89A54E'
						}
					},
					title: {
						text: '',
						style: {
							color: '#89A54E'
						}
					}
				}, { // Secondary yAxis
					min: 0,
					max: 100,
					title: {
						text: '',
						style: {
							color: '#4572A7'
						}
					},
					labels: {
						format: '{value}%',
						style: {
							color: '#4572A7'
						}
					},
					opposite: true
				}],
		credits: {
			enabled: false
		},
	   
		exporting: { enabled: false },
		series: [{
			type: 'column',
			name: 'Green',
			data: [326, 293, 285, 305, 321, 299, 253, 334, 300, 311, 309, 342],
			color:'green'
		}, {
			type: 'column',
			name: 'Red',
			data: [10, 11, 11, 15, 15, 13, 19, 18, 20, 9, 11, 10],
			color:'red'
		}, {
			type: 'spline',
			name: 'Green',
			yAxis: 1,
			color:'green',
			data: [97.0, 96.4, 96.3, 95.3, 95.5, 96.0, 93.0, 94.9, 93.8, 97.2, 96.6, 97.2],
			marker: {
				lineWidth: 2,
				lineColor: Highcharts.getOptions().colors[3],
				fillColor: 'green'
			}
		}, {
			type: 'spline',
			name: 'Red',
			yAxis: 1,
			color:'red',
			data: [3.0, 3.6, 3.7, 4.7, 4.5, 4.0, 7.0, 5.1, 6.3, 2.8, 3.4, 2.8],
			marker: {
				lineWidth: 2,
				lineColor: Highcharts.getOptions().colors[3],
				fillColor: 'red'
			}
		}
		
		]
	});
});