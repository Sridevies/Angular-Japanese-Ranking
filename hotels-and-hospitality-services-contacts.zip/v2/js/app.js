(function(){
"use strict";
var AngApp = angular.module('hotelContact',[]);

AngApp.directive('filterList', function($timeout) {
    return {
        link: function(scope, element, attrs) {
			
            var li = Array.prototype.slice.call(element[0].children);
			
            function filterBy(value) {
				if(value!='Select Option'){
					li.forEach(function(el) {
						el.className = el.textContent.toLowerCase().indexOf(value.toLowerCase()) !== -1 ? '' : 'topList ng-hide';
					});
				}
				else{
					li.forEach(function(el) {
						el.className = el.textContent.toLowerCase().indexOf(value.toLowerCase()) !== -1 ? '' : 'topList ng-show';
					});
				}
            }

            scope.$watch(attrs.filterList, function(newVal, oldVal) {
                if (newVal !== oldVal) {
					 filterBy(newVal);
                }
            });
        }
    };
});

AngApp.factory('factoryList',function(){
	var facList ={};
	facList.service = ['Select Option','Strategic Advisory','Valuation Advisory','Operator Selection','Asset Management','Technology Support Services','F&B Consultancy','Buy-Side Advisory','Debt Advisory','Investment Sales','Mergers & Acquisitions','Project & Development Services','Research'];
	return facList;
});

AngApp.controller('hotelConController',function($scope, factoryList){
	alert("hi");
	$scope.selectList = factoryList.service;

	console.log($scope.selectList)

	$('.team_lister li').mouseover(function(){
		$(this).find('.address_bar').stop().animate({bottom: '-110px'}, 500, function(){
			$(this).next().stop().animate({left: '0'}, 300);
		});
	});
	$('.team_lister li').mouseout(function(){
		$(this).find('.address_bar').stop().animate({bottom: '0'}, 500, function(){
			$(this).next().stop().animate({left: '100%'})
		});
	});

	$scope.selectService = function(){

		 var selectLists = document.querySelectorAll(".selectService");
        for(var x = 0;x  < selectLists.length; x++){
            selectLists[x].parentNode.insertBefore(selectLists[x], selectLists[x]);
        }      

		$('.team_lister li').hide(500);
		if($('.team_lister li:not(.topList)')){
			$('.team_lister li').show(500);
		}
		//$scope.$apply();
	}
	
	

});
angular.element(document).ready(function () {
	console.log("loaded");
    angular.bootstrap(document, ['hotelContact']);
});

})();
