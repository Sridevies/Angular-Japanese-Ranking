var result = false;

function popup(url) {
    url = "../../social/inh-fb-disclaimer.htm"
    newwindow = window.open(url, 'name', 'height=392,width=667');
    if (window.focus) {
        newwindow.focus()
    }
    return false;
}
$(document).ready(function() {
    $(function() {
        var src = "/CMENA-371/v4/uae/data/images/crossbanners/";
        var images = [
            ["xl1.jpg", "Ready to apply? Start the process with just a phone call****Apply now or call toll free on 800 CITIHOME (24844663)", "form.htm", '_self'],
            ["xl2.jpg", "Do you know what documents you need to apply? Mortgage document checklist", "pdf/mortgage_document.pdf", '_blank']
        ];
        var rand = images.sort(function() {
            return 0.5 - Math.random()
        });
        $('#ad1').attr('src', src + rand[0][0]).attr('title', rand[0][1]).attr('alt', rand[0][1]).parent().attr('href', rand[0][2]).attr('target', rand[0][3]);
        $('#ad2').attr('src', src + rand[1][0]).attr('title', rand[1][1]).parent().attr('href', rand[1][2]).attr('target', rand[1][3]);
    });
    $(function() {
        var src = "/CMENA-371/v4/uae/data/images/crossbanners/";
        var images = [
            ["xl3.jpg", "Easy Payment Plan - Buy now, Pay Later", "../../consumer/credit_cards/installment_loan.htm"],
            ["xl4.jpg", "Loan on Phone - Access to a hassle-free loan", "../../consumer/credit_cards/installment_loan.htm"],
            ["xl5.jpg", "Lifestyle Protect - Rest assured, your credit card repayments are covered", "../../consumer/insurance/lifestyle_protect.htm"],
            ["xl6.jpg", "Gourmet pleasures, from Citi.", "../../consumer/credit_cards/dining_offer.htm"],
            ["xl6-a.jpg", "Fulfil your banking needs from anywhere in the world", "../../consumer/reach_us/citibank_online.htm"],
			["xl6-b.jpg", "Bank in your pocket", "../../consumer/reach_us/citi_mobile.htm"],
			["xl6-c.jpg", "Pay your bills at no extra cost", "../../consumer/credit_cards/uti_bill_payment.htm"],
			["xl6-d.jpg", "Apply for Citibank personal loan today", "../../consumer/forms/perinstall_form.htm"]
        ];
        var rand = images.sort(function() {
            return 0.5 - Math.random()
        });
        $('#ad3').attr('src', src + rand[0][0]).attr('title', rand[0][1]).parent().attr('href', rand[0][2]);
        $('#ad4').attr('src', src + rand[1][0]).attr('title', rand[1][1]).parent().attr('href', rand[1][2]);
    });
    $(function() {
        var src = "/CMENA-371/v4/uae/data/images/crossbanners/";
        var images = [
            ["xl7.jpg", "Gourmet pleasures, from Citi.", "../../consumer/credit_cards/dining_offer.htm"],
            ["xl8.jpg", "Your Money... On the Move", "../../consumer/personal_account/fund_transfer.htm"],
            ["xl9.jpg", "Fulfil your banking needs from anywhere in the world", "../../consumer/reach_us/citibank_online.htm"],
            ["xl10.jpg", "Bank in your pocket", "../../consumer/reach_us/citi_mobile.htm"],
            ["xl11.jpg", "Global Markets stocks, Bonds, Mutual Funds. All from your desktop", "../../consumer/investment_treasury/range_of_products.htm"],
			["xl11-a.jpg", "Pay your bills at no extra cost", "../../consumer/credit_cards/uti_bill_payment.htm"]
        ];
        var rand = images.sort(function() {
            return 0.5 - Math.random()
        });
        $('#ad5').attr('src', src + rand[0][0]).attr('title', rand[0][1]).parent().attr('href', rand[0][2]);
        $('#ad6').attr('src', src + rand[1][0]).attr('title', rand[1][1]).parent().attr('href', rand[1][2]);
    });
    $(function() {
        var src = "/CMENA-371/v4/uae/data/images/crossbanners/";
        var images = [
            ["xl12.jpg", "Fulfil your banking needs from anywhere in the world", "../../consumer/reach_us/citibank_online.htm"],
            ["xl13.jpg", "Bank in your pocket", "../../consumer/reach_us/citi_mobile.htm"]
        ];
        var rand = images.sort(function() {
            return 0.5 - Math.random()
        });
        $('#ad7').attr('src', src + rand[0][0]).attr('title', rand[0][1]).parent().attr('href', rand[0][2]);
        $('#ad8').attr('src', src + rand[1][0]).attr('title', rand[1][1]).parent().attr('href', rand[1][2]);
    });
    $(function() {
        var src = "/CMENA-371/v4/uae/data/images/crossbanners/";
        var images = [
            ["xl14.jpg", "Fulfil your banking needs from anywhere in the world", "../../consumer/reach_us/citibank_online.htm?icid=AEMMCG30"],
            ["xl15.jpg", "Bank in your pocket", "../../consumer/reach_us/citi_mobile.htm?icid=AEMMCG31"],
			["xl15-a.jpg", "Your Money... On the Move", "../../consumer/personal_account/fund_transfer.htm?icid=AEMMCR19"],
			["xl15-b.jpg", "Global Markets stocks, Bonds, Mutual Funds & FX linked solutions all from your desktop", "../../consumer/investment_treasury/range_of_products.htm?icid=AEMMCR20"],
			["xl15-c.jpg", "Pay your bills at no extra cost", "../../consumer/credit_cards/uti_bill_payment.htm"]
			["xl15-d.jpg", "Refer a friend for a Citigold Account and get rewarded", "https://www.citibank.com/CMENA-371/v4/uae/consumer/mgm_campaign_for_citigold/form.htm"]
        ];
        var rand = images.sort(function() {
            return 0.5 - Math.random()
        });
        $('#ad9').attr('src', src + rand[0][0]).attr('title', rand[0][1]).parent().attr('href', rand[0][2]);
        $('#ad10').attr('src', src + rand[1][0]).attr('title', rand[1][1]).parent().attr('href', rand[1][2]);
    });
    $(function() {
        var src = "/CMENA-371/v4/uae/data/images/crossbanners/";
        var images = [
            ["xl16.jpg", "Global Markets stocks, Bonds, Mutual Funds. All from your desktop", "../../consumer/investment_treasury/range_of_products.htm"],
            ["xl17.jpg", "Fulfil your banking needs from anywhere in the world", "../../consumer/reach_us/citibank_online.htm"],
            ["xl18.jpg", "FX Order Watch. Valuable service for our global clients", "../../citigold/introduction/fx_order_watch.htm"],
            ["xl19.jpg", "Your Money... On the Move", "../../consumer/personal_account/fund_transfer.htm"],
        ];
        var rand = images.sort(function() {
            return 0.5 - Math.random()
        });
        $('#ad11').attr('src', src + rand[0][0]).attr('title', rand[0][1]).parent().attr('href', rand[0][2]);
        $('#ad12').attr('src', src + rand[1][0]).attr('title', rand[1][1]).parent().attr('href', rand[1][2]);
    });
    $(function() {
        var src = "/CMENA-371/v4/uae/data/images/crossbanners/";
        var images = [
            ["xl20.jpg", "Citi life credit cards - Earn rewards and use for shopping.", "/CMENA-371/v4/uae/consumer/credit_cards/credit_cards_offers.htm?tab=Lifestyle1"],
            ["xl21.jpg", "Citi PremierMiles credit card -  Earn miles and fly with many Airlines.", "/CMENA-371/v4/uae/consumer/credit_cards/credit_cards_offers.htm?tab=Lifestyle"],
			["xl21-a.jpg", "Emirates - Citibank credit cards, Earn miles and fly with Emirates Airlines.", "/CMENA-371/v4/uae/consumer/credit_cards/credit_cards_offers.htm?tab=Travel"]
        ];
        var rand = images.sort(function() {
            return 0.5 - Math.random()
        });
        $('#ad13').attr('src', src + rand[0][0]).attr('title', rand[0][1]).parent().attr('href', rand[0][2]);
        $('#ad14').attr('src', src + rand[1][0]).attr('title', rand[1][1]).parent().attr('href', rand[1][2]);
    });
    setTimeout(function() {
        if ($(window).width() < "1024") {
            $(".follows ul li a").addClass("footerfbicon");
            $(".follows ul li a").removeAttr("onclick");
            $(".follows ul li a").attr("href", "https://www.facebook.com/CitibankUAE");
            $(".follows ul li a").attr("target", "_blank");
            $('.pl9').attr('src', '/CMENA-371/v4/uae/data/images/sign-out-arrow.png');
        }
        $(".double-inner ul").css('margin-bottom', 12)
        $('.jak-more p a').click(function() {
            $("a").toggleClass("jak-open");
        })
        if ($(window).width() <= "600") {
            $(".productsList .productsListDetails ul li ul").css("width", "94%");
        }
        if ($(window).width() == "600") {
            $(".row .fourteen").css("width", "100%");
            $(".row .fourteen").css("margin-right", 0);
            $(".youtube iframe").css("width", 400);
        }
        if ($(window).width() == "768") {
            $("footer .footer-line-top nav").css("width", "85%");
            $('.clsTable td').css("word-wrap", "break-word");
        }
        $('.intro-a').parent().parent().next().find('.box-row-line').css('margin-top', 10)
        var disctablepintro1 = 0;
        $(".intro-a").each(function() {
            disctablepintro1 = disctablepintro1 + 1;
        })
        if (disctablepintro1 > 0) {
            if ($('.intro-a').children().get(0).nodeName.indexOf('P') != -1) {}
        }
    }, 100);
    if (navigator.userAgent.indexOf('SM-T211') != -1) {
        if ($(window).width() == 600) {
            $('.footer-sec-row1 .footer-sec').css('width', '30%')
            $('.footer-sec-row1 .footer-sec').css('float', 'none')
            $('.footer-sec-row1 .footer-sec p').css('margin-bottom', '10px')
            $('.footer-sec-row1').css('padding-bottom', '20px')
        } else {
            $('.footer-sec-row1 .footer-sec').css('width', '30% !important')
            $('.footer-sec-row1 .footer-sec').css('float', 'left')
            $('.footer-sec-row1 .footer-sec p').css('margin-bottom', '0px')
            $('.footer-sec-row1').css('padding-bottom', '0px')
        }
    }
    $(window).bind('orientationchange', function(e) {
        setTimeout(function() {
            if ($(window).width() == 600) {
                $('.footer-sec-row1 .footer-sec').css('width', '30%')
                $('.footer-sec-row1 .footer-sec').css('float', 'none')
                $('.footer-sec-row1 .footer-sec p').css('margin-bottom', '10px')
                $('.footer-sec-row1').css('padding-bottom', '20px')
            } else {
                $('.footer-sec-row1 .footer-sec').css('width', '30%')
                $('.footer-sec-row1 .footer-sec').css('float', 'left')
                $('.footer-sec-row1 .footer-sec p').css('margin-bottom', '0px')
                $('.footer-sec-row1').css('padding-bottom', '0px')
            }
        }, 500)
    })
    if (navigator.userAgent.indexOf('iphone') != -1) {
        if ($(window).width() == 320) {
            $('.footer-sec-row1 .footer-sec').css('width', '100%')
        } else {
            $('.footer-sec-row1 .footer-sec').css('width', '100%')
        }
    }
    $(window).bind('orientationchange', function(e) {
        setTimeout(function() {
            if ($(window).width() == 320) {
                $('.footer-sec-row1 .footer-sec').css('width', '100%')
            } else {
                $('.footer-sec-row1 .footer-sec').css('width', '100%')
            }
        }, 500)
    })
});
var inttabarrow = 0;
var countscrollleft = 0;
var countscrollleft0 = 0;
var countscrollleft1 = 0;
var countscrollleft2 = 0;
var countscrollleft3 = 0;
var countscrollleft4 = 0;
var countscrollleft5 = 0;
var countscrollleft6 = 0;
var countscrollleft7 = 0;
var countscrollleft8 = 0;
var countscrollleft9 = 0;
var countscrollleft10 = 0;
$(document).ready(function() {
    setTimeout(function() {
        $('.footer-sec:eq(0)').removeAttr("height");
        $('.footer-sec:eq(1)').removeAttr("height");
        if ($('.footer-sec:eq(0)').height() < $('.footer-sec:eq(1)').height()) {
            $('.footer-sec:eq(0)').height($('.footer-sec:eq(1)').height())
        } else {
            $('.footer-sec:eq(1)').height($('.footer-sec:eq(0)').height())
        }
    }, 300);
    $(".footer-sec-row .footer-sec:last-child").css("margin-right", 0);
    $(".footer-sec-row .footer-sec:last-child").css("padding-right", 0);
    $(".footer-sec-row .footer-sec:last-child").css("border-right", 0);
    $("#jak_more p:eq(0)").css("margin-top", "10px");
    $('#showhide').click(function() {
        if ($('#jak_more').css('display') == 'none') {
            $('#jak_more').css('display', 'block');
            $('.carrot-hide a').addClass('carrot-arrowdown');
        } else {
            $('#jak_more').css('display', 'none');
            $('.carrot-hide a').removeClass('carrot-arrowdown');
        }
        if (navigator.userAgent.indexOf('SM-T211') != -1) {
            if ($('body').width() <= 600) {
                $('.tab-arw-rit').css({
                    'right': '150px',
                    'position': 'absolute'
                })
            }
        }
    })
    $('.slider-arrow').width($('body').width())
    setTimeout(function() {
        if ($(window).width() == 320) {
            $('.show-hide-cnt .table-arrow').width(242);
        }
        if ($(window).width() == 480) {
            $('.table-arrow').width(412);
            $('.show-hide-cnt .table-arrow').width(382);
        }
    }, 500);
    $(window).bind('orientationchange', function(e) {
        setTimeout(function() {
            $('.footer-sec:eq(0)').removeAttr("height").css("height", "auto");
            $('.footer-sec:eq(1)').removeAttr("height").css("height", "auto");
            if ($('.footer-sec:eq(0)').height() < $('.footer-sec:eq(1)').height()) {
                $('.footer-sec:eq(0)').height($('.footer-sec:eq(1)').height())
            } else {
                $('.footer-sec:eq(1)').height($('.footer-sec:eq(0)').height())
            }
            if (navigator.userAgent.indexOf('SM-T211') != -1) {
                if ($('body').width() <= 600) {
                    $('.tab-arw-rit').css({
                        'right': '150px',
                        'position': 'absolute'
                    })
                }
                if ($('body').width() > 800) {
                    $('.tab-arw-rit').css({
                        'right': '0px',
                        'position': 'absolute'
                    })
                }
            }
            for (var i = 0; i < inttabarrow; i++) {
                if ($(".clsTable:eq(" + i + ")").width() > $(".tableScroll:eq(" + i + ")").width()) {} else {
                    $('.table-arrow:eq(' + i + ') .tab-arw-lft').hide();
                    $('.table-arrow:eq(' + i + ') .tab-arw-rit').hide();
                }
            }
            $('.slider-arrow').width($('body').width())
            $('.table-arrow').width($('.tableScroll').width())
            if ($(window).width() == 320) {
                $('.table-arrow').width(270);
                $('.show-hide-cnt .table-arrow').width(242);
            }
            if ($(window).width() == 480) {
                $('.table-arrow').width(412);
                $('.show-hide-cnt .table-arrow').width(382);
            }
            if (tablet.detect()) {
                $('.ftr-nav').css('top', 0)
                if ($('.ftr-nav').height() > 25) {
                    $('#footerfirstarwdown').show()
                    $('#footerfirstarwup').hide()
                } else {
                    $('#footerfirstarwdown').hide()
                    $('#footerfirstarwup').hide()
                }
            }
        }, 700);
    });
    setTimeout(function() {
        $('#footerfirstarwdown a').click(function() {
            $('.ftr-nav').animate({
                top: parseInt($('.ftr-nav').css('top')) - 25
            });
            if (-parseInt($('.ftr-nav').css('top')) + 50 >= $('.ftr-nav').height()) {
                $('#footerfirstarwup').show();
                $('#footerfirstarwdown').hide();
            }
        })
        $('#footerfirstarwup').click(function() {
            $('.ftr-nav').animate({
                top: parseInt($('.ftr-nav').css('top')) + 25
            });
            if (-parseInt($('.ftr-nav').css('top')) == 25) {
                $('#footerfirstarwdown').show();
                $('#footerfirstarwup').hide();
            }
        })
        if ($('.ftr-nav').height() > 25) {
            $('#footerfirstarwdown').show()
        } else {
            $('#footerfirstarwdown').hide()
            $('#footerfirstarwup').hide()
        }
        $("ul.mMenuList li:last-child").css("border-right", 0);
        $(".double-column-right ul:not(:first-child)").css("margin-top", 14);
        $(".double-column-right ol:not(:first-child)").css("margin-top", 13);
        $(".double-column-right ul:first-child").css("margin-top", 0);
        $(".double-column-right ol:first-child").css("margin-top", 0);
        if ($(".double-column-right p:eq(0)").prev('h3').html() != 'undefined' || $(".double-column-right p:eq(0)").prev('h3').html() != 'null') {}
        $(".double-column-right .clsTable:eq(0)").css("margin-top", 0);
        var productsListDetails = 0
        $(".productsListDetails").each(function() {
            productsListDetails = productsListDetails + 1;
        })
        for (var i = 0; i < productsListDetails; i++) {
            $(".productsListDetails:eq(" + i + ")").each(function() {
                if ($(this).children(':first')[0].nodeName != "P" && $(this).children(':first')[0].nodeName != "H3") {}
                $(".productsListDetails:eq(" + i + ") ul:eq(0)").css('margin-top', 0)
                $(".productsListDetails:eq(" + i + ") ul:eq(0)").css('margin-bottom', 14)
                $(".productsListDetails:eq(" + i + ") h3:eq(0)").css('margin-bottom', 14)
            })
        }
        var tableh31 = 0
        $(".double-column-right").each(function() {
            tableh31 = tableh31 + 1;
        })
        for (var i = 0; i < tableh31; i++) {
            $(".double-column-right:eq(" + i + ") h3").each(function() {
                if (!$(this).prev().hasClass('tableScroll')) {
                    if (!$(".double-column-right:eq(" + i + ")").prev().hasClass('tableScroll')) {
                        $(".double-column-right:eq(" + i + ") h3:eq(0)").css('margin-top', 0)
                    }
                }
            })
        }
        if ($('.control-group:last-child div').next().hasClass('form-button')) {
            $('.control-group:last-child').css('margin-top', 10)
        }
        var disccount = 0;
        $("ul").each(function() {
            disccount = disccount + 1;
        })
        for (var i = 0; i < disccount; i++) {
            $('ul:eq(' + i + ') li').last().css('padding-bottom', '0px')
            $('ul:eq(' + i + ') li').last().css('margin-bottom', '0px')
        }
        var introp = 0;
        $(".intro-a").each(function() {
            introp = introp + 1;
        })
        for (var i = 0; i < introp; i++) {
            $('.intro-a:eq(' + i + ') p').last().css('padding-bottom', '0px')
            $('.intro-a:eq(' + i + ') p').last().css('margin-bottom', '0px')
        }
        var disclimarp = 0;
        $(".disclimar").each(function() {
            disclimarp = disclimarp + 1;
        })
        for (var i = 0; i < disclimarp; i++) {
            $('.disclimar:eq(' + i + ') p').last().css('padding-bottom', '0px')
            $('.disclimar:eq(' + i + ') p').last().css('margin-bottom', '0px')
        }
        var lastrowpad = 0;
        $(".box-row").each(function() {
            lastrowpad = lastrowpad + 1;
        })
        for (var i = 0; i < lastrowpad; i++) {
            $('.box-row:eq(' + i + ') .box').last().css('padding-right', '0px')
            $('.box-row:eq(' + i + ') .box').last().css('margin-right', '0px')
            $('.box-row:eq(' + i + ') .box').last().css('border-right', '0px')
        }
        var box_row = $('.box-row .box').size();
        box_row = box_row - 1;
        $('.box-row .box:eq(' + box_row + ')').addClass('last')
        var rowcol = 0;
        $(".row").each(function() {
            rowcol = rowcol + 1;
        })
        for (var i = 0; i < rowcol; i++) {
            $('.row:eq(' + i + ') .columns').last().addClass('last');
            $('.row:eq(' + i + ') .column').last().addClass('last');
        }
        $(".double-column-right ul:not(:first-child)").css("margin-top", 14);
        $(".double-column-right ol:not(:first-child)").css("margin-top", 13);
        $(".double-column-right ul:first-child").css("margin-top", 0);
        $(".double-column-right ol:first-child").css("margin-top", 0);
        $(".double-column-right p:eq(0)").css("margin-top", 0);
        $("h3").each(function() {
            if ($(this).next().find('a').hasClass('carrot')) {
                $(this).css("margin-bottom", 6);
            }
        })
        if (mobile.detect() && userAgent.indexOf('ipad') == -1) {
            $("p").each(function() {
                if ($(this).find('a').hasClass('carrot')) {
                    $(this).css("margin-top", 10);
                }
            })
        } else if (tablet.detect()) {
            $("p").each(function() {
                if ($(this).find('a').hasClass('carrot')) {
                    $(this).css("margin-top", 8);
                }
            })
        } else {
            $("p").each(function() {
                if ($(this).find('a').hasClass('carrot')) {
                    $(this).css("margin-top", 10);
                }
            })
        }
        $("p").each(function() {
            if ($(this).find('a').hasClass('btn-blu') || $(this).find('a').hasClass('golden-button') || $(this).find('a').hasClass('gray-btn')) {
                $(this).css("margin-top", 15);
            }
        })
        $(".double-column-right .tableScroll .clsTable p a").each(function() {
            if ($(this).hasClass('carrot')) {
                $(this).parent().css("margin-top", 8);
            }
        })
        var distableulpdficon = 0;
        var pdficonfig = "";
        $(".pdf-icon").each(function() {
            distableulpdficon = distableulpdficon + 1;
        })
        for (var i = 0; i < distableulpdficon; i++) {
            pdficonfig = $('.pdf-icon:eq(' + i + ') a:eq(0)').html();
            $('.pdf-icon:eq(' + i + ') a:eq(0)').html('<span>' + pdficonfig + '<img class="pdf-img" src="/CMENA-371/v4/uae/data/images/pdf_01.png" width="20"></span>');
            $('.pdf-icon:eq(' + i + ') a:eq(0)').width($('.pdf-icon:eq(' + i + ') a:eq(0) span').width() + 20);
        }
        var distableul = 0;
        $(".clsTable td").each(function() {
            distableul = distableul + 1;
        })
        for (var i = 0; i < distableul; i++) {
            if ($('.clsTable td:eq(' + i + ') a:eq(0)').hasClass('carrot')) {
                $('.clsTable td:eq(' + i + ') a').last().css('margin-bottom', '3px')
            }
        }
        var disccountol = 0;
        $("ol").each(function() {
            disccountol = disccountol + 1;
        })
        for (var i = 0; i < disccountol; i++) {
            $('ol:eq(' + i + ') li').last().css('padding-bottom', '0px')
            $('ol:eq(' + i + ') li').last().css('margin-bottom', '0px')
        }
        var disctablep = 0;
        $(".double-column-h3").each(function() {
            disctablep = disctablep + 1;
        })
        for (var i = 0; i < disctablep; i++) {
            if ($('.double-column-h3:eq(' + i + ')').children().get(0).nodeName != "H3") {
                $('.double-column-h3:eq(' + i + ') .double-column-left').css('margin-top', 30)
                $('.double-column-h3:eq(' + i + ') .double-column-right').css('margin-top', 30)
            }
        }
        if ($(".content721 ul li:last-child").has("ul")) {
            $(".content721 ul li:last-child ul").css('margin-bottom', 0)
        }
        var lasttablesetd = 0;
        $(".clsTable").each(function() {
            lasttablesetd = lasttablesetd + 1;
        })
        if (lasttablesetd > 1) {
            $(".clsTable").last().css('padding-bottom', '0px')
            $(".clsTable").last().css('margin-bottom', '0px')
        }
        var clstable = 0;
        $(".clsTable").each(function() {
            clstable = clstable + 1;
        })
        if (clstable > 1) {
            $(".clsTable").last().css('padding-bottom', '0px')
            $(".clsTable").last().css('margin-bottom', '0px')
        }
        $(".content-container p").last().css('margin-bottom', '0px')
        $(".content-container p").last().css('padding-bottom', '0px')
        var adjusment;
        var footeridnav = $('#footeridnav ul li').length;
    }, 1000);
});
$(document).ready(function() {
    var rowspanval = 0;
    var tablecount = ($('.tableScroll table').length);
    var tdcolor = 0;
    for (var i = 0; i < tablecount; i++) {
        trcount = $('.tableScroll:eq(' + i + ') table tr').length
        for (var j = 0; j < trcount; j++) {
            rowspanval = 0;
            var tdcount = ($('.tableScroll:eq(' + i + ') table tr:eq(' + j + ') td').length)
            $('.tableScroll:eq(' + i + ') table tr:eq(' + j + ') td').each(function() {
                if (rowspanval == 0) {
                    if ($(this).attr('rowspan') > 0) {
                        $(this).addClass('border-left0')
                    }
                    rowspanval = rowspanval + 1;
                } else {
                    $(this).addClass('border-left')
                }
            })
            tdcount = tdcount - 1;
            $('.tableScroll:eq(' + i + ') table tr:eq(' + j + ') td:eq(' + tdcount + ')').addClass('clsTableTD-last')
            $('.tableScroll:eq(' + i + ') table tr:eq(' + j + ') th:eq(' + tdcount + ')').addClass('clsTableTD-last')
            if (j % 2 == 0) {
                $('.tableScroll:eq(' + i + ') table tr:eq(' + j + ')').addClass('tgrey')
            } else {
                $('.tableScroll:eq(' + i + ') table tr:eq(' + j + ')').addClass('tdwhite')
            }
        }
    }
})
$(function() {
    if (navigator.userAgent.indexOf('iPad') != -1) {
        if ($(window).width() == "1024") {
            $('.slider-text-container').width('550px')
            $('.banner').height('310px');
            var productbannerh2 = $('.banner h1').height();
            var productbannerp = $('.banner p').height();
            var temp = productbannerh2 + productbannerp;
            var heighth2 = $('.banner').height() - temp;
            var bottomh2 = heighth2 / 2;
            var bottomph1 = $('.banner').height() / 2;
            if ($('.banner').hasClass('citi-gold-select-banner')) {
                $('.banner h1').css("bottom", bottomph1 + 8.5);
                $('.banner p').css("top", bottomph1 + 8.5);
                $('.banner h1,.banner p').css('left', 450);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -157);
                $('.citi-gold-select-banner p').css('top', 169);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 433);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 387);
                $('.half-gold-banner').css('bottom', 27);
                $('.half-gold-banner').css('left', 20);
                $('.half-gold-banner').css('width', 396);
                $('.double-column-left').css('width', '19%');
                $('.double-column-right').css('width', '78%');
            } else if ($('.banner').hasClass('citi-gold-banner')) {
                $('.banner h1').css("bottom", '49%');
                $('.banner p').css("top", bottomph1 + 12.5);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -157);
                $('.citi-gold-select-banner p').css('top', 169);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 433);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 387);
                $('.half-gold-banner').css('bottom', 27);
                $('.half-gold-banner').css('left', 20);
                $('.half-gold-banner').css('width', 396);
                $('.double-column-left').css('width', '19%');
                $('.double-column-right').css('width', '78%');
            } else {
                $('.banner h1').css("bottom", bottomph1 + 8);
                $('.banner p').css("top", bottomph1 + 8);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -157);
                $('.citi-gold-select-banner p').css('top', 169);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 433);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 387);
                $('.half-gold-banner').css('bottom', 27);
                $('.half-gold-banner').css('left', 20);
                $('.half-gold-banner').css('width', 396);
                $('.double-column-left').css('width', '19%');
                $('.double-column-right').css('width', '78%');
            }
            $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -155);
            $('.citi-gold-select-banner p').css('top', 162);
            $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 26);
        }
        if ($(window).width() == "768") {
            $('.slider-text-container').width('430px')
            $('.banner').height('227px');
            var productbannerh2 = $('.banner h1').height();
            var productbannerp = $('.banner p').height();
            var temp = productbannerh2 + productbannerp;
            var heighth2 = $('.banner').height() - temp;
            var bottomh2 = heighth2 / 2;
            var bottomph1 = $('.banner').height() / 2;
            if ($('.banner').hasClass('citi-gold-select-banner')) {
                $('.banner h1').css("bottom", bottomph1 + 8.5);
                $('.banner p').css("top", bottomph1 + 8.5);
                $('.banner h1,.banner p').css('left', 330);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -118);
                $('.citi-gold-select-banner p').css('top', 129);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 325);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 387);
                $('.half-gold-banner').css('bottom', 20);
                $('.half-gold-banner').css('left', 20);
                $('.half-gold-banner').css('width', 296);
                $('.double-column-left').css('width', '25%');
                $('.double-column-right').css('width', '70%');
            } else if ($('.banner').hasClass('citi-gold-banner')) {
                $('.banner h1').css("bottom", '49%');
                $('.banner p').css("top", bottomph1 + 12.5);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -96);
                $('.citi-gold-select-banner p').css('top', 141);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 325);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 387);
                $('.half-gold-banner').css('bottom', 20);
                $('.half-gold-banner').css('left', 20);
                $('.half-gold-banner').css('width', 296);
                $('.double-column-left').css('width', '25%');
                $('.double-column-right').css('width', '70%');
            } else {
                $('.banner h1').css("bottom", bottomph1 + 8);
                $('.banner p').css("top", bottomph1 + 8);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -96);
                $('.citi-gold-select-banner p').css('top', 141);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 325);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 387);
                $('.half-gold-banner').css('bottom', 20);
                $('.half-gold-banner').css('left', 20);
                $('.half-gold-banner').css('width', 296);
                $('.double-column-left').css('width', '25%');
                $('.double-column-right').css('width', '70%');
            }
            $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 26);
            $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -118);
            $('.citi-gold-select-banner p').css('top', 129);
        }
    }
    if (navigator.userAgent.indexOf('SM-T211') != -1) {
        if ($(window).width() == "1024") {
            $(".footer-sec-row .footer-sec:last-child").css("width", "48%");
            $('.slider-text-container').width('550px')
            $('.banner').height('300px');
            var productbannerh2 = $('.banner h1').height();
            var productbannerp = $('.banner p').height();
            var temp = productbannerh2 + productbannerp;
            var heighth2 = $('.banner').height() - temp;
            var bottomh2 = heighth2 / 2;
            var bottomph1 = $('.banner').height() / 2;
            if ($('.banner').hasClass('citi-gold-select-banner')) {
                $('.banner h1').css("bottom", bottomph1 + 8.5);
                $('.banner p').css("top", bottomph1 + 8.5);
                $('.banner h1,.banner p').css('left', 330)
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -137);
                $('.citi-gold-select-banner p').css('top', 182);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 433);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 387);
                $('.half-gold-banner').css('bottom', 27);
                $('.half-gold-banner').css('left', 20);
                $('.half-gold-banner').css('width', 396);
                $('.double-column-left').css('width', '19%');
                $('.double-column-right').css('width', '78%');
            } else if ($('.banner').hasClass('citi-gold-banner')) {
                $('.banner h1').css("bottom", '49%');
                $('.banner p').css("top", bottomph1 + 12.5);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -137);
                $('.citi-gold-select-banner p').css('top', 182);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 433);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 387);
                $('.half-gold-banner').css('bottom', 27);
                $('.half-gold-banner').css('left', 20);
                $('.half-gold-banner').css('width', 396);
                $('.double-column-left').css('width', '19%');
                $('.double-column-right').css('width', '78%');
            } else {
                $('.banner h1').css("bottom", bottomph1 + 8);
                $('.banner p').css("top", bottomph1 + 8);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -137);
                $('.citi-gold-select-banner p').css('top', 182);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 433);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 387);
                $('.half-gold-banner').css('bottom', 27);
                $('.half-gold-banner').css('left', 20);
                $('.half-gold-banner').css('width', 396);
                $('.double-column-left').css('width', '19%');
                $('.double-column-right').css('width', '78%');
            }
            $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 26);
            $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -155);
            $('.citi-gold-select-banner p').css('top', 162);
        }
        if ($(window).width() == "600") {
            $(".bps-right-main").css("width", "100%");
            $(".bpc-main-en .fifteen").css("width", "100%");
            $(".double-col").css("width", "44%");
            $(".footer-sec-row .footer-sec:last-child").css("width", "43%");
            $('footer .footer-line-bottom p').width('55%')
            $("footer .footer-line-bottom p.copryright").width('30%').css('position', 'relative').css('top', -11)
            $("footer .footer-line-bottom p.copryright").css('margin-top', '10px')
            $('.slider-text-container').width('300px')
            $('.banner').height('180px');
            var productbannerh2 = $('.banner h1').height();
            var productbannerp = $('.banner p').height();
            var temp = productbannerh2 + productbannerp;
            var heighth2 = $('.banner').height() - temp;
            var bottomh2 = heighth2 / 2;
            var bottomph1 = $('.banner').height() / 2;
            if ($('.banner').hasClass('citi-gold-select-banner')) {
                $('.banner h1').css("bottom", bottomph1 + 8.5);
                $('.banner p').css("top", bottomph1 + 8.5);
                $('.banner h1,.banner p').css('left', 445);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -76);
                $('.citi-gold-select-banner p').css('top', 114);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 254);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 387);
                $('.half-gold-banner').css('bottom', 20);
                $('.half-gold-banner').css('left', 20);
                $('.half-gold-banner').css('width', 220);
                $('.double-column-left').css('width', '33%');
                $('.double-column-right').css('width', '63%');
            } else if ($('.banner').hasClass('citi-gold-banner')) {
                $('.banner h1').css("bottom", '49%');
                $('.banner p').css("top", bottomph1 + 12.5);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -76);
                $('.citi-gold-select-banner p').css('top', 114);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 254);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 387);
                $('.half-gold-banner').css('bottom', 20);
                $('.half-gold-banner').css('left', 20);
                $('.half-gold-banner').css('width', 220);
                $('.double-column-left').css('width', '33%');
                $('.double-column-right').css('width', '63%');
            } else {
                $('.banner h1').css("bottom", bottomph1 + 8);
                $('.banner p').css("top", bottomph1 + 8);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -76);
                $('.citi-gold-select-banner p').css('top', 114);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 254);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 325);
                $('.half-gold-banner').css('bottom', 20);
                $('.half-gold-banner').css('left', 20);
                $('.half-gold-banner').css('width', 220);
                $('.double-column-left').css('width', '33%');
                $('.double-column-right').css('width', '63%');
            }
            $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -90);
            $('.citi-gold-select-banner p').css('top', 100);
            $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 26);
            $("#table_arrowhid").css("overflow", "hidden");
        }
    }
});
jQuery(window).bind('orientationchange', function(e) {
    setTimeout(function() {
        if (navigator.userAgent.indexOf('iPad') != -1) {
            if ($(window).width() == "1024") {
                $('.slider-text-container').width('550px')
                $('.banner').height('310px');
                var productbannerh2 = $('.banner h1').height();
                var productbannerp = $('.banner p').height();
                var temp = productbannerh2 + productbannerp;
                var heighth2 = $('.banner').height() - temp;
                var bottomh2 = heighth2 / 2;
                var bottomph1 = $('.banner').height() / 2;
                if ($('.banner').hasClass('citi-gold-select-banner')) {
                    $('.banner h1').css("bottom", bottomph1 + 8.5);
                    $('.banner p').css("top", bottomph1 + 8.5);
                    $('.banner h1,.banner p').css('left', 450);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -137);
                    $('.citi-gold-select-banner p').css('top', 182);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 433);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 387);
                    $('.half-gold-banner').css('bottom', 27);
                    $('.half-gold-banner').css('left', 20);
                    $('.half-gold-banner').css('width', 396);
                    $('.double-column-left').css('width', '19%');
                    $('.double-column-right').css('width', '78%');
                } else if ($('.banner').hasClass('citi-gold-banner')) {
                    $('.banner h1').css("bottom", '49%');
                    $('.banner p').css("top", bottomph1 + 12.5);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -137);
                    $('.citi-gold-select-banner p').css('top', 182);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 433);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 387);
                    $('.half-gold-banner').css('bottom', 27);
                    $('.half-gold-banner').css('left', 20);
                    $('.half-gold-banner').css('width', 396);
                    $('.double-column-left').css('width', '19%');
                    $('.double-column-right').css('width', '78%');
                } else {
                    $('.banner h1').css("bottom", bottomph1 + 8);
                    $('.banner p').css("top", bottomph1 + 8);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -137);
                    $('.citi-gold-select-banner p').css('top', 182);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 433);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 387);
                    $('.half-gold-banner').css('bottom', 27);
                    $('.half-gold-banner').css('left', 20);
                    $('.half-gold-banner').css('width', 396);
                    $('.double-column-left').css('width', '19%');
                    $('.double-column-right').css('width', '78%');
                }
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 26);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -155);
                $('.citi-gold-select-banner p').css('top', 162);
            }
            if ($(window).width() == "768") {
                $('.slider-text-container').width('430px')
                $('.banner').height('227px');
                var productbannerh2 = $('.banner h1').height();
                var productbannerp = $('.banner p').height();
                var temp = productbannerh2 + productbannerp;
                var heighth2 = $('.banner').height() - temp;
                var bottomh2 = heighth2 / 2;
                var bottomph1 = $('.banner').height() / 2;
                if ($('.banner').hasClass('citi-gold-select-banner')) {
                    $('.banner h1').css("bottom", bottomph1 + 8.5);
                    $('.banner p').css("top", bottomph1 + 8.5);
                    $('.banner h1,.banner p').css('left', 330);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -118);
                    $('.citi-gold-select-banner p').css('top', 129);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 325);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 387);
                    $('.half-gold-banner').css('bottom', 20);
                    $('.half-gold-banner').css('left', 20);
                    $('.half-gold-banner').css('width', 296);
                    $('.double-column-left').css('width', '25%');
                    $('.double-column-right').css('width', '70%');
                } else if ($('.banner').hasClass('citi-gold-banner')) {
                    $('.banner h1').css("bottom", '49%');
                    $('.banner p').css("top", bottomph1 + 12.5);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -96);
                    $('.citi-gold-select-banner p').css('top', 141);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 325);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 387);
                    $('.half-gold-banner').css('bottom', 20);
                    $('.half-gold-banner').css('left', 20);
                    $('.half-gold-banner').css('width', 296);
                    $('.double-column-left').css('width', '25%');
                    $('.double-column-right').css('width', '70%');
                } else {
                    $('.banner h1').css("bottom", bottomph1 + 8);
                    $('.banner p').css("top", bottomph1 + 8);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -96);
                    $('.citi-gold-select-banner p').css('top', 141);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 325);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 387);
                    $('.half-gold-banner').css('bottom', 20);
                    $('.half-gold-banner').css('left', 20);
                    $('.half-gold-banner').css('width', 296);
                    $('.double-column-left').css('width', '25%');
                    $('.double-column-right').css('width', '70%');
                }
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 26);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -118);
                $('.citi-gold-select-banner p').css('top', 129);
            }
        }
        if (navigator.userAgent.indexOf('SM-T211') != -1) {
            if ($(window).width() == "1024") {
                $(".bps-right-main").css("width", "33%");
                $(".bpc-main-en .fifteen").css("width", "62.095%");
                $(".footer-sec-row .footer-sec:last-child").css("width", "44%");
                $('footer .footer-line-bottom p').width('auto')
                $("footer .footer-line-bottom p.copryright").removeAttr("top");
                $("footer .footer-line-bottom p.copryright").removeAttr("position");
                $("footer .footer-line-bottom p.copryright").removeAttr("margin-top");
                $('.slider-text-container').width('550px')
                $('.banner').height('300px');
                var productbannerh2 = $('.banner h1').height();
                var productbannerp = $('.banner p').height();
                var temp = productbannerh2 + productbannerp;
                var heighth2 = $('.banner').height() - temp;
                var bottomh2 = heighth2 / 2;
                var bottomph1 = $('.banner').height() / 2;
                if ($('.banner').hasClass('citi-gold-select-banner')) {
                    $('.banner h1').css("bottom", bottomph1 + 12.5);
                    $('.banner p').css("top", bottomph1 + 12.5);
                    $('.banner h1,.banner p').css('left', 330)
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -137);
                    $('.citi-gold-select-banner p').css('top', 182);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 433);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 387);
                    $('.half-gold-banner').css('bottom', 27);
                    $('.half-gold-banner').css('left', 20);
                    $('.half-gold-banner').css('width', 396);
                    $('.double-column-left').css('width', '19%');
                    $('.double-column-right').css('width', '78%');
                } else if ($('.banner').hasClass('citi-gold-banner')) {
                    $('.banner h1').css("bottom", bottomph1 + 12.5);
                    $('.banner p').css("top", bottomph1 + 12.5);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -137);
                    $('.citi-gold-select-banner p').css('top', 182);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 433);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 387);
                    $('.half-gold-banner').css('bottom', 27);
                    $('.half-gold-banner').css('left', 20);
                    $('.half-gold-banner').css('width', 396);
                    $('.double-column-left').css('width', '19%');
                    $('.double-column-right').css('width', '78%');
                } else {
                    $('.banner h1').css("bottom", bottomph1 + 8);
                    $('.banner p').css("top", bottomph1 + 8);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -137);
                    $('.citi-gold-select-banner p').css('top', 182);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 433);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 387);
                    $('.half-gold-banner').css('bottom', 27);
                    $('.half-gold-banner').css('left', 20);
                    $('.half-gold-banner').css('width', 396);
                    $('.double-column-left').css('width', '19%');
                    $('.double-column-right').css('width', '78%');
                }
                $('.half-gold-banner').css('bottom', 27);
                $('.half-gold-banner').css('left', 20);
                $('.half-gold-banner').css('width', 396);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -155);
                $('.citi-gold-select-banner p').css('top', 162);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 26);
            }
            if ($(window).width() == "600") {
                $(".bps-right-main").css("width", "100%");
                $(".bpc-main-en .fifteen").css("width", "100%");
                $(".double-col").css("width", "44%");
                $(".footer-sec-row .footer-sec:last-child").css("width", "43%");
                $('footer .footer-line-bottom p').width('55%')
                $("footer .footer-line-bottom p.copryright").width('30%').css('position', 'relative').css('top', -11)
                $("footer .footer-line-bottom p.copryright").css('margin-top', '10px')
                $('.slider-text-container').width('300px')
                $('.banner').height('180px');
                var productbannerh2 = $('.banner h1').height();
                var productbannerp = $('.banner p').height();
                var temp = productbannerh2 + productbannerp;
                var heighth2 = $('.banner').height() - temp;
                var bottomh2 = heighth2 / 2;
                var bottomph1 = $('.banner').height() / 2;
                if ($('.banner').hasClass('citi-gold-select-banner')) {
                    $('.banner h1').css("bottom", bottomph1 + 12.5);
                    $('.banner p').css("top", bottomph1 + 12.5);
                    $('.banner h1,.banner p').css('left', 445);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -76);
                    $('.citi-gold-select-banner p').css('top', 114);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 254);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 387);
                    $('.half-gold-banner').css('bottom', 20);
                    $('.half-gold-banner').css('left', 20);
                    $('.half-gold-banner').css('width', 220);
                    $('.double-column-left').css('width', '33%');
                    $('.double-column-right').css('width', '63%');
                } else if ($('.banner').hasClass('citi-gold-banner')) {
                    $('.banner h1').css("bottom", bottomph1 + 12.5);
                    $('.banner p').css("top", bottomph1 + 12.5);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -76);
                    $('.citi-gold-select-banner p').css('top', 114);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 254);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 325);
                    $('.half-gold-banner').css('bottom', 20);
                    $('.half-gold-banner').css('left', 20);
                    $('.half-gold-banner').css('width', 220);
                    $('.double-column-left').css('width', '33%');
                    $('.double-column-right').css('width', '63%');
                } else {
                    $('.banner h1').css("bottom", bottomph1 + 8);
                    $('.banner p').css("top", bottomph1 + 8);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -76);
                    $('.citi-gold-select-banner p').css('top', 114);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 254);
                    $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('width', 325);
                    $('.half-gold-banner').css('bottom', 20);
                    $('.half-gold-banner').css('left', 20);
                    $('.half-gold-banner').css('width', 220);
                    $('.double-column-left').css('width', '33%');
                    $('.double-column-right').css('width', '63%');
                }
                $('.half-gold-banner').css('bottom', 20);
                $('.half-gold-banner').css('left', 20);
                $('.half-gold-banner').css('width', 220);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2').css('bottom', -90);
                $('.citi-gold-select-banner p').css('top', 100);
                $('.citi-gold-select-banner h1,.citi-gold-select-banner h2,.citi-gold-select-banner p').css('left', 26);
                $("#table_arrowhid").css("overflow", "hidden");
            }
        }
    }, 700);
});

function MM_openBrWindow(e, t, n) {
    window.open(e, t, n)
}

function createCookie(e, t, n) {
    var r;
    if (n) {
        var i = new Date;
        i.setTime(i.getTime() + n * 24 * 60 * 60 * 1e3);
        r = "; expires=" + i.toGMTString()
    } else {
        r = ""
    }
    document.cookie = e + "=" + t + r + "; path=/"
}

function getCookie(e) {
    var t, n, r, i = document.cookie.split(";");
    for (t = 0; t < i.length; t++) {
        n = i[t].substr(0, i[t].indexOf("="));
        r = i[t].substr(i[t].indexOf("=") + 1);
        n = n.replace(/^\s+|\s+$/g, "");
        if (n == e) {
            return unescape(r)
        }
    }
}

function eraseCookie(e) {
    createCookie(e, "", -1)
}

function setCookie(e, t, n) {
    var r = new Date;
    r.setDate(r.getDate() + n);
    var i = escape(t) + (n === null ? "" : "; expires=" + r.toUTCString());
    document.cookie = e + "=" + i
}
var is_touch_device = "ontouchstart" in document.documentElement;
$(function() {
    var tabbluelength = $('.blue li').length;
    var tabtext = "";
    for (var i = 1; i <= tabbluelength; i++) {
        var txt1 = i - 1;
        var txthtml = $('.blue li:eq(' + txt1 + ') a').html()
        if (i == 1)
            tabtext = "<div class='tab-ph-heaer'> <a id='b" + i + "sir' title='' class='current' href='javascript:void(0);'>" + txthtml + "</a></div>";
        else
            tabtext = "<div class='tab-ph-heaer'> <a id='b" + i + "sir' title='' class='' href='javascript:void(0);'>" + txthtml + "</a></div>";
        $("#re" + i).before(tabtext);
    }
    $('.tab-ph-heaer').click(function(e) {
        var len = $(this).index() / 2 + 1;
        tabrcnew1('b' + len + 'sir', tabbluelength);
    })
})
var tablet = function() {
    return {
        detect: function() {
            (function() {
                var previousDevice, _addClass, _doc_element, _find, _handleOrientation, _hasClass, _orientation_event, _removeClass, _supports_orientation, _user_agent;
                previousDevice = window.device;
                window.device = {};
                _doc_element = window.document.documentElement;
                _user_agent = window.navigator.userAgent.toLowerCase();
                device.ios = function() {
                    return device.iphone() || device.ipod() || device.ipad();
                };
                device.iphone = function() {
                    return _find('iphone');
                };
                device.ipod = function() {
                    return _find('ipod');
                };
                device.ipad = function() {
                    return _find('ipad');
                };
                device.android = function() {
                    return _find('android');
                };
                device.androidPhone = function() {
                    return device.android() && _find('mobile');
                };
                device.androidTablet = function() {
                    return device.android() && !_find('mobile');
                };
                device.blackberry = function() {
                    return _find('blackberry') || _find('bb10') || _find('rim');
                };
                device.blackberryPhone = function() {
                    return device.blackberry() && !_find('tablet');
                };
                device.blackberryTablet = function() {
                    return device.blackberry() && _find('tablet');
                };
                device.windows = function() {
                    return _find('windows');
                };
                device.windowsPhone = function() {
                    return device.windows() && _find('phone');
                };
                device.windowsTablet = function() {
                    return device.windows() && (_find('touch') && !device.windowsPhone());
                };
                device.fxos = function() {
                    return (_find('(mobile;') || _find('(tablet;')) && _find('; rv:');
                };
                device.fxosPhone = function() {
                    return device.fxos() && _find('mobile');
                };
                device.fxosTablet = function() {
                    return device.fxos() && _find('tablet');
                };
                device.meego = function() {
                    return _find('meego');
                };
                device.cordova = function() {
                    return window.cordova && location.protocol === 'file:';
                };
                device.nodeWebkit = function() {
                    return typeof window.process === 'object';
                };
                device.mobile = function() {
                    return device.androidPhone() || device.iphone() || device.ipod() || device.windowsPhone() || device.blackberryPhone() || device.fxosPhone() || device.meego();
                };
                device.tablet = function() {
                    return device.ipad() || device.androidTablet() || device.blackberryTablet() || device.windowsTablet() || device.fxosTablet();
                };
                device.desktop = function() {
                    return !device.tablet() && !device.mobile();
                };
                device.portrait = function() {
                    return (window.innerHeight / window.innerWidth) > 1;
                };
                device.landscape = function() {
                    return (window.innerHeight / window.innerWidth) < 1;
                };
                device.noConflict = function() {
                    window.device = previousDevice;
                    return this;
                };
                _find = function(needle) {
                    return _user_agent.indexOf(needle) !== -1;
                };
                _hasClass = function(class_name) {
                    var regex;
                    regex = new RegExp(class_name, 'i');
                    return _doc_element.className.match(regex);
                };
                _addClass = function(class_name) {
                    if (!_hasClass(class_name)) {
                        return _doc_element.className += " " + class_name;
                    }
                };
                _removeClass = function(class_name) {
                    if (_hasClass(class_name)) {
                        return _doc_element.className = _doc_element.className.replace(class_name, "");
                    }
                };
                if (device.ios()) {
                    if (device.ipad()) {
                        result = true;
                        return result;
                    } else if (device.iphone()) {
                        _addClass("ios iphone mobile");
                    } else if (device.ipod()) {
                        _addClass("ios ipod mobile");
                    }
                } else if (device.android()) {
                    if (device.androidTablet()) {
                        result = true;
                        return result;
                    } else {
                        _addClass("android mobile");
                    }
                } else if (device.blackberry()) {
                    if (device.blackberryTablet()) {
                        result = true;
                        return result;
                    } else {
                        _addClass("blackberry mobile");
                    }
                } else if (device.windows()) {
                    if (device.windowsTablet()) {
                        result = true;
                        return result;
                    } else if (device.windowsPhone()) {
                        _addClass("windows mobile");
                    } else {
                        _addClass("desktop");
                    }
                } else if (device.fxos()) {
                    if (device.fxosTablet()) {
                        result = true;
                        return result;
                    } else {
                        _addClass("fxos mobile");
                    }
                } else if (device.meego()) {
                    _addClass("meego mobile");
                } else if (device.nodeWebkit()) {
                    _addClass("node-webkit");
                } else {
                    _addClass("desktop");
                }
                if (device.cordova()) {
                    _addClass("cordova");
                }
            }).call(this);
            return result;
        }
    }
}();
var mobile = function() {
    return {
        detect: function(e, t) {
            e = navigator.userAgent;
            if (/bb|meego|mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(e) || /1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(e.substring(0, 4))) return true;
            else return false
        }
    }
}();
var heaadshow1 = 0;
var heaadshow2 = 0;
var heaadshow3 = 0;
var heaadshow4 = 0;
var heaadshow5 = 0;
var heaadshow6 = 0;
var heaadshow7 = 0;
var heaadshow8 = 0;
var heaadshow9 = 0;
var heaadshow10 = 0;
var heaadshow11 = 0;
var heaadshow21 = 0;
var heaadshow31 = 0;
var heaadshow41 = 0;
var heaadshow51 = 0;
var heaadshow61 = 0;
var heaadshow71 = 0;
var heaadshow81 = 0;
var userAgent = navigator.userAgent.toLowerCase();
var appVersion = navigator.appVersion.toLowerCase();
var arraySHCSS = ['/CMENA-371/v4/uae/data/css/mobile.css'];
var arraySHJS = ['/CMENA-371/v4/uae/data/js/jquery-1.8.3.min.js', '/CMENA-371/v4/uae/data/js/idangerous.swiper-2.0.min.js'];
var arrayIPADCSS = ['/CMENA-371/v4/uae/data/css/ipad.css'];
var arrayIPADJS = ['/CMENA-371/v4/uae/data/js/jquery-1.8.3.min.js', '/CMENA-371/v4/uae/data/js/idangerous.swiper-2.0.min.js'];
var arrayMORECSS = ['/CMENA-371/v4/uae/data/css/home-desk.css', '/CMENA-371/v4/uae/data/css/home-desk_new.css'];
var arrayMOREJS = ['/CMENA-371/v4/uae/data/js/jquery-1.8.3.min.js', '/CMENA-371/v4/uae/data/js/idangerous.swiper-2.0.mindeck.js'];
var chkUA = function() {
    if (mobile.detect() && userAgent.indexOf('ipad') == -1) {
        return 'SH';
    } else if (tablet.detect()) {
        return 'IPAD';
    } else {
        return 'MORE';
    }
};
var uaType = chkUA();
var setArrayCSS = eval('array' + uaType + 'CSS');
var setArrayJS = eval('array' + uaType + 'JS');
for (var setI = 0, len = setArrayCSS.length; setI < len; setI++) {
    var sNew = document.createElement("link");
    sNew.async = true;
    sNew.href = setArrayCSS[setI];
    sNew.rel = 'stylesheet';
    var s0 = document.getElementsByTagName('link')[0];
    s0.parentNode.appendChild(sNew, s0);
};
for (var setI = 0, len = setArrayJS.length; setI < len; setI++) {
    var sNew = document.createElement("script");
    sNew.async = true;
    sNew.src = setArrayJS[setI];
    var s0 = document.getElementsByTagName('script')[0];
    document.write('<script src="' + sNew.src + '" type="text/javascript"><\/script>');
};
$(function() {})

function lang() {
    var expr = /\/en\//;
    var expr1 = /\/gr\//;
    var cpUrl = new String(document.location);
    var ch = expr.test(cpUrl);
    expr.lastIndex = 0;
    var ch1 = expr1.test(cpUrl);
    if (ch === true) {
        var i = cpUrl.lastIndexOf("/en/");
        var url = (cpUrl.substring(0, i)) + "/gr/" + (cpUrl.substring(i + 4));
        window.location.href = url;
    } else if (ch1 === true) {
        var i = cpUrl.lastIndexOf("/gr/");
        var url1 = (cpUrl.substring(0, i)) + "/en/" + (cpUrl.substring(i + 4));
        window.location.href = url1;
    } else {
        window.location.href = "index.htm";
    }
}
$(document).ready(function() {
    $('.show-hide-cnt p:last-child').css('margin-bottom', '-2px');
    $('.common-list-content p.notes:last-child').css('margin-bottom', '5px');
    var clickchange = 0;
    var mouseoverchage = 0;
    var menuContentTopNav = $('#main-cont-top-nav');
    var menuContent = $('#Menu-Content');
    var menuArrow = $('#Menu-Arrow');
    var menuLinkLi = $('#Menu-Link li');

    function showarrowtim() {
        clearTimeout(timer);
        menuArrow.css({
            'opacity': '1'
        });
        menuArrow.css({
            'display': 'block'
        });
    }

    function hidearrowtim() {
        menuArrow.css({
            'display': 'none'
        });
        clearTimeout(timer);
    }
    menuLinkLi.click(function(e) {
        var arrowLeft = $(this).attr('id').split('_')[1];
        var menuName = $(this).attr('id').split('_')[0];
        logon = 0;
        $('#signlOnToolContent li a').fadeOut();
        $('#signlOnToolContent').slideUp('slow');
        $('.pl9').attr('src', '/CMENA-371/v4/uae/data/images/sign-in-arrow.png');
        $('.Banking').css({
            'display': 'none'
        });
        menuContentTopNav.css({
            'display': 'block'
        });
        $('#Menu_' + menuName).css({
            'display': 'block'
        })
        menuArrow.css({
            'display': 'block'
        });
        menuArrow.css('background-position', arrowLeft + 'px 0px');
        if (mouseoverchage == 0) {
            menuArrow.css({
                'opacity': '0.0'
            });
            timer = setTimeout(function() {
                showarrowtim()
            }, 200);
        }
        mouseoverchage = 1;
        menuContent.animate({
            'top': '0px'
        }, 400);
    });
    menuLinkLi.mousemove(function(e) {
        if (mouseoverchage == 1) {
            var arrowLeft = $(this).attr('id').split('_')[1];
            var menuName = $(this).attr('id').split('_')[0];
            menuArrow.css('background-position', arrowLeft + 'px 0px');
            menuLinkLi.removeClass('menuActive');
            $(this).addClass('menuActive');
            $('.Banking').css({
                'display': 'none'
            })
            $('#Menu_' + menuName).css({
                'display': 'block'
            })
        }
    });
    var n = 0;
    $('header,#rotating-banner,#cont-section,#section').mouseenter(function() {
        mouseoverchage = 0;
        menuLinkLi.removeClass('menuActive');
        menuArrow.css({
            'display': 'none'
        });
        menuContent.animate({
            'top': '-210px'
        }, 1000);
        menuContentTopNav.slideUp(1010);
    });
    $('#wrapper').mouseleave(function() {
        mouseoverchage = 0;
        menuLinkLi.removeClass('menuActive');
        menuArrow.css({
            'display': 'none'
        });
        menuContent.animate({
            'top': '-210px'
        }, 1000);
        menuContentTopNav.slideUp(1010);
    });
    var logon = 0
    $('#signOnTool,#signlOnToolContent').click(function() {
        if (logon == 0) {
            logon = 1;
            $('#signlOnToolContent li a').fadeIn();
            $('#signlOnToolContent').slideDown();
            $('#signOnTool a').addClass('signOnToolAct');
            $('.pl9').attr('src', '/CMENA-371/v4/uae/data/images/sign-out-arrow.png');
            mouseoverchage = 0;
            menuLinkLi.removeClass('menuActive');
            menuArrow.css({
                'display': 'none'
            });
            menuContent.animate({
                'top': '-210px'
            }, 1000);
            menuContentTopNav.slideUp(1010);
            return false;
        }
        if (logon == 1) {
            logon = 0;
            $('#signlOnToolContent li a').fadeOut();
            $('#signlOnToolContent').slideUp('slow');
            $('#signOnTool a').removeClass('signOnToolAct');
            $('.pl9').attr('src', '/CMENA-371/v4/uae/data/images/sign-in-arrow.png');
            return false;
        }
    });
    $(document).click(function() {
        logon = 0;
        $('#signlOnToolContent li a').fadeOut();
        $('#signlOnToolContent').slideUp('slow');
        $('.pl9').attr('src', '/CMENA-371/v4/uae/data/images/sign-in-arrow.png');
    });
    var menushow = 0;
    var menuopen = 0;
    setTimeout(function() {
        $("#menu-icon-point").click(function() {
            $('.dropdown').slideUp();
            $('.maniul').slideUp();
            $('.searchMobWrap').slideUp();
            $('#search-icon').removeClass('menu-icon-point-active');
            if ($('.levels').css('display') == 'none') {
                $('.levels').slideDown();
                $('#menu-icon-point').addClass('menu-icon-point-active')
                menuopen = 1;
                return false;
            } else {
                menuopen = 0;
                $('.levels').slideUp();
                $('#menu-icon-point').removeClass('menu-icon-point-active')
                if ($('.show-down').hasClass('show')) {}
                return false;
            }
        });
        $('.productShow a').click(function() {
            var el = $(this).parent().next('ul');
            var cur = $(this);
            if (el.is(':visible')) {
                cur.removeClass('show');
                el.slideUp();
            } else {
                $('.productShow a').removeClass('show');
                $('.submainul').not(el).slideUp();
                cur.addClass('show');
                el.slideDown();
            }
        });
    }, 1000)
    setTimeout(function() {
        var footerScrollAnimate = $('#myScrollebleItems1');
        var footerscrollArrow = $('.footer-arrow div');
        var mobilephchkurl = location.href;
        $(window).bind('orientationchange', function(e) {
            if ($('body').width() <= 320) {
                if (clickchange > 8) {
                    footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                }
            }
            if ($('body').width() >= 320 && $('body').width() < 576) {
                if (clickchange > 8) {
                    clickchange = 7;
                    if (clickchange == 7) {
                        clickchange = 8
                        footerScrollAnimate.animate({
                            top: -240
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_up.png)');
                        return false;
                    }
                }
            }
        })
        $("#ad").click(function() {
            var artname = $(".footer-arrow div").css("background-image").split('arrow_');
            var getarrow = artname[1].split('.');
            if (getarrow[0] == "next" || getarrow[0] == "prev") {
                if (clickchange == 0) {
                    clickchange = 1
                    footerScrollAnimate.animate({
                        left: -666
                    });
                    footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_prev.png)');
                    return false;
                }
                if (clickchange == 1) {
                    clickchange = 0
                    footerScrollAnimate.animate({
                        left: 0
                    });
                    footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_next.png)');
                    return false;
                }
            }
            if (getarrow[0] == "up" || getarrow[0] == "down") {
                if ($('body').width() <= 320) {
                    if (clickchange == 0) {
                        clickchange = 1
                        footerScrollAnimate.animate({
                            top: -30
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 1) {
                        clickchange = 2
                        footerScrollAnimate.animate({
                            top: -60
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 2) {
                        clickchange = 3
                        footerScrollAnimate.animate({
                            top: -90
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 3) {
                        clickchange = 4
                        footerScrollAnimate.animate({
                            top: -120
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 4) {
                        clickchange = 5
                        footerScrollAnimate.animate({
                            top: -150
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 5) {
                        clickchange = 6
                        footerScrollAnimate.animate({
                            top: -188
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 6) {
                        clickchange = 7
                        footerScrollAnimate.animate({
                            top: -220
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 7) {
                        clickchange = 8
                        footerScrollAnimate.animate({
                            top: -250
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_up.png)');
                        return false;
                    }
                    /* if (clickchange == 8) {
                        clickchange = 9
                        footerScrollAnimate.animate({
                            top: -280
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_up.png)');
                        return false;
                    } */
                    /* if (clickchange == 9) {
                        clickchange = 10
                        footerScrollAnimate.animate({
                            top: -310
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_up.png)');
                        return false;
                    } */
                    if (clickchange == 8) {
                        clickchange = 0
                        footerScrollAnimate.animate({
                            top: 0
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                }
                if ($('body').width() >= 320 && $('body').width() < 576) {
                    if (clickchange == 0) {
                        clickchange = 1
                        footerScrollAnimate.animate({
                            top: -30
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 1) {
                        clickchange = 2
                        footerScrollAnimate.animate({
                            top: -60
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 2) {
                        clickchange = 3
                        footerScrollAnimate.animate({
                            top: -90
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 3) {
                        clickchange = 4
                        footerScrollAnimate.animate({
                            top: -120
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 4) {
                        clickchange = 5
                        footerScrollAnimate.animate({
                            top: -150
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 5) {
                        clickchange = 6
                        footerScrollAnimate.animate({
                            top: -180
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 6) {
                        clickchange = 7
                        footerScrollAnimate.animate({
                            top: -210
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_up.png)');
                        return false;
                    }
                    /* if (clickchange == 7) {
                        clickchange = 8
                        footerScrollAnimate.animate({
                            top: -240
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_up.png)');
                        return false;
                    } */
                    if (clickchange == 7) {
                        clickchange = 0
                        footerScrollAnimate.animate({
                            top: 0
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                }
                if ($('body').width() == 600) {
                    if (clickchange == 0) {
                        clickchange = 1
                        footerScrollAnimate.animate({
                            top: -30
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 1) {
                        clickchange = 2
                        footerScrollAnimate.animate({
                            top: -60
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 2) {
                        clickchange = 3
                        footerScrollAnimate.animate({
                            top: -90
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 3) {
                        clickchange = 4
                        footerScrollAnimate.animate({
                            top: -120
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 4) {
                        clickchange = 5
                        footerScrollAnimate.animate({
                            top: -150
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_up.png)');
                        return false;
                    }
                    if (clickchange == 5) {
                        clickchange = 0
                        footerScrollAnimate.animate({
                            top: 0
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                }
                if ($('body').width() == 667) {
                    if (clickchange == 0) {
                        clickchange = 1
                        footerScrollAnimate.animate({
                            top: -30
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 1) {
                        clickchange = 2
                        footerScrollAnimate.animate({
                            top: -60
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 2) {
                        clickchange = 3
                        footerScrollAnimate.animate({
                            top: -90
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 3) {
                        clickchange = 4
                        footerScrollAnimate.animate({
                            top: -120
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 4) {
                        clickchange = 5
                        footerScrollAnimate.animate({
                            top: -150
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_up.png)');
                        return false;
                    }
                    if (clickchange == 5) {
                        clickchange = 6
                        footerScrollAnimate.animate({
                            top: -180
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 6) {
                        clickchange = 0
                        footerScrollAnimate.animate({
                            top: 0
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                }
                if ($('body').width() == 480) {
                    if (clickchange == 0) {
                        clickchange = 1
                        footerScrollAnimate.animate({
                            top: -30
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 1) {
                        clickchange = 2
                        footerScrollAnimate.animate({
                            top: -60
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 2) {
                        clickchange = 3
                        footerScrollAnimate.animate({
                            top: -90
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 3) {
                        clickchange = 4
                        footerScrollAnimate.animate({
                            top: -120
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 4) {
                        clickchange = 5
                        footerScrollAnimate.animate({
                            top: -150
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_up.png)');
                        return false;
                    }
                    if (clickchange == 5) {
                        clickchange = 6
                        footerScrollAnimate.animate({
                            top: -180
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 6) {
                        clickchange = 7
                        footerScrollAnimate.animate({
                            top: -210
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 7) {
                        clickchange = 8
                        footerScrollAnimate.animate({
                            top: -240
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 8) {
                        clickchange = 0
                        footerScrollAnimate.animate({
                            top: 0
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                }
                if ($('body').width() == 640) {
                    if (clickchange == 0) {
                        clickchange = 1
                        footerScrollAnimate.animate({
                            top: -30
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 1) {
                        clickchange = 2
                        footerScrollAnimate.animate({
                            top: -60
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 2) {
                        clickchange = 3
                        footerScrollAnimate.animate({
                            top: -90
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                    if (clickchange == 3) {
                        clickchange = 4
                        footerScrollAnimate.animate({
                            top: -120
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_up.png)');
                        return false;
                    }
                    if (clickchange == 4) {
                        clickchange = 0
                        footerScrollAnimate.animate({
                            top: 0
                        });
                        footerscrollArrow.css('background-image', 'url(/CMENA-371/v4/uae/data/images/arrow_down.png)');
                        return false;
                    }
                }
            }
        });
    }, 1000);
    var clickchange = 0;
    var leftRighttab = 1;
    $("#left_arrow").click(function() {
        var touchTabCount = $('.tab-touch-title').length;
        var touchTabCountMinus = touchTabCount - 1;
        if (touchTabCountMinus != 0) {
            leftRighttab--;
        }
        if (leftRighttab == 1) {
            $("#left_arrow").css({
                'display': 'none'
            })
            $("#right_arrow").css({
                'display': 'block'
            })
        } else {
            $("#right_arrow").css({
                'display': 'block'
            })
        }
        changeTab(leftRighttab);
    });
    $("#right_arrow").click(function() {
        var touchTabCount = $('.tab-touch-title').length;
        if (leftRighttab <= touchTabCount) {
            leftRighttab++
        }
        if (leftRighttab == touchTabCount) {
            $("#right_arrow").css({
                'display': 'none'
            })
            $("#left_arrow").css({
                'display': 'block'
            })
        }
        $("#left_arrow").css({
            'display': 'block'
        })
        changeTab(leftRighttab);
    });

    function changeTab(leftRighttab) {
        for (i = 1; i <= 6; i++) {
            if (document.getElementById('re' + i))
                document.getElementById('re' + i).style.display = 'none';
            if (document.getElementById('tab' + i))
                document.getElementById('tab' + i).style.display = 'none';
        }
        document.getElementById('tab' + leftRighttab).style.display = 'block';
        document.getElementById('re' + leftRighttab).style.display = 'block';
    }
    var Depositsulval = 0
    $('#nav-left li a').click(function() {
        if ($(this).parent().hasClass('leftliholder')) {
            if ($(this).hasClass('active-lis')) {
                $(this).removeClass('active-lis');
                $(this).removeClass('active_top_nav');
                $(this).next().slideUp();
            } else {
                $(this).addClass('active-lis');
                $(this).addClass('active_top_nav');
                $(this).next().slideDown();
                if ($(this).parent().siblings().children().hasClass('active-lis')) {
                    $(this).parent().siblings().children().removeClass('active-lis');
                    $(this).parent().siblings().children().removeClass('active_top_nav');
                    $(this).parent().siblings().children().next().slideUp();
                }
            }
        }
        if ($(this).parent().hasClass('leftshowhide_subLi')) {
            if ($(this).hasClass('active-lis')) {
                $(this).removeClass('active-lis');
                $(this).removeClass('active_top_nav');
				/* 23-6-15 */
				$(this).removeClass('active');
                $(this).next().slideUp();
            } else {
                $(this).addClass('active-lis');
                $(this).addClass('active_top_nav');
				/* 23-6-15 */
				$(this).addClass('active');
                $(this).next().slideDown();
                if ($(this).parent().siblings().children().hasClass('active-lis')) {
                    $(this).parent().siblings().children().removeClass('active-lis');
                    $(this).parent().siblings().children().removeClass('active_top_nav');
                    $(this).parent().siblings().children().next().slideUp();
                }
            }
        }
    });
    $("li #nav-left-info").click(function() {
        $("#GeneralID1 a").removeClass('active_top_nav')
        $("#GeneralID1 ul").css("display", "none")
        var currentpage = location.href.substr(location.href.lastIndexOf("/") + 1, location.href.length)
        $("#GeneralID1 a").attr("href", currentpage)
    });
    var applynowval = 0
    $('#applynow').click(function() {
        if (applynowval == 0) {
            $('.cS-applicationFormHldr').slideDown('slow');
            applynowval = 1;
            return false;
        }
        if (applynowval == 1) {
            $('.cS-applicationFormHldr').slideUp('slow');
            applynowval = 0;
            return false;
        }
    });
    $('.closeButton').click(function() {
        $('.cS-applicationFormHldr').slideUp('slow');
    });
    $(".tableScroll").each(function() {
        inttabarrow = inttabarrow + 1;
    })
    for (var i = 0; i < inttabarrow; i++) {
        $(".clsTable:eq(" + i + ")").before("<div class='table-arrow'><span class='tab-arw-rit'><img src='/CMENA-371/v4/uae/data/images/table-arrow-right.png' width='27' height='50' alt=''></span><span class='tab-arw-lft'><img src='/CMENA-371/v4/uae/data/images/table-arrow-left.png' width='27' height='49' alt=''></span></div>");
        $('.table-arrow:eq(' + i + ') .tab-arw-lft').hide();
        $('.table-arrow:eq(' + i + ') .tab-arw-rit').hide();
        if ($(".clsTable:eq(" + i + ")").width() > $(".tableScroll:eq(" + i + ")").width()) {
            $('.table-arrow:eq(' + i + ') .tab-arw-lft').hide();
            $('.table-arrow:eq(' + i + ') .tab-arw-rit').show();
        }
    }
    $('.table-arrow').width($('.tableScroll').width())
    var whichtable = 0;
    var ddtabstr1 = 0;
    $('.tableScroll').scroll(function() {
        $(".tableScroll").each(function() {
            ddtabstr1 = ddtabstr1 + 1;
        })
        for (var i = 0; i < ddtabstr1; i++) {
            if ($(".clsTable:eq(" + i + ")").width() > $(".tableScroll:eq(" + i + ")").width()) {
                if ($(this).scrollLeft() == 0) {
                    $('.table-arrow:eq(' + i + ') .tab-arw-lft').hide();
                    $('.table-arrow:eq(' + i + ') .tab-arw-rit').show();
                    countscrollleft = 0;
                } else {
                    $('.table-arrow:eq(' + i + ') .tab-arw-lft').show();
                    $('.table-arrow:eq(' + i + ') .tab-arw-rit').hide();
                    countscrollleft = 0;
                }
            }
        }
    });
    window.setInterval(function() {
        tablescrollfun();
    }, 1000);

    function tablescrollfun() {
        if (countscrollleft < 15) {
            for (var i = 0; i < inttabarrow; i++) {
                if ($(".clsTable:eq(" + i + ")").width() > $(".tableScroll:eq(" + i + ")").width()) {
                    $(".table-arrow:eq(" + i + ") .tab-arw-lft").animate({
                        opacity: 0.0
                    }, 500).animate({
                        opacity: 1
                    }, 500)
                    $(".table-arrow:eq(" + i + ") .tab-arw-rit").animate({
                        opacity: 0.0
                    }, 500).animate({
                        opacity: 1
                    }, 500)
                }
            }
        } else {
            for (var i = 0; i < inttabarrow; i++) {
                if ($(".clsTable:eq(" + i + ")").width() > $(".tableScroll:eq(" + i + ")").width()) {
                    $(".table-arrow:eq(" + i + ") .tab-arw-lft").animate({
                        opacity: 0.0
                    }, 500)
                    $(".table-arrow:eq(" + i + ") .tab-arw-rit").animate({
                        opacity: 0.0
                    }, 500)
                    setTimeout(function() {
                        $('.table-arrow:eq(' + i + ') .tab-arw-lft').hide();
                        $('.table-arrow:eq(' + i + ') .tab-arw-rit').hide();
                    }, 500);
                }
            }
        }
        countscrollleft++;
    }
    flip = 0;
    $('#tableScroll tr').each(function() {
        if (flip == 0) {
            $(this).addClass('tgrey')
            flip = 1;
        } else {
            $(this).addClass('tdwhite')
            flip = 0;
        }
    })
    $('#tableScroll tr').each(function() {
        $(this).children('td:last').addClass('clsTableTD-last')
        $(this).children('th:last').addClass('clsTableTD-last')
    })
    $('.show-hide-1').click(function() {
        $(this).next().slideToggle('slow', function() {
            $('html, body').animate({
                scrollTop: $(this).offset().top - 30
            }, 1000);
            if ($(this).css('display') != 'none') {
                countscrollleft = 0;
                $(".tableScroll").each(function() {
                    inttabarrow = inttabarrow + 1;
                })
                for (var i = 0; i < inttabarrow; i++) {
                    $('.table-arrow:eq(' + i + ') .tab-arw-lft').hide();
                    $('.table-arrow:eq(' + i + ') .tab-arw-rit').hide();
                    $(".table-arrow").width($(".tableScroll").width())
                    if ($(".clsTable:eq(" + i + ")").width() > $(".tableScroll:eq(" + i + ")").width()) {
                        if ($(".tableScroll:eq(" + i + ")").scrollLeft() == 0) {
                            $('.table-arrow:eq(' + i + ') .tab-arw-lft').hide();
                            $('.table-arrow:eq(' + i + ') .tab-arw-rit').show();
                            countscrollleft = 0;
                        } else {
                            $('.table-arrow:eq(' + i + ') .tab-arw-lft').show();
                            $('.table-arrow:eq(' + i + ') .tab-arw-rit').hide();
                            countscrollleft = 0;
                        }

                    }
                }
                $(this).prev('div').find('.showArrowIdicate').css({
                    'backgroundImage': 'url("/CMENA-371/v4/uae/data/images/blue_arrow_down.png")'
                })
                $(this).prev('div').find('.showArrowIdicate2').css({
                    'backgroundImage': 'url("/CMENA-371/v4/uae/data/images/arrow_down_new.png")'
                })
            } else {
                $(this).find('.table-arrow .tab-arw-lft').hide();
                $(this).find('.table-arrow .tab-arw-rit').hide();
                $(this).prev('div').find('.showArrowIdicate').css({
                    'backgroundImage': 'url("/CMENA-371/v4/uae/data/images/blue_arrow_up.png")'
                })
                $(this).prev('div').find('.showArrowIdicate2').css({
                    'backgroundImage': 'url("/CMENA-371/v4/uae/data/images/lft-arrow.jpg")'
                })
            }
        });
    })
});

function tabrcnew(id, total) {
    if (document.getElementById(id).className != 'current') {
        img = id.substring(1, 2, 3, 4, 5, 6);
        var tabnames = ['benefit', 'sir', 'qualification', 'apply'];
        for (i = 1; i <= total; i++) {
            if (navigator.userAgent.indexOf('MSIE 7.0') != -1) {
                $('#re' + i).fadeOut('slow');
            } else {
                document.getElementById('re' + i).style.display = 'none';
            }
            document.getElementById('a' + i + 'sir').className = '';
        }
        $('#re' + img).fadeIn('slow');
        document.getElementById(id).className = 'current';
        if (id == "a2sir") {
            if (location.href.indexOf('affinity_card_mastercard.htm') != -1) {
                if (navigator.userAgent.indexOf('MSIE 7.0') != -1) {
                    myEqualHeight();
                } else {
                    setTimeout(myEqualHeight, 250);
                }
            }
        }
    }
}

function tabrcnew1(id, total) {
    if (mobile.detect() && userAgent.indexOf('ipad') == -1) {
        var hrefVal = $("#" + id).attr("href")
        if (document.getElementById(id).className != 'current') {
            if (hrefVal == "javascript:void(0);") {
                img = id.substring(1, 2, 3);
                var tabnames = ['benefit', 'sir', 'qualification', 'apply'];
                for (i = 1; i <= total; i++) {
                    document.getElementById('re' + i).style.display = 'none';
                    $('#re' + i).slideUp('slow')
                    document.getElementById('b' + i + 'sir').className = '';
                }
                $('#re' + img).slideDown("slow", function() {
                    $("html,body").animate({
                        scrollTop: $(this).offset().top - 83
                    }, 1000)
                    document.getElementById(id).className = 'current';
                })
            }
        } else {
            for (i = 1; i <= total; i++) {
                $('#re' + i).slideUp(800)
                document.getElementById('b' + i + 'sir').className = '';
            }
        }
    } else {
        if (document.getElementById(id).className != 'current') {
            img = id.substring(1, 2, 3);
            var tabnames = ['benefit', 'sir', 'qualification', 'apply'];
            for (i = 1; i <= total; i++) {
                if (location.href.indexOf('affinity_card_mastercard.htm') != -1 || location.href.indexOf('citiprivilege.htm') != -1 || location.href.indexOf('debit_card.htm') != -1) {
                    if (navigator.userAgent.indexOf('MSIE 7.0') != -1) {
                        $('#re1' + i).fadeOut('slow');
                    } else {
                        document.getElementById('re1' + i).style.display = 'none';
                    }
                } else {
                    document.getElementById('re1' + i).style.display = 'none';
                }
                document.getElementById('b' + i + 'sir').className = '';
            }
            $('#re1' + img).fadeIn('slow');
            document.getElementById(id).className = 'current';
            if (id == "b2sir") {
                if (location.href.indexOf('affinity_card_mastercard.htm') != -1) {
                    setTimeout(myEqualHeight, 250);
                }
            }
        }
    }
}

function tabrcnew3(id, total) {
    img = id.substring(1, 2);
    var tabnames = ['benefit', 'sir', 'qualification', 'apply'];
    document.getElementById('a1benefit').className = '';
    document.getElementById('a2sir').className = '';
    document.getElementById('a3sir').className = '';
    for (i = 1; i <= total; i++) {
        document.getElementById('re' + i).style.display = 'none';
    }
    $('#re' + img).fadeIn('slow');
    document.getElementById(id).className = 'current';
}

function tabrcnew4(id, total) {
    img = id.substring(1, 2);
    var tabnames = ['benefit', 'sir', 'qualification', 'apply'];
    document.getElementById('a1benefit').className = '';
    document.getElementById('a2sir').className = '';
    document.getElementById('a3sir').className = '';
    document.getElementById('a4sir').className = '';
    for (i = 1; i <= total; i++) {
        document.getElementById('re' + i).style.display = 'none';
    }
    $('#re' + img).fadeIn('slow');
    document.getElementById(id).className = 'current';
}

function tabrcnew5(id, total) {
    if (document.getElementById(id).className != 'current') {
        img = id.substring(1, 2);
        var tabnames = ['benefit', 'sir', 'qualification', 'apply'];
        document.getElementById('a1benefit').className = '';
        document.getElementById('a2sir').className = '';
        document.getElementById('a3sir').className = '';
        document.getElementById('a4sir').className = '';
        document.getElementById('a5sir').className = '';
        for (i = 1; i <= total; i++) {
            document.getElementById('re' + i).style.display = 'none';
        }
        $('#re' + img).fadeIn('slow');
        document.getElementById(id).className = 'current';
    }
}

function tabrcnew6(id, total) {
    img = id.substring(1, 2);
    var tabnames = ['benefit', 'sir', 'qualification', 'apply'];
    document.getElementById('a1benefit').className = '';
    document.getElementById('a2sir').className = '';
    document.getElementById('a3sir').className = '';
    document.getElementById('a4sir').className = '';
    document.getElementById('a5sir').className = '';
    document.getElementById('a6sir').className = '';
    for (i = 1; i <= total; i++) {
        document.getElementById('re' + i).style.display = 'none';
    }
    $('#re' + img).fadeIn('slow');
    document.getElementById(id).className = 'current';
}
var viewval = 0;

function showhide() {
    if (viewval == 0) {
        viewval = 1;
        $('#f1').fadeIn('slow');
        document.getElementById('f2').style.display = 'none';
        $('#imgf1').html('<img src="/CMENA-371/v4/uae/data/images/grid-off.png"   alt="" border="0" > Grid View');
        return false;
    }
    if (viewval == 1) {
        $('#f2').fadeIn('slow');
        document.getElementById('f1').style.display = 'none';
        $('#imgf1').html('<img src="/CMENA-371/v4/uae/data/images/grid-on.png"   alt="" border="0" > List View');
        viewval = 0
        return false;
    }
}
var viewval1 = 0;

function showhide2() {
    if (viewval1 == 0) {
        viewval1 = 1;
        $('#f1').fadeIn('slow');
        document.getElementById('f2').style.display = 'none';
        $('#imgf1').html('<img src="/CMENA-371/v4/uae/data/images/grid-off.png"   alt="" border="0" > Grid View');
        return false;
    }
    if (viewval1 == 1) {
        $('#f2').fadeIn('slow');
        document.getElementById('f1').style.display = 'none';
        $('#imgf1').html('<img src="/CMENA-371/v4/uae/data/images/grid-on.png"   alt="" border="0" > List View');
        viewval1 = 0
        return false;
    }
}

function showHide(src, img) {
    $('.expand-head').next('div').slideUp();
    $('.expand-head a').removeClass('open').addClass('closed')
    if ($("#" + src).css('display') == "none") {
        $("#" + src).slideDown();
        var scr = parseInt($("#" + src).offset().top - 200);
        if (mobile.detect()) {
            setTimeout(function() {
                $("html,body").animate({
                    scrollTop: $("#" + src).offset().top - 70
                })
            }, 500);
        } else {
            if (location.href.indexOf('Citi_Mobile_Apps.htm') != -1) {
                setTimeout(function() {
                    $("html,body").animate({
                        scrollTop: $("#" + src).offset().top - 70
                    })
                }, 500);
            } else {
                setTimeout(function() {
                    $("html,body").animate({
                        scrollTop: $("#" + src).offset().top - 70
                    })
                }, 500);
            }
        }
        $('.expand-head a').eq(parseInt(src.split('d')[1]) - 1).removeClass('closed').addClass('open')
    } else {
        $("#" + src).slideUp();
        $('.expand-head a').eq(parseInt(src.split('d')[1]) - 1).removeClass('open').addClass('closed')
    }
}

function MiReCaCla(id, total) {
    img = id.substring(1, 2);
    var tabnames = ['benefit', 'key'];
    for (i = 1; i <= total; i++) {
        document.getElementById('re' + i).style.display = 'none';
        document.getElementById('a' + i + tabnames[i - 1]).src = "/CMENA-371/v4/uae/data/images/" + tabnames[i - 1] + "_normal.gif";
        document.getElementById('a' + i + tabnames[i - 1]).parentNode.style.cursor = "pointer";
    }
    document.getElementById('re' + img).style.display = 'block';
    document.getElementById(id).src = "/CMENA-371/v4/uae/data/images/" + tabnames[img - 1] + "_over.gif";
    document.getElementById(id).parentNode.style.cursor = "default";
}

function showhide1(src, img) {
    var imgopen = '/CMENA-371/v4/uae/data/images/minus.png';
    var imgclose = '/CMENA-371/v4/uae/data/images/plus.png';
    if (!$("#" + src).is(":visible")) {
        $("#" + src).slideDown();
        $("#" + img).attr("src", imgopen);
    } else {
        $("#" + src).slideUp();
        $("#" + img).attr("src", imgclose);
    }
}

function showhide111(src, img) {
    var imgopen = '/CMENA-371/v4/uae/data/images/cta-arrow-dwn.png';
    var imgclose = '/CMENA-371/v4/uae/data/images/cta-arrow.png';
    if (!$("#" + src).is(":visible")) {
        $("#" + src).slideDown();
        $("#" + img).attr("src", imgopen);
    } else {
        $("#" + src).slideUp();
        $("#" + img).attr("src", imgclose);
    }
}

function MiReCaCla(id, total) {
    img = id.substring(1, 2);
    var tabnames = ['benefit', 'key'];
    for (i = 1; i <= total; i++) {
        document.getElementById('re' + i).style.display = 'none';
        document.getElementById('a' + i + tabnames[i - 1]).src = "/CMENA-371/v4/uae/data/images/" + tabnames[i - 1] + "_normal.gif";
        document.getElementById('a' + i + tabnames[i - 1]).parentNode.style.cursor = "pointer";
    }
    document.getElementById('re' + img).style.display = 'block';
    document.getElementById(id).src = "/CMENA-371/v4/uae/data/images/" + tabnames[img - 1] + "_over.gif";
    document.getElementById(id).parentNode.style.cursor = "default";
}

function show_list_product() {
    if ($('#offerselect').val() == 1) {
        $('.Shopping,.HotelTravel,.BeautyHealth,.Others').hide();
        $('.Shopping,.HotelTravel,.BeautyHealth,.Others').fadeIn('slow');
    }
    if ($('#offerselect').val() == 2) {
        $('.Shopping,.HotelTravel,.BeautyHealth,.Others').hide();
        $('.Shopping').fadeIn('slow');
    }
    if ($('#offerselect').val() == 3) {
        $('.Shopping,.HotelTravel,.BeautyHealth,.Others').hide();
        $('.HotelTravel').fadeIn('slow');
    }
    if ($('#offerselect').val() == 4) {
        $('.Shopping,.HotelTravel,.BeautyHealth,.Others').hide();
        $('.BeautyHealth').fadeIn('slow');
    }
    if ($('#offerselect').val() == 5) {
        $('.Shopping,.HotelTravel,.BeautyHealth,.Others').hide();
        $('.Others').fadeIn('slow');
    }
}

	var excuted = false;
	 $(document).ready(function() {
     var homepageurls = location.href;
     var leftAnimate = {
         "CreditCards": "85",
         "ReadyCredit": "150",
         "Global": "205",
         "Investments": "273",
         "Insurance": "348",
         "Citigold": "415",
         "Citigold-Private-Clients": "516",
         "Global-corporate-banking": "612",
         "onlinebanking": "695"

     };

$(window).load (function(){
    setTimeout(function() {
        $(".listNavMarketing li").each(function() {
            /* $("a", this).on('click.fndtn', function(e) { */
			$("a", this).on('mouseenter click', function(e) {
                var headerid = e.target.id;
                var object = $(this);
                if ($(".activeSubMenu").size() > 0) {
                    $(".mnuSubCnt").slideUp("slow", function() {
                        $(".activeSubMenu").stop(false, false).slideUp("slow", function() {
                            showMegaMenu($(object));
                        }).removeClass("activeSubMenu").parents("li").removeClass("active");
                    });
                } else
                    showMegaMenu($(this));
                if ((heaadshow1 == 1 && headerid == 'topMnubanking') || (heaadshow2 == 1 && headerid == 'topMnucorporate') || (heaadshow3 == 1 && headerid == 'topMnucreditcard') || (heaadshow4 == 1 && headerid == 'topMnureadyCredit') || (heaadshow5 == 1 && headerid == 'topMnuinsurance') || (heaadshow6 == 1 && headerid == 'topcredit_cards') || (heaadshow7 == 1 && headerid == 'topMnuservices') || (heaadshow8 == 1 && headerid == 'topMnuglobal') || (heaadshow9 == 1 && headerid == 'topMnucitigold') || (heaadshow10 == 1 && headerid == 'topciti_at_work')) {
                    if (!$('.top-Navigation').parents(".top-Navigation").hasClass("top-Navigation")) {
                        /* $(".mmSubArrow").hide();
                        $(".activeMMenu").animate({
                            "top": "-250px"
                        }, 500, function() {
                            $(".megaMenuCnt").css({
                                "height": "0"
                            });
                            headermenuhighlight()
                        })
                        $(".activeMMenu").removeClass("activeMMenu");
                        $(".activeTab").removeClass("activeTab");
                        var mainlocurl = location.href; */
                    }
                    heaadshow11 = 1;
                    heaadshow21 = 1;
                    heaadshow31 = 1;
                    heaadshow41 = 1;
                    heaadshow51 = 1;
                    heaadshow61 = 1;
                    heaadshow71 = 1;
                    heaadshow81 = 1;
                    heaadshow91 = 1;
                }
                if (headerid == 'topMnubanking') {
                    if (heaadshow11 == 1) {
                        heaadshow1 = 0;
                        heaadshow2 = 0;
                        heaadshow3 = 0;
                        heaadshow4 = 0;
                        heaadshow5 = 0;
                        heaadshow6 = 0;
                        heaadshow7 = 0;
                        heaadshow8 = 0;
                        heaadshow9 = 0;
                        heaadshow10 = 0;
                    }
                    if (heaadshow11 == 0) {
                        heaadshow1 = 1;
                        heaadshow2 = 0;
                        heaadshow3 = 0;
                        heaadshow4 = 0;
                        heaadshow5 = 0;
                        heaadshow6 = 0;
                        heaadshow7 = 0;
                        heaadshow8 = 0;
                        heaadshow9 = 0;
                        heaadshow10 = 0;
                    }
                }
                if (headerid == 'topMnucorporate') {
                    if (heaadshow21 == 1) {
                        heaadshow1 = 0;
                        heaadshow2 = 0;
                        heaadshow3 = 0;
                        heaadshow4 = 0;
                        heaadshow5 = 0;
                        heaadshow6 = 0;
                        heaadshow7 = 0;
                        heaadshow8 = 0;
                        heaadshow9 = 0;
                        heaadshow10 = 0;
                    }
                    if (heaadshow21 == 0) {
                        heaadshow1 = 0;
                        heaadshow2 = 1;
                        heaadshow3 = 0;
                        heaadshow4 = 0;
                        heaadshow5 = 0;
                        heaadshow6 = 0;
                        heaadshow7 = 0;
                        heaadshow8 = 0;
                        heaadshow9 = 0;
                        heaadshow10 = 0;
                    }
                }
                if (headerid == 'topMnucreditcard') {
                    if (heaadshow31 == 1) {
                        heaadshow1 = 0;
                        heaadshow2 = 0;
                        heaadshow3 = 0;
                        heaadshow4 = 0;
                        heaadshow5 = 0;
                        heaadshow6 = 0;
                        heaadshow7 = 0;
                        heaadshow8 = 0;
                        heaadshow9 = 0;
                        heaadshow10 = 0;
                    }
                    if (heaadshow31 == 0) {
                        heaadshow1 = 0;
                        heaadshow2 = 0;
                        heaadshow3 = 1;
                        heaadshow4 = 0;
                        heaadshow5 = 0;
                        heaadshow6 = 0;
                        heaadshow7 = 0;
                        heaadshow8 = 0;
                        heaadshow9 = 0;
                        heaadshow10 = 0;
                    }
                }
                if (headerid == 'topMnureadyCredit') {
                    if (heaadshow41 == 1) {
                        heaadshow1 = 0;
                        heaadshow2 = 0;
                        heaadshow3 = 0;
                        heaadshow4 = 0;
                        heaadshow5 = 0;
                        heaadshow6 = 0;
                        heaadshow7 = 0;
                        heaadshow8 = 0;
                        heaadshow9 = 0;
                        heaadshow10 = 0;
                    }
                    if (heaadshow41 == 0) {
                        heaadshow1 = 0;
                        heaadshow2 = 0;
                        heaadshow3 = 0;
                        heaadshow4 = 1;
                        heaadshow5 = 0;
                        heaadshow6 = 0;
                        heaadshow7 = 0;
                        heaadshow8 = 0;
                        heaadshow9 = 0;
                        heaadshow10 = 0;
                    }
                }
                if (headerid == 'topMnuinsurance') {
                    if (heaadshow51 == 1) {
                        heaadshow1 = 0;
                        heaadshow2 = 0;
                        heaadshow3 = 0;
                        heaadshow4 = 0;
                        heaadshow5 = 0;
                        heaadshow6 = 0;
                        heaadshow7 = 0;
                        heaadshow8 = 0;
                        heaadshow9 = 0;
                        heaadshow10 = 0;
                    }
                    if (heaadshow51 == 0) {
                        heaadshow1 = 0;
                        heaadshow2 = 0;
                        heaadshow3 = 0;
                        heaadshow4 = 0;
                        heaadshow5 = 1;
                        heaadshow6 = 0;
                        heaadshow7 = 0;
                        heaadshow8 = 0;
                        heaadshow9 = 0;
                        heaadshow10 = 0;
                    }
                }
                if (headerid == 'topcredit_cards') {
                    if (heaadshow61 == 1) {
                        heaadshow1 = 0;
                        heaadshow2 = 0;
                        heaadshow3 = 0;
                        heaadshow4 = 0;
                        heaadshow5 = 0;
                        heaadshow6 = 0;
                        heaadshow7 = 0;
                        heaadshow8 = 0;
                        heaadshow9 = 0;
                        heaadshow10 = 0;
                    }
                    if (heaadshow61 == 0) {
                        heaadshow1 = 0;
                        heaadshow2 = 0;
                        heaadshow3 = 0;
                        heaadshow4 = 0;
                        heaadshow5 = 0;
                        heaadshow6 = 1;
                        heaadshow7 = 0;
                        heaadshow8 = 0;
                        heaadshow9 = 0;
                        heaadshow10 = 0;
                    }
                }
                if (headerid == 'topMnuservices') {
                    if (heaadshow71 == 1) {
                        heaadshow1 = 0;
                        heaadshow2 = 0;
                        heaadshow3 = 0;
                        heaadshow4 = 0;
                        heaadshow5 = 0;
                        heaadshow6 = 0;
                        heaadshow7 = 0;
                        heaadshow8 = 0;
                        heaadshow9 = 0;
                        heaadshow10 = 0;
                    }
                    if (heaadshow71 == 0) {
                        heaadshow1 = 0;
                        heaadshow2 = 0;
                        heaadshow3 = 0;
                        heaadshow4 = 0;
                        heaadshow5 = 0
                        heaadshow6 = 0;
                        heaadshow7 = 1;
                        heaadshow8 = 0;
                        heaadshow9 = 0;
                        heaadshow10 = 0;
                    }
                }
                if (headerid == 'topMnuglobal') {
                    if (heaadshow81 == 1) {
                        heaadshow1 = 0;
                        heaadshow2 = 0;
                        heaadshow3 = 0;
                        heaadshow4 = 0;
                        heaadshow5 = 0;
                        heaadshow6 = 0;
                        heaadshow7 = 0;
                        heaadshow8 = 0;
                        heaadshow9 = 0;
                        heaadshow10 = 0;
                    }
                    if (heaadshow81 == 0) {
                        heaadshow1 = 0;
                        heaadshow2 = 0;
                        heaadshow3 = 0;
                        heaadshow4 = 0;
                        heaadshow5 = 0
                        heaadshow6 = 0;
                        heaadshow7 = 0;
                        heaadshow8 = 1;
                        heaadshow9 = 0;
                        heaadshow10 = 0;
                    }
                }
                if (headerid == 'topMnucitigold') {
                    if (heaadshow81 == 1) {
                        heaadshow1 = 0;
                        heaadshow2 = 0;
                        heaadshow3 = 0;
                        heaadshow4 = 0;
                        heaadshow5 = 0;
                        heaadshow6 = 0;
                        heaadshow7 = 0;
                        heaadshow8 = 0;
                        heaadshow9 = 0;
                        heaadshow10 = 0;
                    }
                    if (heaadshow81 == 0) {
                        heaadshow1 = 0;
                        heaadshow2 = 0;
                        heaadshow3 = 0;
                        heaadshow4 = 0;
                        heaadshow5 = 0
                        heaadshow6 = 0;
                        heaadshow7 = 0;
                        heaadshow8 = 0;
                        heaadshow9 = 1;
                        heaadshow10 = 0;
                    }
                }
                if (headerid == 'topMnucitigold') {
                    if (heaadshow81 == 1) {
                        heaadshow1 = 0;
                        heaadshow2 = 0;
                        heaadshow3 = 0;

                        heaadshow4 = 0;
                        heaadshow5 = 0;
                        heaadshow6 = 0;
                        heaadshow7 = 0;
                        heaadshow8 = 0;
                        heaadshow9 = 0;
                        heaadshow10 = 0;
                    }
                    if (heaadshow81 == 0) {
                        heaadshow1 = 0;
                        heaadshow2 = 0;
                        heaadshow3 = 0;
                        heaadshow4 = 0;
                        heaadshow5 = 0
                        heaadshow6 = 0;
                        heaadshow7 = 0;
                        heaadshow8 = 0;
                        heaadshow9 = 1;
                        heaadshow10 = 0;
                    }
                }
                if (headerid == 'topciti_at_work') {
                    if (heaadshow81 == 1) {
                        heaadshow1 = 0;
                        heaadshow2 = 0;
                        heaadshow3 = 0;
                        heaadshow4 = 0;
                        heaadshow5 = 0;
                        heaadshow6 = 0;
                        heaadshow7 = 0;
                        heaadshow8 = 0;
                        heaadshow9 = 0;
                        heaadshow10 = 0;
                    }
                    if (heaadshow81 == 0) {
                        heaadshow1 = 0;
                        heaadshow2 = 0;
                        heaadshow3 = 0;
                        heaadshow4 = 0;
                        heaadshow5 = 0
                        heaadshow6 = 0;
                        heaadshow7 = 0;
                        heaadshow8 = 0;
                        heaadshow9 = 0;
                        heaadshow10 = 1;
                    }
                }
                if (headerid == 'topcommercialbank') {
                    if (heaadshow91 == 1) {
                        heaadshow1 = 0;
                        heaadshow2 = 0;
                        heaadshow3 = 0;
                        heaadshow4 = 0;
                        heaadshow5 = 0;
                        heaadshow6 = 0;
                        heaadshow7 = 0;
                        heaadshow8 = 0;
                        heaadshow9 = 0;
                        heaadshow10 = 0;
                    }
                    if (heaadshow91 == 0) {
                        heaadshow1 = 0;
                        heaadshow2 = 0;
                        heaadshow3 = 0;
                        heaadshow4 = 0;
                        heaadshow5 = 0
                        heaadshow6 = 0;
                        heaadshow7 = 0;
                        heaadshow8 = 0;
                        heaadshow9 = 0;
                        heaadshow10 = 0;
                    }
                }
                if ($(this).hasClass('megamenuHide')) {
                    $('.mmSubArrow').css('display', 'none');
                }
            })
        })
        $(".listNavMarketing li a").mouseover(function(e) {
            if ($('.activeMMenu').size() > 0) {
                showMegaMenu($(this));
                var headerid1 = e.target.id;
                if (headerid1 == 'topMnubanking') {
                    heaadshow1 = 1;
                    heaadshow2 = 0;
                    heaadshow3 = 0;
                    heaadshow4 = 0;
                    heaadshow5 = 0;
                    heaadshow6 = 0;
                    heaadshow7 = 0;
                    heaadshow8 = 0;
                    heaadshow9 = 0;
                }
                if (headerid1 == 'topMnuinvestments') {
                    heaadshow1 = 0;
                    heaadshow2 = 1;
                    heaadshow3 = 0;
                    heaadshow4 = 0;
                    heaadshow5 = 0;
                    heaadshow6 = 0;
                    heaadshow7 = 0;
                    heaadshow8 = 0;
                    heaadshow9 = 0;
                }
                if (headerid1 == 'topMnucreditcard') {
                    heaadshow1 = 0;
                    heaadshow2 = 0;
                    heaadshow3 = 1;
                    heaadshow4 = 0;
                    heaadshow5 = 0;
                    heaadshow6 = 0;
                    heaadshow7 = 0;
                    heaadshow8 = 0;
                    heaadshow9 = 0;
                }
                if (headerid1 == 'topMnureadyCredit') {
                    heaadshow1 = 0;
                    heaadshow2 = 0;
                    heaadshow3 = 0;
                    heaadshow4 = 1;
                    heaadshow5 = 0;
                    heaadshow6 = 0;
                    heaadshow7 = 0;
                    heaadshow8 = 0;
                    heaadshow9 = 0;
                }
                if (headerid1 == 'topMnuinsurance') {
                    heaadshow1 = 0;
                    heaadshow2 = 0;
                    heaadshow3 = 0;
                    heaadshow4 = 0;
                    heaadshow5 = 1;
                    heaadshow6 = 0;
                    heaadshow7 = 0;
                    heaadshow8 = 0;
                    heaadshow9 = 0;
                }
                if (headerid1 == 'topMnucommercialBank') {
                    heaadshow1 = 0;
                    heaadshow2 = 0;
                    heaadshow3 = 0;
                    heaadshow4 = 0;
                    heaadshow5 = 0;
                    heaadshow6 = 1;
                    heaadshow7 = 0;
                    heaadshow8 = 0;
                    heaadshow9 = 0;
                }
                if (headerid1 == 'topMnuservices') {
                    heaadshow1 = 0;
                    heaadshow2 = 0;
                    heaadshow3 = 0;
                    heaadshow4 = 0;
                    heaadshow5 = 0;
                    heaadshow6 = 0;
                    heaadshow7 = 1;
                    heaadshow8 = 0;
                    heaadshow9 = 0;
                }
                if (headerid1 == 'topMnuglobal') {
                    heaadshow1 = 0;
                    heaadshow2 = 0;
                    heaadshow3 = 0;
                    heaadshow4 = 0;
                    heaadshow5 = 0;
                    heaadshow6 = 0;
                    heaadshow7 = 0;
                    heaadshow8 = 1;
                    heaadshow9 = 0;
                }
                if (headerid1 == 'topMnucitigold') {
                    heaadshow1 = 0;
                    heaadshow2 = 0;
                    heaadshow3 = 0;
                    heaadshow4 = 0;
                    heaadshow5 = 0;
                    heaadshow6 = 0;
                    heaadshow7 = 0;
                    heaadshow8 = 0;
                    heaadshow9 = 1;
                }
            }
            if ($(this).hasClass('megamenuHide')) {
                $('.mmSubArrow').css('display', 'none');
            }
        })
        $(".top-Navigation").mouseleave(function() {
            heaadshow11 = 0;
            heaadshow21 = 0;
            heaadshow31 = 0;
            heaadshow41 = 0;
            heaadshow51 = 0;
            heaadshow61 = 0;
            heaadshow71 = 0;
            heaadshow81 = 0;
            heaadshow1 = 0;
            heaadshow2 = 0;
            heaadshow3 = 0;
            heaadshow4 = 0;
            heaadshow5 = 0;
            heaadshow6 = 0;
            heaadshow7 = 0;
            heaadshow8 = 0;
        })
    }, 1000);
	});

    function showMegaMenu(object) {
        $(".mmSubArrow").hide();
        $(".activeTab").removeClass("activeTab");
        var rel = $(object).addClass('activeTab').attr("class").split(' ')[0];
        if ($('.activeMMenu').size() > 0) {
            $(".activeMMenu").hide();
            $(".activeMMenu").css('top', "-250px");
            $(object).removeClass("activeMMenu");
            $(".activeTab").removeClass("activeTab");
            $(object).addClass('activeTab');
            $(".megaMenuCnt").css({
                "height": "500px"
            }).promise().done(function() {
                $("#" + rel).addClass('activeMMenu').css("top", "0");
                $("#" + rel).show();
                $(".mmSubArrow").show();
            })
            $(".mmSubArrow").stop(true, false).animate({
                "left": leftAnimate[rel]
            }, 500, function() {
                $(".mmSubArrow").show();
            });
        } else {
            $(".megaMenuCnt").css({
                "height": "500px"
            }).promise().done(function() {
                $("#" + rel).addClass('activeMMenu').animate({
                    "top": "0"
                }, 500, function() {
                    $(".mmSubArrow").show();
                })
                $("#" + rel).show();
            })
            $(".mmSubArrow").css({
                "left": leftAnimate[rel] + "px"
            });
        }
        heaadshow11 = 0;
        heaadshow21 = 0;
        heaadshow31 = 0;
        heaadshow41 = 0;
        heaadshow51 = 0;
        heaadshow61 = 0;
        heaadshow71 = 0;
        heaadshow81 = 0;
    }
    setTimeout(function() {
        $(".listQuickLinks li a, .listNavSignOn li a").on("click.fndtn", function() {
            var parent = $(this).parent().find("div.ratesFlyout");
            var object = $(this);
            parent.clearQueue();
            parent.stop();
            $(this).stop();
            if ($(".activeMMenu").size() > 0) {
                $(".activeMMenu").stop(false, false).animate({
                    "top": "-250px"
                }, 500, function() {
                    $(this).removeClass("activeMMenu");
                    $(".megaMenuCnt").css({
                        "height": "0"
                    });
                    $(".activeTab").removeClass("activeTab");
                    headermenuhighlight();
                    if ($(".activeSubMenu").size() > 0) {
                        if (excuted == true) return false;
                        parent.stop();
                        $(".mnuSubCnt").slideUp("slow", function() {
                            flagDispaly = $(parent).css("display");
                            $(".activeSubMenu").stop(false, false).slideUp('slow', function() {
                                if (flagDispaly != "block") {
                                    parent.addClass("activeSubMenu").stop(false, false).slideToggle(function() {
                                        $(".mnuSubCnt", parent).slideDown("slow");
                                        $(this).next("css3-container").show();
                                    }).parents("li").addClass("active");
                                }
                            }).removeClass("activeSubMenu").parents("li").removeClass("active");
                        })
                    } else {
                        if (object.parent().find("div.ratesFlyout")) {
                            $(".mnuSubCnt", parent).slideUp("slow");
                            parent.addClass("activeSubMenu").stop(false, false).slideDown(function() {
                                $(".mnuSubCnt", parent).slideDown("slow");
                                $(this).next("css3-container").show();
                            }).parents("li").addClass("active");
                            excuted = true;
                        }
                    }
                });
            } else {
                if ($(".activeSubMenu").size() > 0) {
                    $(".mnuSubCnt").slideUp("slow", function() {
                        flagDispaly = $(parent).css("display");
                        $(".activeSubMenu").stop(false, false).slideUp(100, function() {
                            if (flagDispaly != "block") {
                                parent.addClass("activeSubMenu").stop(false, false).slideToggle(function() {
                                    $(".mnuSubCnt", parent).slideDown(100);
                                    $(this).next("css3-container").show();
                                }).parents("li").addClass("active");
                            }
                        }).removeClass("activeSubMenu").parents("li").removeClass("active");
                    })
                } else {
                    if ($(this).parent().find("div.ratesFlyout")) {
                        $(".mnuSubCnt", parent).slideUp(0);
                        parent.addClass("activeSubMenu").stop(false, false).slideToggle(function() {
                            $(".mnuSubCnt", parent).slideDown(100);
                            $(this).next("css3-container").show();
                        }).parents("li").addClass("active");
                    }
                }
            }
        })
        var mainlocurl1 = location.href;
        if (mainlocurl1.indexOf('/Konta/') != -1) {
            $('#topMnuinvestments').addClass('activeTab')
        }
        if (mainlocurl1.indexOf('/Ubezpieczenia/') != -1) {
            $('#topMnureadyCredit').addClass('activeTab')
        }
        if (mainlocurl1.indexOf('/mortgages/') != -1) {
            $('#topMnucreditcard').addClass('activeTab')
        }
        if (mainlocurl1.indexOf('/Korzysci_i_Przywileje/') != -1) {
            $('#topMnubanking').addClass('activeTab')
        }
        if (mainlocurl1.indexOf('/insurance/') != -1) {
            $('#topMnuinsurance').addClass('activeTab')
        }
        if (mainlocurl1.indexOf('/consumer/') != -1) {
            if (mainlocurl1.indexOf('/credit_cards/') != -1) {
                $('#topcredit_cards').addClass('activeTab')
            }
        }
        if (mainlocurl1.indexOf('/index/') != -1) {
            if (mainlocurl1.indexOf('/index.htm') != -1) {
                $('#tophome').addClass('activeTab')
            }
        }
        var mainlocurl = location.href;
        if (mainlocurl.indexOf('/corporate/') != -1) {
            if (mainlocurl.indexOf('/markets_banking/') != -1) {
                $('#topMnucorporate').addClass('activeTab')
            }
        }
        if (mainlocurl.indexOf('/commercial/') != -1) {
            if (mainlocurl.indexOf('/commercial_banking/') != -1) {
                $('#topMnucorporate').addClass('activeTab')
            }
        }
        if (mainlocurl.indexOf('/consumer/') != -1) {
            if (mainlocurl.indexOf('/personal_account/') != -1) {
                $('#topMnuglobal').addClass('activeTab')
            }
        }
        if (mainlocurl1.indexOf('/citigold/introduction/') != -1) {
            $('#topMnucitigold').addClass('activeTab')
        }
        if (mainlocurl1.indexOf('/citigold/citigold_private_client/') != -1) {
            $('#topMnucpc').addClass('activeTab')
        }
        if (mainlocurl1.indexOf('/citigold/homepage/index.htm') != -1) {
            $('#tophome').addClass('activeTab')
        }
        if (mainlocurl1.indexOf('/citigold/forms/') != -1) {
            $('#topMnucitigold').addClass('activeTab')
        }
        if (mainlocurl.indexOf('/offshore/') != -1) {
            if (mainlocurl.indexOf('/international_personal_banking/') != -1) {
                $('#topMnuglobal').addClass('activeTab')
            }
        }
        if (mainlocurl.indexOf('/consumer/') != -1) {
            if (mainlocurl.indexOf('/personal_account/') != -1) {
                $('#topMnuglobal').addClass('activeTab')
            }
        }
        if (mainlocurl.indexOf('/consumer/') != -1) {
            $(".activeTab").removeClass("activeTab");
            if (mainlocurl.indexOf('/citi_at_work/') != -1) {
                $('#topMnucorporate').addClass('activeTab')
            }
            if (mainlocurl.indexOf('/mortgages/') != -1) {
                $('#topMnucreditcard').addClass('activeTab')
            }
            if (mainlocurl.indexOf('/forms/') != -1) {
                if (mainlocurl.indexOf('/contact_form.htm') != -1) {
                    $('#topMnubanking').removeClass('activeTab')
                }
                if (mainlocurl.indexOf('/citi_at_work/') != -1) {
                    $('#topMnucorporate').addClass('activeTab')
                }
                if (mainlocurl.indexOf('/consumer/') != -1) {
                    if (mainlocurl.indexOf('/personal_account/') != -1) {
                        $('#topMnuglobal').addClass('activeTab')
                    }
                }
                if (mainlocurl.indexOf('/golf_reserve_form.htm') != -1) {
                    $('#topMnubanking').removeClass('activeTab')
                }
                if (mainlocurl.indexOf('/suppl_card_form.htm') != -1) {
                    $('#topMnubanking').removeClass('activeTab')
                }
            }
            if (mainlocurl.indexOf('/loans/') != -1) {
                $('#topMnubanking').addClass('activeTab')
            }
            if (mainlocurl.indexOf('/investment_treasury/') != -1) {
                $('#topMnureadyCredit').addClass('activeTab')
            }
            if (mainlocurl.indexOf('/reach_us/') != -1) {
                $('#topMnucommercialBank').addClass('activeTab')
            }
            if (mainlocurl.indexOf('/Benefits_and_Privileges/') != -1) {
                $('#topMnubanking').addClass('activeTab')
            }
            if (mainlocurl.indexOf('/mortgages/') != -1) {
                $('#topMnucreditcard').addClass('activeTab')
            }
            if (mainlocurl.indexOf('/Insurance/') != -1) {
                $('#topMnureadyCredit').addClass('activeTab')
            }
            if (mainlocurl.indexOf('/insurance/') != -1) {
                $('#topMnuinsurance').addClass('activeTab')
            }
            if (mainlocurl1.indexOf('/consumer/') != -1) {
                if (mainlocurl1.indexOf('/credit_cards/') != -1) {
                    $('#topcredit_cards').addClass('activeTab')
                }
            }
            if (mainlocurl.indexOf('/Global_Banking/') != -1) {
                $('#topMnuglobal').addClass('activeTab')
            }
            if (mainlocurl.indexOf('/consumer/') != -1) {
                if (mainlocurl.indexOf('/personal_account/') != -1) {
                    $('#topMnuglobal').addClass('activeTab')
                }
            }
            if (mainlocurl.indexOf('/Main/') != -1) {
                if (mainlocurl.indexOf('/Rozwiazania_walutowe.htm') != -1) {
                    $('#topMnucommercialBank').addClass('activeTab')
                }
            }
        }
        if (mainlocurl.indexOf('/corporate/') != -1) {
            if (mainlocurl.indexOf('/markets_banking/') != -1) {
                $('#topMnucorporate').addClass('activeTab')
            }
        }
        $("body").click(function(e) {
            if (!$(e.target).parents().hasClass("levels") && e.target.id != 'drop1' && e.target.id != 'ddrop1' && e.target.id != 'ddrop2') {
               /* $('.levels').slideUp();*/
                menuopen = 0;
                $('#menu-icon-point').removeClass("menu-icon-point-active");
                if ($('.show-down').hasClass('show')) {}
            }
            if (!$(e.target).parents().hasClass("drop") && !$(e.target).parents().hasClass("right") && !$(e.target).parents().hasClass("searchMobWrap")) {
               /* $('.searchMobWrap').slideUp();*/
                $('.searchMobWrap').removeClass('active');
                $('#search-icon').removeClass('menu-icon-point-active');
            }
            if (!$(e.target).hasClass("imp-icon") && !$(e.target).parents().hasClass("dropdown") && !$(e.target).hasClass("imp-txt")) {
                $('.dropdown').slideUp();
                $('.mob-impLinks').removeClass('imptextopen');
                menuopen = 0;
            }
            if (!$(e.target).hasClass("left-nav-icon") && !$(e.target).parents().hasClass("sub")) {
                $('.maniul').slideUp();
            }
            if (!$(e.target).hasClass("left-nav-icon") && !$(e.target).parents().hasClass("maniul hidden") && !$(e.target).hasClass("sub")) {
                $('.maniul hidden').slideUp();
            }
            if (!$(e.target).parents().hasClass("h-view")) {
                $('.RatesFlyOut2').slideUp();
                $('#location').removeClass('closeactive')
            }
            if (e.target.id != 'rates') {
                $('#ratesFlyout').slideUp();
                $('#rates').removeClass('closeactive')
            }
            if (e.target.id != 'location') {}
            if (e.target.id != 'contact') {
                $('#ratesFlyout3').slideUp();
                $('#contact').removeClass('closeactive')
            }
            if (e.target.id != 'sbSelector_18361260') {
                $('#sbOptions_18361260').slideUp();
            }
            if (e.target.id != 'sbSelector_183612601') {
                $('#sbOptions_183612601').slideUp();
            }
            if (!$(e.target).parents().hasClass("stoppropagation")) {
                $('.mmSubArrow ').hide();
                /* $(".activeMMenu").animate({
                    "top": "-250px"
                }, 1000, function() {
                    $(this).removeClass("activeMMenu");
                    $(".megaMenuCnt").css({
                        "height": "0"
                    })
                    headermenuhighlight();
                }) */
                var mainlocurl = location.href;
                $(".activeTab").removeClass("activeTab");
                if (mainlocurl.indexOf('/main/homepage/') != -1) {
                    if (mainlocurl.indexOf('/Rozwiazania_walutowe.htm') != -1) {
                        $('#topMnucommercialBank').addClass('activeTab')
                    }
                    if (mainlocurl.indexOf('/index.htm') != -1) {
                        $('#tophome').addClass('activeTab')
                    }
                }
                if (mainlocurl1.indexOf('/Konta/') != -1) {
                    $('#topMnuinvestments').addClass('activeTab')
                }
                if (mainlocurl1.indexOf('/Ubezpieczenia/') != -1) {
                    $('#topMnureadyCredit').addClass('activeTab')
                }
                if (mainlocurl1.indexOf('/mortgages/') != -1) {
                    $('#topMnucreditcard').addClass('activeTab')
                }
                if (mainlocurl1.indexOf('/Korzysci_i_Przywileje/') != -1) {
                    $('#topMnubanking').addClass('activeTab')
                }
                if (mainlocurl1.indexOf('/insurance/') != -1) {
                    $('#topMnuinsurance').addClass('activeTab')
                }
                if (mainlocurl1.indexOf('/consumer/') != -1) {
                    if (mainlocurl1.indexOf('/credit_cards/') != -1) {
                        $('#topcredit_cards').addClass('activeTab')
                    }
                }
                if (mainlocurl.indexOf('/Globalna_bankowosc/') != -1) {
                    $('#topMnuglobal').addClass('activeTab')
                }
                if (mainlocurl.indexOf('/consumer/') != -1) {
                    if (mainlocurl.indexOf('/personal_account/') != -1) {
                        $('#topMnuglobal').addClass('activeTab')
                    }
                }
                if (mainlocurl.indexOf('homepage/') != -1) {
                    if (mainlocurl.indexOf('/Rozwiazania_walutowe.htm') != -1) {
                        $('#topMnucommercialBank').addClass('activeTab')
                    }
                    if (mainlocurl.indexOf('/index.htm') != -1) {
                        $('#tophome').addClass('activeTab')
                    }
                }
                if (mainlocurl.indexOf('/corporate/') != -1) {
                    if (mainlocurl.indexOf('/markets_banking/') != -1) {
                        $('#topMnucorporate').addClass('activeTab')
                    }
                }
                if (mainlocurl.indexOf('/introduction/') != -1) {
                    if (mainlocurl.indexOf('/video.htm') != -1) {
                        $('#topcredit_cards').addClass('activeTab')
                    }
                }
                if (mainlocurl.indexOf('/commercial/') != -1) {
                    if (mainlocurl.indexOf('/commercial_banking/') != -1) {
                        $('#topMnucorporate').addClass('activeTab')
                    }
                }
                if (mainlocurl.indexOf('/consumer/') != -1) {
                    if (mainlocurl.indexOf('/personal_account/') != -1) {
                        $('#topMnuglobal').addClass('activeTab')
                    }
                }
                if (mainlocurl.indexOf('/citigold_private_client/') != -1) {
                    $('#topMnucpc').addClass('activeTab')
                }
                if (mainlocurl.indexOf('/offshore/') != -1) {
                    if (mainlocurl.indexOf('/international_personal_banking/') != -1) {
                        $('#topMnuglobal').addClass('activeTab')
                    }
                }
                if (mainlocurl.indexOf('/consumer/') != -1) {
                    if (mainlocurl.indexOf('/personal_account/') != -1) {
                        $('#topMnuglobal').addClass('activeTab')
                    }
                }
                if (mainlocurl.indexOf('/consumer/') != -1) {
                    if (mainlocurl.indexOf('/citi_at_work/') != -1) {
                        $('#topMnucorporate').addClass('activeTab')
                    }
                    if (mainlocurl.indexOf('/corporate/') != -1) {
                        if (mainlocurl.indexOf('/markets_banking/') != -1) {
                            $('#topMnucorporate').addClass('activeTab')
                        }
                    }
                    if (mainlocurl.indexOf('/mortgages/') != -1) {
                        $('#topMnucreditcard').addClass('activeTab')
                    }
                    if (mainlocurl.indexOf('/forms/') != -1) {
                        if (mainlocurl.indexOf('/consumer/') != -1) {
                            if (mainlocurl.indexOf('/personal_account/') != -1) {
                                $('#topMnuglobal').addClass('activeTab')
                            }
                        }
                        if (mainlocurl.indexOf('/citi_at_work/') != -1) {
                            $('#topMnucorporate').addClass('activeTab')
                        }
                        if (mainlocurl.indexOf('/consumer/') != -1) {
                            if (mainlocurl.indexOf('/personal_account/') != -1) {
                                $('#topMnuglobal').addClass('activeTab')
                            }
                        }
                        if (mainlocurl.indexOf('/contact_form.htm') != -1) {
                            $('#topMnubanking').removeClass('activeTab')
                        }
                        if (mainlocurl.indexOf('/golf_reserve_form.htm') != -1) {
                            $('#topMnubanking').removeClass('activeTab')
                        }
                        if (mainlocurl.indexOf('/suppl_card_form.htm') != -1) {
                            $('#topMnubanking').removeClass('activeTab')
                        }
                    }
                    if (mainlocurl.indexOf('/loans/') != -1) {
                        $('#topMnubanking').addClass('activeTab')
                    }
                    if (mainlocurl.indexOf('/reach_us/') != -1) {
                        $('#topMnucommercialBank').addClass('activeTab')
                    }
                    if (mainlocurl.indexOf('/investment_treasury/') != -1) {
                        $('#topMnureadyCredit').addClass('activeTab')
                    }
                    if (mainlocurl.indexOf('/Benefits_and_Privileges/') != -1) {
                        $('#topMnubanking').addClass('activeTab')
                    }
                    if (mainlocurl.indexOf('/mortgages/') != -1) {
                        $('#topMnucreditcard').addClass('activeTab')
                    }
                    if (mainlocurl.indexOf('/Insurance/') != -1) {
                        $('#topMnureadyCredit').addClass('activeTab')
                    }
                    if (mainlocurl.indexOf('/insurance/') != -1) {
                        $('#topMnuinsurance').addClass('activeTab')
                    }
                    if (mainlocurl1.indexOf('/consumer/') != -1) {
                        if (mainlocurl1.indexOf('/credit_cards/') != -1) {
                            $('#topcredit_cards').addClass('activeTab')
                        }
                    }
                    if (mainlocurl.indexOf('/Global_Banking/') != -1) {
                        $('#topMnuglobal').addClass('activeTab')
                    }
                    if (mainlocurl.indexOf('/consumer/') != -1) {
                        if (mainlocurl.indexOf('/personal_account/') != -1) {
                            $('#topMnuglobal').addClass('activeTab')
                        }
                    }
                    if (mainlocurl.indexOf('/contact/') != -1) {
                        $('#topMnuservices').addClass('activeTab')
                    }
                }
                if (mainlocurl.indexOf('/insurance/') != -1) {
                    $('#topMnuinsurance').addClass('activeTab')
                }
                if (mainlocurl1.indexOf('/citigold/introduction/') != -1) {
                    $('#topMnucitigold').addClass('activeTab')
                }
                if (mainlocurl1.indexOf('/citigold/citigold_private_client/') != -1) {
                    $('#topMnucpc').addClass('activeTab')
                }
                if (mainlocurl1.indexOf('homepage/index.htm') != -1) {
                    $('#tophome').addClass('activeTab')
                }
                if (mainlocurl1.indexOf('/citigold/forms/') != -1) {
                    $('#topMnucitigold').addClass('activeTab')
                }
                if (mainlocurl1.indexOf('/consumer/') != -1) {
                    if (mainlocurl1.indexOf('/credit_cards/') != -1) {
                        $('#topcredit_cards').addClass('activeTab')
                    }
                }
                if (!$(e.target).parents().hasClass('BreadcrumbTxt') && $('ul.BreadcrumbNav').css('display') == "block")
                    $('ul.BreadcrumbNav').slideUp();
            }
            var mainlocurl = location.href;
            if (!$(e.target).parents().hasClass("stoppropagationQL")) {
                if ($(".activeSubMenu").size() > 0) {
                    $(".mnuSubCnt").slideUp("slow", function() {
                        $(".activeSubMenu").stop(false, false).slideUp().removeClass("activeSubMenu").parents("li").removeClass("active");
                    })
                }
            }
        })
    }, 500)
})
$(document).ready(function() {
    $('body').click(function(e) {
        if ($(e.target).attr('id') == 'menu-icon-search') {
            $('.searchMobWrap').slideToggle();
            $('#search-icon').toggleClass('menu-icon-point-active');
            $('.dropdown').fadeOut('slow')
            /*$('.levels').slideUp();*/
            if ($('.show-down').hasClass('show')) {}
        }
    });
    var xyz = location.href;
    if (xyz.indexOf("?") > 0) {
        var htmName = xyz.split('?')
        if (xyz.indexOf("&") > 0) {
            var getTab = htmName[1].split('&');
            var geteTabVal = getTab[0].substr(4, getTab.length + 1);
        } else {
            var geteTabVal = htmName[1].substr(4, htmName.length + 1);
        }
        if (geteTabVal != '') {
            var tabLength = $('#tablength').val();
            if (geteTabVal <= tabLength)
                tabrcnew('a' + geteTabVal + 'Tab', tabLength);
        }
    }
    var mainlocurl = location.href;
    $('#nav li a').click(function() {
        if (!$(this).parent().hasClass('leftliholder')) {
            $('.maniul').slideToggle('slow')
        }
    });
    $('.submainliNoLink').click(function() {
        $('.submainliNoLink ul').slideToggle('slow')
    });
    $('#mid-section,header').click(function() {
        $('.maniul').fadeOut('slow')
    })
    $('#section,.header-mob').click(function() {
        $('.searchMobWrap').removeClass('active')
        $('.visible-phone').removeClass('active')
        $('.dropdown').fadeOut('slow')
    })
    $('.imp-icon').click(function() {
        $('.searchMobWrap').removeClass('active')
        $('.searchMobWrap').slideUp();
        $('#search-icon').removeClass('menu-icon-point-active');
        $('#search-icon').removeClass('active')
        $('.dropdown').slideToggle('slow');
        $('.levels').slideUp();
        if ($('.show-down').hasClass('show')) {}
    })
    $('.imp-txt').click(function() {
        $('.dropdown').slideToggle('slow');
        $('.mob-impLinks').toggleClass('imptextopen');
        $('.levels').slideUp();
        if ($('.show-down').hasClass('show')) {}
    })
    $('.visible-phone').click(function() {})
    $('#nav ul li a').click(function() {
        if ($(this).parent().hasClass('leftliholder')) {
            $(this).next().slideToggle();
        }
    })
})

function showhide1(src, img) {
    var imgopen = '../../images/cta-arrow-dwn.png';
    var imgclose = '../../images/cta-arrow.png';
    if (document.getElementById(src).style.display == 'none') {
        document.getElementById(src).style.display = 'block';
        document.getElementById(img).src = imgopen;
        $('html, body').animate({
            scrollTop: $("#" + src).offset().top - 20
        }, 1000);
    } else {
        document.getElementById(src).style.display = 'none';
        document.getElementById(img).src = imgclose;
    }
}
$(document).ready(function() {
    $('#rates').click(function() {
        $('#ratesFlyout').slideToggle();
        $('#ratesFlyout2').slideUp();
        $('#ratesFlyout3').slideUp();
        $('#sbOptions_18361260').slideUp();
        $('#sbOptions_183612601').slideUp();
        $('#rates').toggleClass('closeactive')
        $('#location').removeClass('closeactive')
        $('#contact').removeClass('closeactive')
    })
    $('#location').click(function() {
        $('#ratesFlyout2').slideToggle();
        $('#ratesFlyout').slideUp();
        $('#ratesFlyout3').slideUp();
        $('#sbOptions_18361260').slideUp();
        $('#sbOptions_183612601').slideUp();
        $('#location').toggleClass('closeactive')
        $('#contact').removeClass('closeactive')
        $('#rates').removeClass('closeactive')
    })
    $('#contact').click(function() {
        $('#ratesFlyout3').slideToggle();
        $('#ratesFlyout2').slideUp();
        $('#ratesFlyout').slideUp();
        $('#sbOptions_18361260').slideUp();
        $('#sbOptions_183612601').slideUp();
        $('#contact').toggleClass('closeactive')
        $('#location').removeClass('closeactive')
        $('#rates').removeClass('closeactive')
    })
    $('#sbSelector_18361260').click(function() {
        $('#sbOptions_18361260').slideToggle();
        $('#ratesFlyout3').slideUp();
        $('#ratesFlyout2').slideUp();
        $('#ratesFlyout').slideUp();
        $('#sbOptions_183612601').slideUp();
    })
    $('#sbSelector_183612601').click(function() {
        $('#sbOptions_183612601').slideToggle();
        $('#sbOptions_18361260').slideUp();
        $('#ratesFlyout3').slideUp();
        $('#ratesFlyout2').slideUp();
        $('#ratesFlyout').slideUp();
    })
    $('#content').click(function() {
        $('#ratesFlyout3').slideUp();
        $('#ratesFlyout2').slideUp();
        $('#ratesFlyout').slideUp();
    })
})
$(document).ready(function() {
    var dd = $('.blue li').length;
    var dd1 = 0;
    var dd4 = $('.common-list-content').width();
    var dd5 = $('.common-list-content').width()
    var dd9 = $('.blue li:eq(0)').width()
    var ddleft = $('.blue').css('left')
    var dd7 = 0;
    for (var i = 0; i < dd; i++) {
        dd1 = dd1 + $('.blue li:eq(' + i + ')').width()
    }
    var clickwidth = 0;
    for (var i = 0; i < dd - 1; i++) {
        dd7 = dd7 + $('.blue li:eq(' + i + ')').width()
    }
    var fullwidth = 0;
    var fullwidth1 = 0;
    var fullwidth2 = 0;
    for (var d = 0; d <= dd - 1; d++) {
        fullwidth = $('.blue li:eq(' + d + ')').width() + parseInt($('.blue li:eq(' + d + ')').css('margin-left')) + parseInt($('.blue li:eq(' + d + ')').css('margin-right'));
        fullwidth2 = fullwidth + fullwidth2
    }
    var maxwidth = 0;
    for (var g = 1; g <= dd - 1; g++) {
        var f = g - 1
        if ($('.blue li:eq(' + f + ')').width() > $('.blue li:eq(' + g + ')').width()) {
            maxwidth = g
        }
    }
    var maxwidth1 = $('.blue li:eq(' + maxwidth + ')').width()
    var twoclick = 0;
    var twoclick1 = 0;
    var twoclick2 = 0;
    var kdclick = 0;
    var ddd1 = 0;
    var clickcount = 0
    var leftr1 = 0
    var arrowleftclickwidth = 0;
    var arrowleftclickwidth1 = 0;
    var arrowleftclickwidth2 = 0;
    var tableft = 0;
    var tableft1 = 0;
    var tableft2 = 0;
    var tableftreslt = 0;
    var lileftwidth = 0;
    var clickleftfind = 0;
    var clickleftfind1 = 0;
    var clickleftfindvar = 1;
    var clickleftfindvar1 = 0;
    var clickleftfindvar2 = 1;
    var clickleftfindvar3 = 0;
    var clickleftfindvar4 = 0;
    var clickleftfindvar5 = 0;
    var clickleftfindvar6 = 0;
    var arrowleftr = 0;
    var arrowleftr1 = 0;
    var arrowtableftreslt = 0
    var arrowtableft1 = 0;
    var arrowtableft2 = 0;
    var arrowleftclickwidth1 = 0;
    var arrowtableft = 0;
    if (fullwidth2 >= $('.common-list').width()) {
        if (dd > 0) {
            $('.tab-ipad-mover-left').hide();
            $('.tab-ipad-mover-right').show();
        }
    } else {
        $('.tab-ipad-mover-left').hide();
        $('.tab-ipad-mover-right').hide();
    }
    var dd3 = 0;
    var liwidth = $('.blue li:eq(0)').width()
    var clicktab = 0;
    $('.tab-ipad-mover-right').click(function() {
        setTimeout(function() {
            $('.blue li a').each(function() {
                if ($(this).hasClass("current")) {
                    liactive1 = $(this).parent().index() + 1
                }
            })
            $('.blue li a').removeClass('current')
            $('.common-list-content').css('display', 'none')
            $('.blue li a').eq(liactive1).addClass('current')
            $('#re' + (liactive1 + 1)).css('display', 'block')
            if ($('.blue').css('left') == 'auto') {
                $('.blue').css('left', '0')
            }
            clickcount = clickcount + 1;
            leftr1 = 0;
            if (liwidth != dd9) {
                twoclick = 1;
                twoclick1 = liwidth - dd9;
            }
            tableft = -(parseInt($('.blue').css('left')))
            for (var j = 0; j <= dd; j++) {
                var leftr = $('.blue li:eq(' + j + ')').width() + parseInt($('.blue li:eq(' + j + ')').css('margin-left')) + parseInt($('.blue li:eq(' + j + ')').css('margin-right'));
                leftr1 = leftr1 + leftr;
                if (tableft == 0) {
                    tableftreslt = 0
                } else {
                    if (tableft >= leftr1) {
                        tableftreslt = j + 1
                    }
                }
            }
            clicktab++
            tableft2 = 0;
            for (var d = 0; d <= tableftreslt; d++) {
                tableft1 = $('.blue li:eq(' + d + ')').width() + parseInt($('.blue li:eq(' + d + ')').css('margin-left')) + parseInt($('.blue li:eq(' + d + ')').css('margin-right'));
                tableft2 = tableft1 + tableft2
            }
            $(".blue").animate({
                left: -tableft2
            }, 10);
            $('.tab-ipad-mover-left').show();
            arrowleftclickwidth = 0;
            for (var i = 0; i < dd; i++) {
                arrowleftclickwidth = arrowleftclickwidth + $('.blue li:eq(' + i + ')').width()
            }
            setTimeout(function() {
                if (arrowleftclickwidth - maxwidth1 <= (-parseInt($('.blue').css('left'))) + $('.common-list').width()) {
                    $('.tab-ipad-mover-right').hide();
                }
            }, 100)
            if ($(".blue li:last-child a").hasClass('current')) {
                $(".blue li:last-child a").trigger('click');
            }
            return false;
        });
		var totalWidth=0;
        $('.blue li').each(function(){
            totalWidth = totalWidth+$(this).width();
        });
        var check=totalWidth+$(".blue").position().left;
        if((check-$('.current').width())>$('.common-list').width())
        {
            setTimeout(function() {
             $('.tab-ipad-mover-right').css('display', 'block');
             }, 500);
        }
        else{
            $('.tab-ipad-mover-right').css('display', 'none');
        }
    })
    $('.blue li a').click(function(e) {
        var clickid = $(this).attr('id');
        var currentClickLi = $(this).parent().index();
        var currentClickLi1 = $(this).parent().index() - 1;
        if ($('.blue').css('left') == 'auto') {
            $('.blue').css('left', '0')
        }
        setTimeout(function() {
            leftr1 = 0;
            for (var j = 0; j <= currentClickLi; j++) {
                var leftr = $('.blue li:eq(' + j + ')').width() + parseInt($('.blue li:eq(' + j + ')').css('margin-left')) + parseInt($('.blue li:eq(' + j + ')').css('margin-right'));
                leftr1 = leftr1 + leftr;
            }
            clickleftfind1 = 0;
            if (leftr1 > $('.common-list').width()) {
                if (leftr1 > $('.common-list').width() + (-parseInt($('.blue').css('left')))) {
                    if (parseInt($('.blue').css('left')) == 0) {
                        clickleftfindvar = 0;
                    } else {
                        for (var k = 0; k <= currentClickLi; k++) {
                            clickleftfind = $('.blue li:eq(' + k + ')').width() + parseInt($('.blue li:eq(' + k + ')').css('margin-left')) + parseInt($('.blue li:eq(' + k + ')').css('margin-right'))
                            clickleftfind1 = clickleftfind1 + clickleftfind;
                            if (clickleftfind1 <= (-parseInt($('.blue').css('left')))) {
                                clickleftfindvar = k + 1;
                            }
                        }
                    }
                    arrowleftclickwidth = 0;
                    clickleftfindvar3 = 0
                    for (var i = 0; i < dd; i++) {
                        arrowleftclickwidth = arrowleftclickwidth + $('.blue li:eq(' + i + ')').width()
                    }
                    for (var m = 0; m <= clickleftfindvar; m++) {
                        clickleftfindvar2 = $('.blue li:eq(' + m + ')').width() + parseInt($('.blue li:eq(' + m + ')').css('margin-left')) + parseInt($('.blue li:eq(' + m + ')').css('margin-right'));
                        clickleftfindvar3 = clickleftfindvar3 + clickleftfindvar2
                    }
                    if ((arrowleftclickwidth - ((-parseInt($('.blue').css('left'))) + $('.common-list').width() + $('.blue li:eq(' + maxwidth + ')').width() + parseInt($('.blue li:eq(' + maxwidth + ')').css('margin-left')) + parseInt($('.blue li:eq(' + maxwidth + ')').css('margin-right')))) < $('.blue li:eq(' + maxwidth + ')').width() + $('.blue li:eq(' + maxwidth + ')').width()) {
                        $(".blue").animate({
                            left: -clickleftfindvar3
                        }, 10);
                        setTimeout(function() {
                            $("#" + clickid).trigger('click');
                        }, 10);
                    } else {
                        $(".blue").animate({
                            left: -clickleftfindvar3
                        }, 10);
                    }
                    setTimeout(function() {
                        if (arrowleftclickwidth - maxwidth1 <= (-parseInt($('.blue').css('left'))) + $('.common-list').width()) {
                            $('.tab-ipad-mover-right').hide();
                        }
                    }, 100)
                    $('.tab-ipad-mover-left').show();
					setTimeout(function() {
                    if (!($(".blue li:last-child a").hasClass('current'))) {
                        $('.tab-ipad-mover-right').css('display','inline');
                        }
					var totalWidth=0;
                        $('.blue li').each(function(){
                        totalWidth = totalWidth+$(this).width();
                        });
                        var check=totalWidth+$(".blue").position().left;
                        if((check-$('.current').width())>$('.common-list').width())
                            {
                                $('.tab-ipad-mover-right').css('display', 'block');
                            }
                        else{
                                $('.tab-ipad-mover-right').css('display', 'none');
                            }
                    }, 100);
                }
                if ($(".blue li:last-child a").hasClass('current')) {
                    $('.tab-ipad-mover-right').hide();
                }
            }
        }, 200);
    })
    $('.tab-ipad-mover-left').click(function() {
        setTimeout(function() {
            var liactive1 = 0;
            $('.blue li a').each(function() {
                if ($(this).hasClass("current")) {
                    liactive1 = $(this).parent().index() - 1
                }
            })
            arrowleftr1 = 0
            arrowtableft = -(parseInt($('.blue').css('left')))
            for (var j = 0; j <= dd - 1; j++) {
                var arrowleftr = $('.blue li:eq(' + j + ')').width() + parseInt($('.blue li:eq(' + j + ')').css('margin-left')) + parseInt($('.blue li:eq(' + j + ')').css('margin-right'));
                arrowleftr1 = arrowleftr1 + arrowleftr;
                if (arrowtableft >= arrowleftr1) {
                    arrowtableftreslt = j
                }
            }
            arrowtableft2 = 0;
            arrowtableft1 = $('.blue li:eq(' + arrowtableftreslt + ')').width() + parseInt($('.blue li:eq(' + arrowtableftreslt + ')').css('margin-left')) + parseInt($('.blue li:eq(' + arrowtableftreslt + ')').css('margin-right'));
            arrowtableft2 = arrowtableft1 + arrowtableft2
            $(".blue").animate({
                left: parseInt($('.blue').css('left')) + arrowtableft2
            }, 10);
            $('.tab-ipad-mover-right').show();
            arrowleftclickwidth1 = 0;
            for (var i = 0; i < dd; i++) {
                arrowleftclickwidth1 = arrowleftclickwidth1 + $('.blue li:eq(' + i + ')').width()
            }
            if (parseInt($('.blue').css('left')) == -($('.blue li:eq(0)').width() + parseInt($('.blue li:eq(0)').css('margin-left')) + parseInt($('.blue li:eq(0)').css('margin-right')))) {
                $('.tab-ipad-mover-left').hide();
            }
            $('.blue li a').removeClass('current')
            $('.common-list-content').css('display', 'none')
            $('.blue li a').eq(liactive1).addClass('current')
            $('#re' + (liactive1 + 1)).css('display', 'block')
            return false;
        }, 10)
    })
    $(window).bind('orientationchange', function(e) {
        setTimeout(function() {
            var fullwidth = 0;
            var fullwidth1 = 0;
            var fullwidth2 = 0;
            for (var d = 0; d <= dd - 1; d++) {
                fullwidth = $('.blue li:eq(' + d + ')').width() + parseInt($('.blue li:eq(' + d + ')').css('margin-left')) + parseInt($('.blue li:eq(' + d + ')').css('margin-right'));
                fullwidth2 = fullwidth + fullwidth2
            }
            if (mobile.detect() && userAgent.indexOf('ipad') == -1 || tablet.detect()) {
                var maxwidth3 = 0;
                for (var g = 1; g <= dd - 1; g++) {
                    var f = g - 1
                    if ($('.blue li:eq(' + f + ')').width() > $('.blue li:eq(' + g + ')').width()) {
                        maxwidth3 = g
                    }
                }
                var maxwidth4 = $('.blue li:eq(' + maxwidth3 + ')').width()
                if ($('.blue').css('left') == 'auto') {
                    $('.blue').css('left', '0')
                }
                if (fullwidth2 >= $('.common-list').width()) {
                    if (parseInt($('.blue').css('left')) == 0) {
                        $('.tab-ipad-mover-left').hide();
                        $('.tab-ipad-mover-right').show();
                    } else {
                        if (fullwidth2 >= -(parseInt($('.blue').css('left'))) + $('.common-list').width()) {
                            $('.tab-ipad-mover-right').show();
                            $('.tab-ipad-mover-left').show();
                        } else {
                            $('.tab-ipad-mover-right').hide();
                            $('.tab-ipad-mover-left').show();
                        }
                    }
                } else {
                    $('.tab-ipad-mover-left').hide();
                    $('.tab-ipad-mover-right').hide();
                    $('.blue').css('left', '0')
                }
            }
            var liactive;
            $('.blue li a').each(function() {
                if ($(this).hasClass("current")) {
                    liactive = $(this).attr('id')
                }
            })
            $('#' + liactive + '').trigger('click');
            setTimeout(function() {
                $('#' + liactive + '').trigger('click');
            }, 500);
            $('body').trigger('click')
        }, 300)
    })
});
(function(window, document, $) {
    var isInputSupported = 'placeholder' in document.createElement('input');
    var isTextareaSupported = 'placeholder' in document.createElement('textarea');
    var prototype = $.fn;
    var valHooks = $.valHooks;
    var propHooks = $.propHooks;
    var hooks;
    var placeholder;
    if (isInputSupported && isTextareaSupported) {
        placeholder = prototype.placeholder = function() {
            return this;
        };
        placeholder.input = placeholder.textarea = true;
    } else {
        placeholder = prototype.placeholder = function() {
            var $this = this;
            $this.filter((isInputSupported ? 'textarea' : ':input') + '[placeholder]').not('.placeholder').bind({
                'focus.placeholder': clearPlaceholder,
                'blur.placeholder': setPlaceholder
            }).data('placeholder-enabled', true).trigger('blur.placeholder');
            return $this;
        };
        placeholder.input = isInputSupported;
        placeholder.textarea = isTextareaSupported;
        hooks = {
            'get': function(element) {
                var $element = $(element);
                var $passwordInput = $element.data('placeholder-password');
                if ($passwordInput) {
                    return $passwordInput[0].value;
                }
                return $element.data('placeholder-enabled') && $element.hasClass('placeholder') ? '' : element.value;
            },
            'set': function(element, value) {
                var $element = $(element);
                var $passwordInput = $element.data('placeholder-password');
                if ($passwordInput) {
                    return $passwordInput[0].value = value;
                }
                if (!$element.data('placeholder-enabled')) {
                    return element.value = value;
                }
                if (value == '') {
                    element.value = value;
                    if (element != safeActiveElement()) {
                        setPlaceholder.call(element);
                    }
                } else if ($element.hasClass('placeholder')) {
                    clearPlaceholder.call(element, true, value) || (element.value = value);
                } else {
                    element.value = value;
                }
                return $element;
            }
        };
        if (!isInputSupported) {
            valHooks.input = hooks;
            propHooks.value = hooks;
        }
        if (!isTextareaSupported) {
            valHooks.textarea = hooks;
            propHooks.value = hooks;
        }
        $(function() {
            $(document).delegate('form', 'submit.placeholder', function() {
                var $inputs = $('.placeholder', this).each(clearPlaceholder);
                setTimeout(function() {
                    $inputs.each(setPlaceholder);
                }, 10);
            });
        });
        $(window).bind('beforeunload.placeholder', function() {
            $('.placeholder').each(function() {
                this.value = '';
            });
        });
    }

    function args(elem) {
        var newAttrs = {};
        var rinlinejQuery = /^jQuery\d+$/;
        $.each(elem.attributes, function(i, attr) {
            if (attr.specified && !rinlinejQuery.test(attr.name)) {
                newAttrs[attr.name] = attr.value;
            }
        });
        return newAttrs;
    }

    function clearPlaceholder(event, value) {
        var input = this;
        var $input = $(input);
        if (input.value == $input.attr('placeholder') && $input.hasClass('placeholder')) {
            if ($input.data('placeholder-password')) {
                $input = $input.hide().next().show().attr('id', $input.removeAttr('id').data('placeholder-id'));
                if (event === true) {
                    return $input[0].value = value;
                }
                $input.focus();
            } else {
                input.value = '';
                $input.removeClass('placeholder');
                input == safeActiveElement() && input.select();
            }
        }
    }

    function setPlaceholder() {
        var $replacement;
        var input = this;
        var $input = $(input);
        var id = this.id;
        if (input.value == '') {
            if (input.type == 'password') {
                if (!$input.data('placeholder-textinput')) {
                    try {
                        $replacement = $input.clone().attr({
                            'type': 'text'
                        });
                    } catch (e) {
                        $replacement = $('<input>').attr($.extend(args(this), {
                            'type': 'text'
                        }));
                    }
                    $replacement.removeAttr('name').data({
                        'placeholder-password': $input,
                        'placeholder-id': id
                    }).bind('focus.placeholder', clearPlaceholder);
                    $input.data({
                        'placeholder-textinput': $replacement,
                        'placeholder-id': id
                    }).before($replacement);
                }
                $input = $input.removeAttr('id').hide().prev().attr('id', id).show();
            }
            $input.addClass('placeholder');
            $input[0].value = $input.attr('placeholder');
        } else {
            $input.removeClass('placeholder');
        }
    }

    function safeActiveElement() {
        try {
            return document.activeElement;
        } catch (err) {}
    }
}(this, document, jQuery));
$(document).ready(function() {
    if (!("placeholder" in document.createElement("input"))) {
        $("input[placeholder], textarea[placeholder]").each(function() {
            var val = $(this).attr("placeholder");
            if (this.value == "") {
                this.value = val;
            }
            $(this).focus(function() {
                if (this.value == val) {
                    this.value = "";
                }
            }).blur(function() {
                if ($.trim(this.value) == "") {
                    this.value = val;
                }
            })
        });
    }
})
$(document).ready(function() {
    $('.pdf-icon a').addClass('carrot');
    $('.showhideli a').click(function() {
        if (!$(this).hasClass('selected')) {
            $('.showhideli a').removeClass('selected');
            $(this).addClass('selected');
            $('.intro-a p').css('display', 'none');
            $('.intro-a').css('border-bottom', '0px');
            $('.contentshowhide').slideUp('1500');
            $('.contentshowhide:eq(' + $('.showhideli a').index(this) + ')').slideDown('1500');
        }
    });
})
$(document).ready(function() {
    var disctablepintro = 0;
    $(".intro-a").each(function() {
        disctablepintro = disctablepintro + 1;
    })
    if (disctablepintro > 0) {
        if ($('.intro-a').children().get(0).nodeName.indexOf('P') != -1) {
            $(".intro-a p:eq(0)").css("margin-top", "0");
        }
    }
});
$(document).ready(function() {
    $('.footerfbicon').click(function() {
        var f = confirm("You are about to leave a Citibank website");
        if (f == true) {} else {
            return false;
        }
    });
    $('.carrotclick').click(function() {
        var r = confirm("You are now leaving Citibank UAE website. All the information you provide will be subject to confidentiality and security terms of the applicable website. Would you like to continue?");
        if (r == true) {} else {
            return false;
        }
    });
    $('.alertclick').click(function() {
        var r = confirm("You are now leaving Citibank Online and choosing to be redirected to the AIG website. Citibank N.A is not affiliated with AIG and redirecting you to the AIG website does not constitute any recommendation, endorsement or confirmation by Citibank N.A or any of its representatives of the insurance products offered by AIG. Neither Citibank nor any of its representatives offers legal or tax advice. When considering whether or not to purchase any one of AIGÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢s insurance products you shall solely rely on advice provided by AIG. No reliance shall be placed on information contained on Citibank Online or on Citibank or its representatives in relation to the  AIG insurance products. Citibank N.A. shall not be held responsible for your relationship with AIG. All information you provide to AIG on its website will be subject to AIGÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢s security and privacy policies. We encourage you to read the security and privacy policies on AIG website.");
        if (r == true) {} else {
            return false;
        }
    });
    $('.carrotenclick').click(function() {
        var r11 = confirm("You are now leaving Citibank UAE website. All the information you provide will be subject to confidentiality and security terms of the applicable website. Would you like to continue?");
        if (r11 == true) {} else {
            return false;
        }
    });
    $('.carrotclick1').click(function() {
        var r1 = confirm("Przechodzisz na strone dla KlientÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã¢â‚¬ ÃƒÂ¢Ã¢â€šÂ¬Ã¢â€žÂ¢ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬ ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬ÃƒÂ¢Ã¢â‚¬Å¾Ã‚Â¢ÃƒÆ’Ã†â€™Ãƒâ€ Ã¢â‚¬â„¢ÃƒÆ’Ã‚Â¢ÃƒÂ¢Ã¢â‚¬Å¡Ã‚Â¬Ãƒâ€¦Ã‚Â¡ÃƒÆ’Ã†â€™ÃƒÂ¢Ã¢â€šÂ¬Ã…Â¡ÃƒÆ’Ã¢â‚¬Å¡Ãƒâ€šÃ‚Â³w Citi Handlowy stworzona przez Ubezpieczyciela Europ Assistance Holding S.A. Czy chcesz kontynuowac?");
        var r = confirm("Opuszczasz serwis Citi Handlowy i przechodzisz na strone zewnetrzna.");
        if (r == true) {} else {
            return false;
        }
    });
})
$(document).ready(function() {
    function remwid() {
        $('.table-arrow').removeAttr("width");
    }

    function equalhgrem() {
        $('.footer-sec').removeAttr("height");
        var tableh561 = 0
        $(".footer-sec").each(function() {
            tableh561 = tableh561 + 1;
        })
        for (var i = 1; i <= tableh561; i++) {
            var dd = i - 1;
            $(".footer-sec:eq(" + dd + ")").removeAttr("height");
            $(".footer-sec:eq(" + dd + ")").css("height", "")
        }
    }
})
$(document).ready(function() {
    $('.lange').click(function() {
        var mainlocurl = location.href;
        var pagePathName = window.location.pathname;
        var fileName = pagePathName.substring(pagePathName.lastIndexOf("/") + 1);
        var pathnae = ["/Accounts/", "/Benefits_and_Privileges/", "/Investments/", "/Insurance/", "/Loans_and_Credits/", "/Global_Banking/", "/Main/", "/Contact/"];
        var pathnap = ["/Konta/", "/Korzysci_i_Przywileje/", "/Inwestowanie/", "/Ubezpieczenia/", "/Pozyczki_i_Kredyty/", "/Globalna_bankowosc/", "/Main/", "/Kontakt/"];
        for (var k = 0; k < 8; k++) {
            if (mainlocurl.indexOf('/english/') != -1) {
                this.href = this.href.replace('/english/', '/polish/');
                var engpath = pathnae[k];
                var polpath = pathnap[k];
                this.href = this.href.replace(engpath, polpath);
            }
            if (mainlocurl.indexOf('/polish/') != -1) {
                this.href = this.href.replace('/polish/', '/english/');
                var engpath = pathnae[k]
                var polpath = pathnap[k]
                this.href = this.href.replace(polpath, engpath);
            }
        }
        if (navigator.userAgent.indexOf('MSIE') != -1) {
            this.href = this.href + fileName;
        }
    });
})

function headermenuhighlight() {
    var mainlocurl = location.href;
    var mainlocurl1 = location.href;
    $(".activeTab").removeClass("activeTab");
    if (mainlocurl.indexOf('/Main/') != -1) {
        if (mainlocurl.indexOf('/Rozwiazania_walutowe.htm') != -1) {
            $('#topMnucommercialBank').addClass('activeTab')
        }
		}
		if (mainlocurl.indexOf('/homepage/index.htm') != -1) {
            $('#tophome').addClass('activeTab')
        }
    if (mainlocurl1.indexOf('/credit_cards/consumer/') != -1) {
        $('#topMnuinvestments').addClass('activeTab')
    }
    if (mainlocurl.indexOf('/corporate/') != -1) {
        if (mainlocurl.indexOf('/markets_banking/') != -1) {
            $('#topMnucorporate').addClass('activeTab')
        }
    }
    if (mainlocurl1.indexOf('/Ubezpieczenia/') != -1) {
        $('#topMnureadyCredit').addClass('activeTab')
    }
    if (mainlocurl1.indexOf('/mortgages/') != -1) {
        $('#topMnucreditcard').addClass('activeTab')
    }
    if (mainlocurl1.indexOf('/Korzysci_i_Przywileje/') != -1) {
        $('#topMnubanking').addClass('activeTab')
    }
    if (mainlocurl1.indexOf('/insurance/') != -1) {
        $('#topMnuinsurance').addClass('activeTab')

    }
    if (mainlocurl1.indexOf('/consumer/') != -1) {
        if (mainlocurl1.indexOf('/credit_cards/') != -1) {
            $('#topcredit_cards').addClass('activeTab')
        }
    }
    if (mainlocurl1.indexOf('/citi_at_work/') != -1) {
        $('#topMnucorporate').addClass('activeTab')
    }
    if (mainlocurl.indexOf('/Globalna_bankowosc/') != -1) {
        $('#topMnuglobal').addClass('activeTab')
    }
    if (mainlocurl.indexOf('/consumer/') != -1) {
        if (mainlocurl.indexOf('/personal_account/') != -1) {
            $('#topMnuglobal').addClass('activeTab')
        }
    }
    if (mainlocurl.indexOf('/Main/') != -1) {
        if (mainlocurl.indexOf('/Rozwiazania_walutowe.htm') != -1) {
            $('#topMnucommercialBank').addClass('activeTab')
        }
    }
    if (mainlocurl.indexOf('/corporate/') != -1) {
        if (mainlocurl.indexOf('/markets_banking/') != -1) {
            $('#topMnucorporate').addClass('activeTab')
        }
    }
    if (mainlocurl.indexOf('/commercial/') != -1) {
        if (mainlocurl.indexOf('/commercial_banking/') != -1) {
            $('#topMnucorporate').addClass('activeTab')
        }
    }
    if (mainlocurl.indexOf('/consumer/') != -1) {
        if (mainlocurl.indexOf('/personal_account/') != -1) {
            $('#topMnuglobal').addClass('activeTab')
        }
    }
    if (mainlocurl.indexOf('/citigold_private_client/') != -1) {
        $('#topMnucpc').addClass('activeTab')
    }
    if (mainlocurl.indexOf('/offshore/') != -1) {
        if (mainlocurl.indexOf('/international_personal_banking/') != -1) {
            $('#topMnuglobal').addClass('activeTab')
        }
    }
    if (mainlocurl.indexOf('/consumer/') != -1) {
        if (mainlocurl.indexOf('/personal_account/') != -1) {
            $('#topMnuglobal').addClass('activeTab')
        }
    }
    if (mainlocurl.indexOf('/consumer/') != -1) {
        if (mainlocurl.indexOf('/citi_at_work/') != -1) {
            $('#topMnucorporate').addClass('activeTab')
        }
        if (mainlocurl.indexOf('/corporate/') != -1) {
            if (mainlocurl.indexOf('/markets_banking/') != -1) {
                $('#topMnucorporate').addClass('activeTab')
            }
        }
        if (mainlocurl.indexOf('/mortgages/') != -1) {
            $('#topMnucreditcard').addClass('activeTab')
        }
        if (mainlocurl.indexOf('/forms/') != -1) {
            if (mainlocurl.indexOf('/consumer/') != -1) {
                if (mainlocurl.indexOf('/personal_account/') != -1) {
                    $('#topMnuglobal').addClass('activeTab')
                }
            }
            if (mainlocurl.indexOf('/consumer/') != -1) {
                if (mainlocurl.indexOf('/personal_account/') != -1) {
                    $('#topMnuglobal').addClass('activeTab')
                }
            }
            if (mainlocurl.indexOf('/citi_at_work/') != -1) {
                $('#topMnucorporate').addClass('activeTab')
            }
            if (mainlocurl.indexOf('/contact_form.htm') != -1) {
                $('#topMnubanking').removeClass('activeTab')
            }
            if (mainlocurl.indexOf('/golf_reserve_form.htm') != -1) {
                $('#topMnubanking').removeClass('activeTab')
            }
            if (mainlocurl.indexOf('/suppl_card_form.htm') != -1) {
                $('#topMnubanking').removeClass('activeTab')
            }
        }
        if (mainlocurl.indexOf('/loans/') != -1) {
            $('#topMnubanking').addClass('activeTab')
        }
        if (mainlocurl.indexOf('/reach_us/') != -1) {
            $('#topMnucommercialBank').addClass('activeTab')
        }
        if (mainlocurl.indexOf('/investment_treasury/') != -1) {
            $('#topMnureadyCredit').addClass('activeTab')
        }
        if (mainlocurl.indexOf('/Benefits_and_Privileges/') != -1) {
            $('#topMnubanking').addClass('activeTab')
        }
        if (mainlocurl.indexOf('/mortgages/') != -1) {
            $('#topMnucreditcard').addClass('activeTab')
        }
        if (mainlocurl.indexOf('/Insurance/') != -1) {
            $('#topMnureadyCredit').addClass('activeTab')
        }
        if (mainlocurl1.indexOf('/citi_at_work/') != -1) {
            $('#topMnucorporate').addClass('activeTab')
        }
        if (mainlocurl.indexOf('/insurance/') != -1) {
            $('#topMnuinsurance').addClass('activeTab')
        }
        if (mainlocurl1.indexOf('/consumer/') != -1) {
            if (mainlocurl1.indexOf('/credit_cards/') != -1) {
                $('#topcredit_cards').addClass('activeTab')
            }
        }
        if (mainlocurl.indexOf('/Global_Banking/') != -1) {
            $('#topMnuglobal').addClass('activeTab')
        }
        if (mainlocurl.indexOf('/contact/') != -1) {
            $('#topMnuservices').addClass('activeTab')
        }
    }
    if (mainlocurl.indexOf('/insurance/') != -1) {
        $('#topMnuinsurance').addClass('activeTab')
    }
    if (mainlocurl1.indexOf('/citigold/introduction/') != -1) {
        $('#topMnucitigold').addClass('activeTab')
    }
    if (mainlocurl1.indexOf('/citigold/citigold_private_client/') != -1) {
        $('#topMnucpc').addClass('activeTab')
    }
    if (mainlocurl1.indexOf('homepage/index.htm') != -1) {
        $('#tophome').addClass('activeTab')
    }
    if (mainlocurl1.indexOf('/citigold/forms/') != -1) {
        $('#topMnucitigold').addClass('activeTab')
    }
    if (mainlocurl1.indexOf('/consumer/') != -1) {
        if (mainlocurl1.indexOf('/credit_cards/') != -1) {
            $('#topcredit_cards').addClass('activeTab')
        }
    }
}
$(document).ready(function() {
    $(".tab-cnt-seven .global-show-hide:first-child").css("padding-top", 0);
    if ($(window).width() <= "480") {
        var dolp = 0
        $(".double-inner").each(function() {
            dolp = dolp + 1;
        })
        for (var i = 0; i < dolp; i++) {
            $(".double-inner:eq(" + i + ")").each(function() {
                $(".double-inner:eq(" + i + ") p:eq(0)").css('margin-top', 0)
            })
            $(".double-inner:eq(" + i + ") ul").each(function() {
                if ($(this).prev().prop("nodeName") != "P") {
                    $(".double-inner:eq(" + i + ") ul:eq(0)").css('margin-top', 0)
                    $(".double-inner:eq(" + i + ") p:eq(0)").css('margin-top', 0)
                }
            })
        }
    }
    $(".columns .global-show-hide:last-child").css("border-bottom", 0);
    $(".columns .global-show-hide:last-child").css("padding-bottom", 0);
    if ($(window).width() <= "480") {
        $(".columns .global-show-hide:first-child").css("padding-top", 0);
    }
    var dolp = 0
    $(".productsListDetails").each(function() {
        dolp = dolp + 1;
    })
    for (var i = 0; i < dolp; i++) {
        $(".productsListDetails:eq(" + i + ")").each(function() {
            $(".productsListDetails:eq(" + i + ") p:eq(0)").css('margin-top', 0)
        })
        $(".productsListDetails:eq(" + i + ") ul").each(function() {
            if ($(this).prev().prop("nodeName") != "P") {
                $(".productsListDetails:eq(" + i + ") ul:eq(0)").css('margin-top', 0)
                $(".productsListDetails:eq(" + i + ") p:eq(0)").css('margin-top', 0)
            }
        })
    }
})
$(document).ready(function() {
    $('body').click(function() {
        var has = $(".right-content-part").hasClass("vdo-cont");
        if (has == true) {
            $('#topcredit_cards').removeAttr('id');
        }
    });
    $('.howtoreedem').click(function() {
        $('#howtoreedem').trigger('click');
    });
    $('.table-hide').click(function() {
        $('#table-hide').toggle();
    });
    $('.table-hide1').click(function() {
        $('#table-hide1').toggle();
    });
    $('.table-hide2').click(function() {
        $('#table-hide2').toggle();
    });
});
$(document).ready(function() {


    $(".scroll-down4").click(function() {
        $("html, body").animate({
            scrollTop: $('.emirates.allcards').eq(4).offset().top
        }, 1000);
    });

});
$(document).ready(function() {
    if ($.browser.msie && $.browser.version <= 9.0) {
        $.getScript("/CMENA-371/v4/uae/data/js/PIE.js", function() {
            if (window.PIE) {
                $('.tabsection .blue li').each(function() {
                    $(this).children().each(function() {
                        PIE.attach(this);
                    });
                });
                $('.btn-cpcgold').each(function() {
                    PIE.attach(this);
                });
            }
        });
    }
});

$(document).ready(function() {
    if ($.browser.msie && $.browser.version <= 9.0) {
        $.getScript("/CMENA-371/v4/uae/data/js/PIE.js", function() {
            if (window.PIE) {
                $('#bg-signon').each(function() {
                        PIE.attach(this);
                });
                $('.signon-banner').each(function() {
                    PIE.attach(this);
                });
            }
        });
    }
});

$(document).ready(function() {
    if ($.browser.msie && $.browser.version <= 9.0) {
        $.getScript("/CMENA-371/v4/uae/data/js/PIE.js", function() {
            if (window.PIE) {
                $('.megamenu').each(function() {
                        PIE.attach(this);
                });

            }
        });
    }
});

$(document).ready(function() {
    if ($.browser.msie && $.browser.version <= 9.0) {
        $.getScript("/CMENA-371/v4/uae/data/js/PIE.js", function() {
            if (window.PIE) {
                $('.half-gold-banner').each(function() {
                        PIE.attach(this);
                });

            }
        });
    }
});



$(document).ready(function() {
$(".header-blue, .header-cpc, .header-gold").on('mouseleave','.top-Navigation', function(){
 $(this).removeClass("activeMMenu");
 $(".megaMenuCnt").css({
			"height": "0"
	})
 $("body").trigger("click");
});
    if ($.browser.msie && $.browser.version <= 9.0) {
        $.getScript("/CMENA-371/v4/uae/data/js/PIE.js", function() {
            if (window.PIE) {
                       $('.mega-bottom-rounded').each(function() {

                        PIE.attach(this);

                });
                    $('.megamenu').each(function() {
                    PIE.attach(this);
                });
		    $('.mmOffer').each(function() {
                    PIE.attach(this);
                });
		    $('.chat-wrap-tool-tip').each(function() {
                    PIE.attach(this);
                });
            }
        });
    }
});

if(  navigator.userAgent.match(/iPod/i)
||navigator.userAgent.match(/iPad/i)
||navigator.userAgent.match(/SM-T211/i)
 )
 {
 if (window.matchMedia('(min-width: 1024px)').matches)
{
 $('.productsListDetails.heightfixing').css('margin-top','5px');
}
else{
$('.productsListDetails.heightfixing').css('margin-top','0');
}
    $(window).bind('orientationchange', function(e) {
        setTimeout(function() {
            if ($(window).width() == 1024) {

$('.productsListDetails.heightfixing').css('margin-top','5px');
            } else {

$('.productsListDetails.heightfixing').css('margin-top','0');
            }
        }, 500)
    })
}

/* $(window).load(function() {
var url = window.location.href.substr(window.location.href.lastIndexOf("/")+1);
$('.submainul').each(function(){
$(this).children().each(function(){
var href = $(this).children().attr('href');
if(href.indexOf(url) >= 0){
$(this).children().addClass('activeText');
$(this).parents('.submainul').show().prev().children().addClass('show');
}
});
});

});
 */

 $(window).load(function() {

 $("body").trigger("click");
//url=window.location.href.substr(window.location.href.lastIndexOf("/")+1);
url=window.location.href;
var array = url.split('/'),
foo = array[array.length-2];
    foo1 = array[array.length-1];
var res=foo+"/"+foo1;
if(res.lastIndexOf("#")!=-1)
{res=res.substr(0,res.lastIndexOf("#"));}
if(res.lastIndexOf("?")!=-1)
{res=res.substr(0,res.lastIndexOf("?"));}


   $('.submainul').each(function(){


		$(this).children().each(function(){
			var href = $(this).children().attr('href');
			if(href.indexOf(res) >= 0){
				$(this).children().addClass('activeText');
				$(this).parents('.submainul').show().prev().children().addClass('show');
			}
		});
   });

});
function popup_function()
{
window.open('../../consumer/insurance_calc/form.htm','','width=984,height=666,top=150,left=150,scrollbars=yes');
}

$(function(){
	var flyout = "";
		flyout +=		'<div id="flyout-menu">';
		flyout +=			'<div class="flyout_section flyout_apply">';
		flyout +=				'<div class="flyout_cta">';
		flyout +=					'<a href="javascript:void(0);" title="Apply for a product"></a>';
		flyout +=				'</div>';
		flyout +=				'<div class="flyout_content">';
		flyout +=					'<div class="flyout_grid_3">';
		flyout +=						'<div class="flyout_image">';
		flyout +=							'<img src="/CMENA-371/v4/uae/data/images/flyout/citi-credit-cards.png" alt="Citi Credit Cards" title="Citi Credit Cards" />';
		flyout +=						'</div>';
		flyout +=						'<div class="flyout_description">';
		flyout +=						'<h3>Citi Credit Cards</h3>';
		flyout +=						'<p>Get a wide range of benefits and rewards</p>';
		flyout +=							'<a href="https://www.citibank.com/CMENA-371/v4/uae/consumer/credit_cards/apply_cards_form.htm?icid=AEHPACAAN" title="APPLY NOW">APPLY NOW</a>';
		flyout +=						'</div>';
		flyout +=					'</div>';
		flyout +=					'<div class="flyout_grid_3">';
		flyout +=						'<div class="flyout_image">';
		flyout +=							'<img src="/CMENA-371/v4/uae/data/images/flyout/citi-personal-loan.png" alt="Instant Cash Loan" title="Instant Cash Loan"/>';
		flyout +=						'</div>';
		flyout +=						'<div class="flyout_description" style="width:135px;">';
		flyout +=						'<h3>Instant Cash Loan</h3>';
		flyout +=						'<p>Convert your available credit limit into an instant cash loan</p>';
		flyout +=							'<a href="https://online.citibank.ae/CBOL/getcash" title="APPLY NOW">APPLY NOW</a>';
		flyout +=						'</div>';
		flyout +=					'</div>';
		flyout +=					'<div class="flyout_grid_3">';
		flyout +=						'<div class="flyout_image">';
		flyout +=							'<img src="/CMENA-371/v4/uae/data/images/flyout/e-brokarage.png" alt="Citigold" title="Citigold"/>';
		flyout +=						'</div>';
		flyout +=						'<div class="flyout_description">';
		flyout +=							'<h3>Citigold</h3>';
		flyout +=							'<p style="width:120px;">Our innovative wealth management solutions. Your intuition.</p>';
		flyout +=							'<a href="https://www.citibank.com/CMENA-371/v4/uae/citigold/forms/citigold_form.htm" title="APPLY NOW">APPLY NOW</a>';
		flyout +=						'</div>';
		flyout +=					'</div>';
		flyout +=					'<div class="flyout_grid_3 last">';
		flyout +=						'<ul class="flyout_links">';
		flyout +=							'<li><a href="https://www.citibank.com/CMENA-371/v4/uae/gcb/apply/form.htm?card=Bank-Account&icid=AEFOAP41" title="Accounts">Accounts</a></li>';
		flyout +=							'<li><a href="https://www.citibank.com/CMENA-371/v4/uae/gcb/apply/form.htm?card=Investplus&icid=AEFOAP42" title="Insurance">Insurance</a></li>';
		flyout +=						'</ul>';
		flyout +=					'</div>';
		flyout +=					'<div class="flyout_close">';
		flyout +=						'<a href="javascript:void(0);" title="Close"></a>';
		flyout +=					'</div>';
		flyout +=				'</div>';
		flyout +=			'</div>';
		flyout +=			'<div class="flyout_section flyout_promotions">';
		flyout +=				'<div class="flyout_cta">';
		flyout +=					'<a href="javascript:void(0);" title="Promotions"></a>';
		flyout +=				'</div>';

		flyout +=				'<div class="flyout_content">';
		flyout +=					'<div class="flyout_grid_4">';
		flyout +=						'<div class="flyout_image">';
		flyout +=							'<img src="/CMENA-371/v4/uae/data/images/flyout/image-AED.jpg" alt="Get up to AED 600 statement credit!" title="Get up to AED 600 statement credit!"/>';
		flyout +=						'</div>';
		flyout +=						'<div class="flyout_description">';
		flyout +=							'<h3>Get up to AED 600 statement credit!</h3>';
		flyout +=							'<p>Apply for a Citi Credit Card and get up to AED 600 statement credit on your new card.</p>';
		flyout +=							'<a href="https://www.citibank.com/CMENA-371/v4/uae/consumer/credit_cards/apply_cards_form.htm?icid=AEFOPR1" title="APPLY NOW ">APPLY NOW </a>';
		flyout +=						'</div>';
		flyout +=					'</div>';
		flyout +=					'<div class="flyout_grid_4">';
		flyout +=						'<div class="flyout_image">';
		flyout +=							'<img src="/CMENA-371/v4/uae/data/images/flyout/cards_mgm.jpg" alt="Get up to AED 600 cashback" title="Get up to AED 600 cashback"/>';
		flyout +=						'</div>';
		flyout +=						'<div class="flyout_description">';
		flyout +=							'<h3>Share the happiness!</h3>';
		flyout +=							'<p>Refer your friends for a Citi Credit Card and get rewarded with AED 300 for every approved card. T&C Apply.</p>';
		flyout +=							'<a href="https://www.citibank.com/CMENA-371/v4/uae/consumer/mgm_campaign_for_creditcards/form.htm?icid=AEFOPR2" title="APPLY NOW">APPLY NOW</a>';
		flyout +=						'</div>';
		flyout +=					'</div>';
		flyout +=					'<div class="flyout_grid_4">';
		flyout +=						'<div class="flyout_image">';
		flyout +=							'<img src="/CMENA-371/v4/uae/data/images/flyout/buzz_of_the_month.jpg" alt="Buzz of the Month" title="Buzz of the Month"/>';
		flyout +=						'</div>';
		flyout +=						'<div class="flyout_description">';
		flyout +=							'<h3>Buzz of the Month</h3>';
		flyout +=							'<p>Choose from the best of dining, entertainment, travel and shopping offers.</p>';
		flyout +=							'<a href="/CMENA-371/v4/uae/consumer/credit_cards/buzz_of_the_month.htm?icid=AEFOPR3" title="LEARN MORE">LEARN MORE</a>';
		flyout +=						'</div>';
		flyout +=					'</div>';


		flyout +=					'<div class="flyout_grid_4 last">';
		flyout +=						'<div class="flyout_image">';
		flyout +=							'<img src="/CMENA-371/v4/uae/data/images/flyout/CareemMgm.jpg" alt="Go Further with Careem" title="Go Further with Careem"/>';
		flyout +=						'</div>';
		flyout +=						'<div class="flyout_description">';
		flyout +=							'<h3>Go Further with Careem</h3>';
		flyout +=							'<p>Enjoy 20% off twice a month with your Citi Credit Card. Offer T&C Apply.</p>';
		flyout +=							'<a href="https://www.citibank.com/CMENA-371/v4/uae/campaigns/Careem/form.htm?icid=AEFOPR4" title="APPLY NOW">APPLY NOW</a>';
		flyout +=						'</div>';
		flyout +=					'</div>';
		flyout +=					'<div class="flyout_close">';
		flyout +=						'<a href="javascript:void(0);" title="Close"></a>';
		flyout +=					'</div>';
		flyout +=				'</div>';
		flyout +=			'</div>';
		flyout +=			'<div class="flyout_section flyout_contact">';
		flyout +=				'<div class="flyout_cta">';
		flyout +=					'<a href="javascript:void(0);" title="Contact Us"></a>';
		flyout +=				'</div>';
		flyout +=				'<div class="flyout_content">';
		flyout +=					'<div class="flyout_grid_5">';
		flyout +=						'<p class="flyout_contact_description">';
		flyout +=							'Sign on to <a href="https://online.citibank.ae/CBOL/request" title="Citibank Online">Citibank Online</a> and send us a secure message or request.';
		flyout +=						'</p>';
		flyout +=					'</div>';
		flyout +=					'<div class="flyout_grid_5">';
		flyout +=						'<p class="flyout_contact_description">';
		flyout +=							'Fill this <a href="http://www.citibank.com/CMENA-371/v4/uae/consumer/forms/contact_form.htm?icid=AEFOCU2" title="form">form</a> to enquire about our products and services.';
		flyout +=						'</p>';
		flyout +=					'</div>';
		flyout +=					'<div class="flyout_grid_5">';
		flyout +=						'<p class="flyout_contact_description">';
		flyout +=							'<a onclick="return open_redirect(this);" href="https://www.facebook.com/CitibankUAE" title="Like">Like</a> us on Facebook.';
		flyout +=						'</p>';
		flyout +=					'</div>';
		flyout +=					'<div class="flyout_grid_5">';
		flyout +=						'<p class="flyout_contact_description">';
		flyout +=							'Call our 24-hours CitiPhone Banking Services on +971 4 311 4000 or our Citigold Services on +971 4 311 4653.';
		flyout +=						'</p>';
		flyout +=					'</div>';
		flyout +=					'<div class="flyout_grid_5 last">';
		flyout +=						'<p class="flyout_contact_description">';
		flyout +=							'<a href="http://www.citibank.com/CMENA-371/v4/uae/consumer/reach_us/location.htm?icid=AEFOCU5" title="View">View</a> our Branch and ATM network.';
		flyout +=						'</p>';
		flyout +=					'</div>';
		flyout +=					'<div class="flyout_close">';
		flyout +=						'<a href="javascript:void(0);" title="Close"></a>';
		flyout +=					'</div>';
		flyout +=				'</div>';
		flyout +=			'</div>';
		flyout +=		'</div>';
		if(location.href.indexOf('terms_and_conditions-disclaimer2.htm')==-1)
		$('body').append(flyout);

	$('.flyout_cta,.flyout_close').click(function(){
		$(this).parents('.flyout_section').siblings().animate({'right': 0},600);
		var right = parseInt($(this).parents('.flyout_section').css('right'));
		if(right == 0){
			if($(window).width() < 960){
				$(this).parents('.flyout_section').animate({'right': 644},600);
			}else{
				$(this).parents('.flyout_section').animate({'right': 960},600);
			}
		}else{
			$(this).parents('.flyout_section').animate({'right': 0},600);
		}
	});
	$('.flyout_section').click(function(e){
		e.stopPropagation();
	});

	$('html,body').click(function(){
		$('.flyout_section').animate({'right': 0},600);
	});
});

function open_redirect(el){
    newwindow = window.open("/CMENA-371/v4/uae/social/terms_and_conditions-disclaimer2.htm?redirect=" + el.href, 'name', 'height=392,width=667,top=150,left=550', '_blank');
    if (window.focus) {
        newwindow.focus()
    }
    return false;
}

$(document).ready(function() {


    $('#RightArrow').click(function(){

       $(".Scroll_1").animate({marginLeft: '-100px'});

    });

    $('#LeftArrow').click(function(){

       $(".Scroll_1").animate({marginLeft: '+0px'});

    });

	$('#RightArrow2').click(function(){

       $(".Scroll_2").animate({marginLeft: '-100px'});

    });

    $('#LeftArrow2').click(function(){

       $(".Scroll_2").animate({marginLeft: '+0px'});

    });

});

function OpenPopUp()
{
	document.getElementById('Layer').style.display= "block";
	document.getElementById('PopUp_1').style.display = "block";

}

function ClosePopUp()
{
	$('video').each(function(k,v){ jQuery('video')[k].pause(); });
	document.getElementById('PopUp_1').style.display = "none";
	document.getElementById('Layer').style.display= "none";

}

function OpenPopUp2()
{
	document.getElementById('Layer').style.display= "block";
	document.getElementById('PopUp_2').style.display = "block";

}

function ClosePopUp2()
{
	$('video').each(function(k,v){ jQuery('video')[k].pause(); });
	document.getElementById('PopUp_2').style.display = "none";
	document.getElementById('Layer').style.display= "none";

}

	$( ".bx-card" ).click(function() {
  $('div#redeem_tab71').show();
  $('div#redeem_tab72').hide();
  $('div#redeem_tab73').hide();
  $('div#redeem_tab74').hide();
  $('div#redeem_tab75').hide();
  $('div#redeem_tab76').hide();
  $('div#redeem_tab77').hide();
  $('div#redeem_tab78').hide();
  $('div#redeem_tab79').hide();
});
