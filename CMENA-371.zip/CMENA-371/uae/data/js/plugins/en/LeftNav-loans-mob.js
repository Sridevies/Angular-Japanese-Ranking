document.write(


'    <div id="display-non-desk" class="left-nav-mob">'+
'    <ul id="nav" class="mobile-left-nav">'+			
'			<li class="sub"><a class="left-nav-icon menu-icon-blue" href="javascript:void(0);"></a>'+
'                <ul class="maniul hidden">'+

 
/*
'              <li class="leftshowhide_sub"><a style="background-image:none !important;" href="../../consumer/forms/stl_form.htm" title="Salary Transfer Loans form">Salary Transfer Loans form</a></li>'+ */
'              <li class="leftliholder"><a  href="../../consumer/loans/personal_installment_loans.htm?icid=AELOLN1"  >Personal Installment Loans</a>'+
'							<ul class="leftshowhide_sub  hidden">'+
'								<li class="lisubheadadj"><a href="../../consumer/forms/perinstall_form.htm?icid=AELOLN11" >Apply Now</a></li>'+
'              				</ul>'+
'				</li>'+ 
'              <li class="leftliholder"><a  href="../../consumer/loans/salaray_transfer.htm?icid=AELOLN2"  >Salary Transfer Loans</a>'+
'							<ul class="leftshowhide_sub  hidden">'+
'								<li class="lisubheadadj"><a href="../../consumer/forms/stl_form.htm?icid=AELOLN21" >Apply Now</a></li>'+
'              				</ul>'+
'				</li>'+
'              <li class="leftshowhide_sub"><a style="/*background-image:none !important;*/" href="../../consumer/loans/loans_faq.htm?icid=AELOLN3" title="FAQS">Faqs</a></li>'+
'              <li class="leftshowhide_sub"><a style="/*background-image:none !important;*/" href="../../consumer/loans/loan_calculator.htm?icid=AELOLN4" title="Loan Calculator">Loan Calculator</a></li>'+
'								<li class="leftshowhide_sub"><a href="https://www.citibank.com/uae/consumer/forms/perinstall_form.htm?icid=AELOLN5" >Apply Now</a></li>'+
'              		</ul>'+
'              </li>'+	
	
'		</ul></div>'

)

if (mobile.detect() || tablet.detect()) {
	

 	var currentpage=location.href.substr(location.href.lastIndexOf("/")+1,location.href.length)
		if(currentpage.lastIndexOf("#")!=-1)
		{
			currentpage=currentpage.substr(0,currentpage.lastIndexOf("#"));	
		}
		/*if(currentpage.lastIndexOf("?")!=-1)
		{
			currentpage=currentpage.substr(0,currentpage.lastIndexOf("?"));	
		}*/
		var ulli=document.getElementById("display-non-desk").getElementsByTagName("li"); 
		var ullia=document.getElementById("display-non-desk").getElementsByTagName("a"); 
		for ( i=0; i<ullia.length; i++)
		{
			var temp3=temp3 || {};
			var storeURL=ullia[i].href.substr(ullia[i].href.lastIndexOf("/")+1,ullia[i].href.length);	
			if(storeURL.lastIndexOf("?")!=-1)
			{
				/*currentpage=currentpage.substr(0,currentpage.lastIndexOf("?"));	
				storeURL=storeURL.substr(0,storeURL.lastIndexOf("?"));*/	
			}
		

		if (ullia[i].parentNode.className=="leftliholder" ) 
		{
			var	temp=storeURL.split("?");
		temp3=temp[0];
        var temp2=currentpage.split("?"); 
		if(temp3==temp2[0])
			{
			//alert('s')
			ullia[i].setAttribute("href", 'javascript:void(0);');	
			ullia[i].setAttribute("style", 'cursor:default;');	
			   	ulli[i].getElementsByTagName("ul")[0].style.display ='block';
			   	ullia[i].className="active_top_nav";
				//  ullia[i].parentNode.className='leftliholder leftliholder_active'
				  // ullia[i].parentNode.childNodes[0].className='active_top_nav';
			}
		}
		if (ullia[i].parentNode.className=="lisubheadadj" ) 
		 { 
			var	temp=storeURL.split("?");
		temp3=temp[0];
        var temp2=currentpage.split("?"); 
		if(temp3==temp2[0])
			{
				//alert('d')
				ullia[i].setAttribute("style", 'cursor:default;');	
				ullia[i].setAttribute("href", 'javascript:void(0);');
				 ullia[i].className="active";
				 ullia[i].parentNode.parentNode.style.display='block'
				 ullia[i].parentNode.parentNode.parentNode.className='leftliholder leftliholder_active'
			  ullia[i].parentNode.parentNode.parentNode.childNodes[0].className='active_top_nav';

			}
		}
		
		if (ullia[i].parentNode.className=="leftshowhide_sub" ) 
		{
			var	temp=storeURL.split("?");
		temp3=temp[0];
        var temp2=currentpage.split("?"); 
		if(temp3==temp2[0])
			{
			ullia[i].setAttribute("href", 'javascript:void(0);');	
			ullia[i].setAttribute("style", 'cursor:default;');
			//ulli[i].getElementsByTagName("ul")[0].style.display ='block';
				ullia[i].className="active";	
			}
	  }
  
  	
	
}
}
