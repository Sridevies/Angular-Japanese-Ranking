document.write(
'          <div class="menu" id="dvleft">'+
'            <ul id="nav-left">'+       

'              <li class="leftliholder"><a  href="../../consumer/loans/personal_installment_loans.htm?icid=AELOLN1" title="PERSONAL INSTALLMENT LOANS">Personal Installment<br> Loans</a>'+
'					<ul class="leftshowhide_sub  hidden">'+
'						<li class="lisubheadadj"><a href="../../consumer/forms/perinstall_form.htm?icid=AELOLN11" title="Apply Now">Apply Now</a></li>'+
'              		</ul>'+
'</li>'+  

'              <li class="leftliholder"><a href="../../consumer/loans/salaray_transfer.htm?icid=AELOLN2" title="SALARY TRANSFER LOANS">Salary Transfer Loans</a>'+

'					<ul class="leftshowhide_sub  hidden">'+
'						<li class="lisubheadadj"><a href="../../consumer/forms/stl_form.htm?icid=AELOLN21" title="Apply Now">Apply Now</a></li>'+
'              		</ul>'+
'</li>'+

'              <li class="leftshowhide_sub"><a style="/*background-image:none !important;*/" href="../../consumer/loans/loans_faq.htm?icid=AELOLN3" title="FAQS">Faqs</a></li>'+ 
'              <li class="leftshowhide_sub"><a style="/*background-image:none !important;*/" href="../../consumer/loans/loan_calculator.htm?icid=AELOLN4" title="LOAN CALCULATOR">Loan Calculator</a></li>'+ 
'								<li class="leftshowhide_sub"><a href="https://www.citibank.com/uae/consumer/forms/perinstall_form.htm?icid=AELOLN5" >Apply Now</a></li>'+
 /*
'              <li class="leftshowhide_sub"><a style="background-image:none !important;" href="../../consumer/forms/stl_form.htm" title="Salary Transfer Loans form">Salary Transfer Loans form</a></li>' +  */
'              </ul>'+
'        </div>'
)



 	
 var currentpage=location.href.substr(location.href.lastIndexOf("/")+1,location.href.length)
		if(currentpage.lastIndexOf("#")!=-1)
		{ 
			currentpage=currentpage.substr(0,currentpage.lastIndexOf("#"));	
		}
		/* if(currentpage.lastIndexOf("?")!=-1)
		{
			currentpage=currentpage.substr(0,currentpage.lastIndexOf("?"));	
		} */
		var ulli=document.getElementById("dvleft").getElementsByTagName("li"); 
		var ullia=document.getElementById("dvleft").getElementsByTagName("a"); 
		for ( i=0; i<ullia.length; i++)
		{ 
		var temp3=temp3 || {};
			var storeURL=ullia[i].href.substr(ullia[i].href.lastIndexOf("/")+1,ullia[i].href.length);	
			if(storeURL.lastIndexOf("?")!=-1)
			{
		var	temp=storeURL.split("?");
		temp3=temp[0];
		
				/* currentpage=currentpage.substr(0,currentpage.lastIndexOf("?"));	
				storeURL=storeURL.substr(0,storeURL.lastIndexOf("?"));	 */
			}

		if (ullia[i].parentNode.className=="leftliholder" ) 
		{
		var temp2=currentpage.split("?");
			if(temp3==temp2[0])
			{
			   	ulli[i].getElementsByTagName("ul")[0].style.display ='block';
			   	ullia[i].className="active_top_nav";
				  ullia[i].parentNode.className='leftliholder leftliholder_active'
				  				   ullia[i].setAttribute("href", 'javascript:void(0);');	
				   ullia[i].parentNode.childNodes[0].className='active_top_nav active-lis';
				   

			}
		}
		
		if (ullia[i].parentNode.className=="leftliholder borTop-none" ) 
		{
		var temp2=currentpage.split("?");
			if(temp3==temp2[0])/* 
			
			if(storeURL==currentpage) */
			{
			   	ulli[i].getElementsByTagName("ul")[0].style.display ='block';
			   	ullia[i].className="active_top_nav";
				  ullia[i].parentNode.className='leftliholder leftliholder_active borTop-none'
				   ullia[i].parentNode.childNodes[0].className='active_top_nav';
				    ullia[i].setAttribute("href", 'javascript:void(0);');	
			}
		}
		if (ulli[i].className=="lisubheadadj" )
		 { 
		 
			var temp2=currentpage.split("?");
			if(temp3==temp2[0])
			/* if(storeURL==currentpage) */
			{
				
				 ullia[i].className="active";
				 ullia[i].parentNode.parentNode.style.display='block'
				 ullia[i].parentNode.parentNode.parentNode.className='leftliholder leftliholder_active borTop-none'
			  ullia[i].parentNode.parentNode.parentNode.childNodes[0].className='active_top_nav active-lis';
 ullia[i].setAttribute("href", 'javascript:void(0);');	
 ullia[i].parentNode.parentNode.parentNode.childNodes[0].setAttribute("style",'cursor:pointer;');
			}
		}
		
		if (ullia[i].parentNode.className=="leftshowhide_sub" ) 
		{
		
			var temp2=currentpage.split("?");
			if(temp3==temp2[0])
			/* if(storeURL==currentpage) */
			{
				ullia[i].className="active";
ullia[i].href="javascript:void(0)";				
			}
	  }
  
  	
	
}
