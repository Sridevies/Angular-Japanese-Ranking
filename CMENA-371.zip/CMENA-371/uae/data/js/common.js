/*document.write('<!-- Google Code for Remarketing Tag -->'+
'<!--------------------------------------------------'+
'Remarketing tags may not be associated with personally identifiable information or placed on pages related to sensitive categories. See more information and instructions on how to setup the tag on: http://google.com/ads/remarketingsetup'+
'--------------------------------------------------->'+
'<script type="text/javascript">'+
' <![CDATA[ '+
'var google_conversion_id = 935312972;'+
'var google_custom_params = window.google_tag_params;'+
'var google_remarketing_only = true;'+
' ]]> '+
'</script>'+
'<script type="text/javascript" src="//www.googleadservices.com/pagead/conversion.js">'+
'</script>'+
'<noscript>'+
'<div style="display:inline;">'+
'<img height="1" width="1" style="border-style:none;" alt="" src="//googleads.g.doubleclick.net/pagead/viewthroughconversion/935312972/?value=0&amp;guid=ON&amp;script=0"/>'+
'</div>'+
'</noscript>');*/

(function() {
     var cx = '014040597034689477597:kkdoq03jcru';
     var gcse = document.createElement('script');
     gcse.type = 'text/javascript';
     gcse.async = true;
     gcse.src = (document.location.protocol == 'https:' ? 'https:' : 'http:') +
         '//www.google.com/cse/cse.js?cx=' + cx;
     var s = document.getElementsByTagName('script')[0];
     s.parentNode.insertBefore(gcse, s);
   })();

document.write('<link href="/CMENA-371/v1/uae/homepage/home_css/gss.css" rel="stylesheet" type="text/css">'); function enter_check(e) {
     var e=window.event || e;
         var keyunicode=e.charCode || e.keyCode;
         if (keyunicode==13)
         {
         var searchControl = google.search.cse.element.getElement('sggcbSearch');	
	searchControl.execute(document.getElementById('gsc-i-id1').value);
     }
}
var gssCallback = function() {

   if (document.readyState == 'complete') {
     // Document is ready when CSE element is initialized.		
	renderSearchControls();	
   } else {
     google.setOnLoadCallback(renderSearchControls, false);
   }
};

var gsearch = function() {
	var searchControl = google.search.cse.element.getElement('sggcbSearch');	
	searchControl.execute(document.getElementById('gsc-i-id1').value);
};

var renderSearchControls = function() {
	google.search.cse.element.render(
	{
	  div: "gssSearchBox",
	  tag: 'searchbox-only',
	  gname: 'sggcbSearch',
	  attributes: {resultsUrl: '/CMENA-371/v1/uae/main/search/search.htm'}
	});	
	
	if (document.getElementById('gssSearchResults')) {
		
		google.search.cse.element.render(
         {
           div: "gssSearchResults",
           tag: 'searchresults-only',
		  gname: 'sggcbSearch'
         });
	}
};

// Insert it before the CSE code snippet so that cse.js can take the script // parameters, like parsetags, callbacks.
window.__gcse = {
   parsetags: 'explicit', callback: gssCallback };



var is_touch_device='ontouchstart'in document.documentElement;var mobile=function(){return{detect:(function(a,b){a=navigator.userAgent;if(/(ipad|playbook|silk|android|bb\d+|meego).+mobile|avantgo|bada\/|blackberry|blazer|compal|elaine|fennec|hiptop|iemobile|ip(hone|od)|iris|kindle|lge |maemo|midp|mmp|netfront|opera m(ob|in)i|palm( os)?|phone|p(ixi|re)\/|plucker|pocket|psp|series(4|6)0|symbian|treo|up\.(browser|link)|vodafone|wap|windows (ce|phone)|xda|xiino/i.test(a)||/1207|6310|6590|3gso|4thp|50[1-6]i|770s|802s|a wa|abac|ac(er|oo|s\-)|ai(ko|rn)|al(av|ca|co)|amoi|an(ex|ny|yw)|aptu|ar(ch|go)|as(te|us)|attw|au(di|\-m|r |s )|avan|be(ck|ll|nq)|bi(lb|rd)|bl(ac|az)|br(e|v)w|bumb|bw\-(n|u)|c55\/|capi|ccwa|cdm\-|cell|chtm|cldc|cmd\-|co(mp|nd)|craw|da(it|ll|ng)|dbte|dc\-s|devi|dica|dmob|do(c|p)o|ds(12|\-d)|el(49|ai)|em(l2|ul)|er(ic|k0)|esl8|ez([4-7]0|os|wa|ze)|fetc|fly(\-|_)|g1 u|g560|gene|gf\-5|g\-mo|go(\.w|od)|gr(ad|un)|haie|hcit|hd\-(m|p|t)|hei\-|hi(pt|ta)|hp( i|ip)|hs\-c|ht(c(\-| |_|a|g|p|s|t)|tp)|hu(aw|tc)|i\-(20|go|ma)|i230|iac( |\-|\/)|ibro|idea|ig01|ikom|im1k|inno|ipaq|iris|ja(t|v)a|jbro|jemu|jigs|kddi|keji|kgt( |\/)|klon|kpt |kwc\-|kyo(c|k)|le(no|xi)|lg( g|\/(k|l|u)|50|54|\-[a-w])|libw|lynx|m1\-w|m3ga|m50\/|ma(te|ui|xo)|mc(01|21|ca)|m\-cr|me(rc|ri)|mi(o8|oa|ts)|mmef|mo(01|02|bi|de|do|t(\-| |o|v)|zz)|mt(50|p1|v )|mwbp|mywa|n10[0-2]|n20[2-3]|n30(0|2)|n50(0|2|5)|n7(0(0|1)|10)|ne((c|m)\-|on|tf|wf|wg|wt)|nok(6|i)|nzph|o2im|op(ti|wv)|oran|owg1|p800|pan(a|d|t)|pdxg|pg(13|\-([1-8]|c))|phil|pire|pl(ay|uc)|pn\-2|po(ck|rt|se)|prox|psio|pt\-g|qa\-a|qc(07|12|21|32|60|\-[2-7]|i\-)|qtek|r380|r600|raks|rim9|ro(ve|zo)|s55\/|sa(ge|ma|mm|ms|ny|va)|sc(01|h\-|oo|p\-)|sdk\/|se(c(\-|0|1)|47|mc|nd|ri)|sgh\-|shar|sie(\-|m)|sk\-0|sl(45|id)|sm(al|ar|b3|it|t5)|so(ft|ny)|sp(01|h\-|v\-|v )|sy(01|mb)|t2(18|50)|t6(00|10|18)|ta(gt|lk)|tcl\-|tdg\-|tel(i|m)|tim\-|t\-mo|to(pl|sh)|ts(70|m\-|m3|m5)|tx\-9|up(\.b|g1|si)|utst|v400|v750|veri|vi(rg|te)|vk(40|5[0-3]|\-v)|vm40|voda|vulc|vx(52|53|60|61|70|80|81|83|85|98)|w3c(\-| )|webc|whit|wi(g |nc|nw)|wmlb|wonu|x700|yas\-|your|zeto|zte\-/i.test(a.substr(0,4)))return true;else return false;})};}();var appleOS=function(){return{detect:function(){var uagent=navigator.userAgent.toLowerCase();var list=this.ios;var isApple=false;for(var d=0;d<list.length;d+=1){if(uagent.indexOf(list[d])!=-1){isApple=true;}}
return isApple;},ios:["iphone","ipod","ipad"]};}();$(document).ready(function(){$(".closeClick").click(function(){$(".popup-overlay").removeClass("show");$("#overlay").removeClass("show");$(".popup").removeClass('show');enable_scroll();return false;});if(mobile.detect()){}
if($.browser.msie&&$.browser.version<=9.0){setTimeout(function(){$.getScript("/CMENA-371/v1/uae/data/js/PIE.js",function(){if(window.PIE){$('.rounded, .curvedCorners,.ui-slider-range').each(function(){PIE.attach(this);});}})},100);}})
function clsChgLang(obj){if(obj=="en")
{$(".clsChgLang").attr("href",location.pathname.replace("/en/","/id/")+location.search)}
if(obj=="id")
{$(".clsChgLang").attr("href",location.pathname.replace("/id/","/en/")+location.search)}}
function activateLink(para){$(".footerList li").eq(para).find('a').addClass("activeTabHighlight")}
(function($){$.fn.setEqualHeight=function(ele){var maxHeight=0,maxElement=null;var maxHeight1=0,maxElement1=null;var maxHeight2=0,maxElement2=null;$(ele).css({"height":"auto"});$(ele).each(function(){if(($(this).height()+parseInt($(this).css("padding-bottom"))+parseInt($(this).css("padding-top")))>maxHeight){maxHeight=$(this).height()+parseInt($(this).css("padding-top"))+parseInt($(this).css("padding-bottom"));maxElement=this;}
if($(this).children('p').html()!='undefined')
{if(($(this).children('p').height()+parseInt($(this).children('p').css("padding-bottom"))+parseInt($(this).children('p').css("padding-top")))>maxHeight1){maxHeight1=$(this).children('p').height()+parseInt($(this).css("padding-top"))+parseInt($(this).children('p').css("padding-bottom"));maxElement1=this;}}});$(ele).not($(maxElement)).each(function(){$(this).height(maxHeight-parseInt($(this).css("padding-top"))-parseInt($(this).css("padding-bottom")))});};$.fn.setEqualHeight1=function(ele){var maxHeight3=0,maxElement3=null;var maxHeight4=0,maxElement4=null;var maxHeight5=0,maxElement5=null;var maxHeight6=0,maxElement6=null;var maxHeight7=0,maxElement7=null;$('.dd00').each(function(){if(($(this).height()+parseInt($(this).css("padding-bottom"))+parseInt($(this).css("padding-top")))>maxHeight3){maxHeight3=$(this).height()+parseInt($(this).css("padding-top"))+parseInt($(this).css("padding-bottom"));maxElement3=this;}});$('.dd11').each(function(){if(($(this).height()+parseInt($(this).css("padding-bottom"))+parseInt($(this).css("padding-top")))>maxHeight4){maxHeight4=$(this).height()+parseInt($(this).css("padding-top"))+parseInt($(this).css("padding-bottom"));maxElement4=this;}});$('.dd22').each(function(){if(($(this).height()+parseInt($(this).css("padding-bottom"))+parseInt($(this).css("padding-top")))>maxHeight5){maxHeight5=$(this).height()+parseInt($(this).css("padding-top"))+parseInt($(this).css("padding-bottom"));maxElement5=this;}});$('.dd33').each(function(){if(($(this).height()+parseInt($(this).css("padding-bottom"))+parseInt($(this).css("padding-top")))>maxHeight6){maxHeight6=$(this).height()+parseInt($(this).css("padding-top"))+parseInt($(this).css("padding-bottom"));maxElement6=this;}});$('.dd44').each(function(){if(($(this).height()+parseInt($(this).css("padding-bottom"))+parseInt($(this).css("padding-top")))>maxHeight7){maxHeight7=$(this).height()+parseInt($(this).css("padding-top"))+parseInt($(this).css("padding-bottom"));maxElement7=this;}});$('.dd00').not($(maxElement3)).each(function(){$(this).height(maxHeight3-parseInt($(this).css("padding-top"))-parseInt($(this).css("padding-bottom")))});$('.dd11').not($(maxElement4)).each(function(){$(this).height(maxHeight4-parseInt($(this).css("padding-top"))-parseInt($(this).css("padding-bottom")))});$('.dd22').not($(maxElement5)).each(function(){$(this).height(maxHeight5-parseInt($(this).css("padding-top"))-parseInt($(this).css("padding-bottom")))});$('.dd33').not($(maxElement6)).each(function(){$(this).height(maxHeight6-parseInt($(this).css("padding-top"))-parseInt($(this).css("padding-bottom")))});$('.dd44').not($(maxElement7)).each(function(){$(this).height(maxHeight7-parseInt($(this).css("padding-top"))-parseInt($(this).css("padding-bottom")))});$('.dd5').not($(maxElement5)).each(function(){$(this).height(maxHeight5-parseInt($(this).css("padding-top"))-parseInt($(this).css("padding-bottom")))});};$.fn.setEqualHeight2=function(ele){var maxHeight31=0,maxElement31=null;var maxHeight41=0,maxElement41=null;var maxHeight51=0,maxElement51=null;var maxHeight61=0,maxElement61=null;var maxHeight71=0,maxElement71=null;var maxHeight81=0,maxElement81=null;var maxHeight311=0,maxElement311=null;var maxHeight411=0,maxElement411=null;var maxHeight511=0,maxElement511=null;var maxHeight611=0,maxElement611=null;var maxHeight711=0,maxElement711=null;var maxHeight811=0,maxElement811=null;$('.dd000').each(function(){if(($(this).height()+parseInt($(this).css("padding-bottom"))+parseInt($(this).css("padding-top")))>maxHeight311){maxHeight311=$(this).height()+parseInt($(this).css("padding-top"))+parseInt($(this).css("padding-bottom"));maxElement311=this;}});$('.dd111').each(function(){if(($(this).height()+parseInt($(this).css("padding-bottom"))+parseInt($(this).css("padding-top")))>maxHeight411){maxHeight411=$(this).height()+parseInt($(this).css("padding-top"))+parseInt($(this).css("padding-bottom"));maxElement411=this;}});$('.dd222').each(function(){if(($(this).height()+parseInt($(this).css("padding-bottom"))+parseInt($(this).css("padding-top")))>maxHeight511){maxHeight511=$(this).height()+parseInt($(this).css("padding-top"))+parseInt($(this).css("padding-bottom"));maxElement511=this;}});$('.dd333').each(function(){if(($(this).height()+parseInt($(this).css("padding-bottom"))+parseInt($(this).css("padding-top")))>maxHeight611){maxHeight611=$(this).height()+parseInt($(this).css("padding-top"))+parseInt($(this).css("padding-bottom"));maxElement611=this;}});$('.dd444').each(function(){if(($(this).height()+parseInt($(this).css("padding-bottom"))+parseInt($(this).css("padding-top")))>maxHeight711){maxHeight711=$(this).height()+parseInt($(this).css("padding-top"))+parseInt($(this).css("padding-bottom"));maxElement711=this;}});$('.dd555').each(function(){if(($(this).height()+parseInt($(this).css("padding-bottom"))+parseInt($(this).css("padding-top")))>maxHeight811){maxHeight811=$(this).height()+parseInt($(this).css("padding-top"))+parseInt($(this).css("padding-bottom"));maxElement811=this;}});$('.dd000').not($(maxElement311)).each(function(){$(this).height(maxHeight311-parseInt($(this).css("padding-top"))-parseInt($(this).css("padding-bottom")))});$('.dd111').not($(maxElement411)).each(function(){$(this).height(maxHeight411-parseInt($(this).css("padding-top"))-parseInt($(this).css("padding-bottom")))});$('.dd222').not($(maxElement511)).each(function(){$(this).height(maxHeight511-parseInt($(this).css("padding-top"))-parseInt($(this).css("padding-bottom")))});$('.dd333').not($(maxElement611)).each(function(){$(this).height(maxHeight611-parseInt($(this).css("padding-top"))-parseInt($(this).css("padding-bottom")))});$('.dd444').not($(maxElement711)).each(function(){$(this).height(maxHeight711-parseInt($(this).css("padding-top"))-parseInt($(this).css("padding-bottom")))});$('.dd555').not($(maxElement811)).each(function(){$(this).height(maxHeight811-parseInt($(this).css("padding-top"))-parseInt($(this).css("padding-bottom")))});};$.fn.setEqualHeight3=function(ele){var maxHeight3=0,maxElement3=null;var maxHeight4=0,maxElement4=null;var maxHeight5=0,maxElement5=null;var maxHeight6=0,maxElement6=null;var maxHeight7=0,maxElement7=null;$('.dd').each(function(){if(($(this).height()+parseInt($(this).css("padding-bottom"))+parseInt($(this).css("padding-top")))>maxHeight3){maxHeight3=$(this).height()+parseInt($(this).css("padding-top"))+parseInt($(this).css("padding-bottom"));maxElement3=this;}});$('.dd1').each(function(){if(($(this).height()+parseInt($(this).css("padding-bottom"))+parseInt($(this).css("padding-top")))>maxHeight4){maxHeight4=$(this).height()+parseInt($(this).css("padding-top"))+parseInt($(this).css("padding-bottom"));maxElement4=this;}});$('.dd2').each(function(){if(($(this).height()+parseInt($(this).css("padding-bottom"))+parseInt($(this).css("padding-top")))>maxHeight5){maxHeight5=$(this).height()+parseInt($(this).css("padding-top"))+parseInt($(this).css("padding-bottom"));maxElement5=this;}});$('.dd3').each(function(){if(($(this).height()+parseInt($(this).css("padding-bottom"))+parseInt($(this).css("padding-top")))>maxHeight6){maxHeight6=$(this).height()+parseInt($(this).css("padding-top"))+parseInt($(this).css("padding-bottom"));maxElement6=this;}});$('.dd4').each(function(){if(($(this).height()+parseInt($(this).css("padding-bottom"))+parseInt($(this).css("padding-top")))>maxHeight7){maxHeight7=$(this).height()+parseInt($(this).css("padding-top"))+parseInt($(this).css("padding-bottom"));maxElement7=this;}});$('.dd').not($(maxElement3)).each(function(){$(this).height(maxHeight3-parseInt($(this).css("padding-top"))-parseInt($(this).css("padding-bottom")))});$('.dd1').not($(maxElement4)).each(function(){$(this).height(maxHeight4-parseInt($(this).css("padding-top"))-parseInt($(this).css("padding-bottom")))});$('.dd2').not($(maxElement5)).each(function(){$(this).height(maxHeight5-parseInt($(this).css("padding-top"))-parseInt($(this).css("padding-bottom")))});$('.dd3').not($(maxElement6)).each(function(){$(this).height(maxHeight6-parseInt($(this).css("padding-top"))-parseInt($(this).css("padding-bottom")))});$('.dd4').not($(maxElement7)).each(function(){$(this).height(maxHeight7-parseInt($(this).css("padding-top"))-parseInt($(this).css("padding-bottom")))});$('.dd5').not($(maxElement5)).each(function(){$(this).height(maxHeight5-parseInt($(this).css("padding-top"))-parseInt($(this).css("padding-bottom")))});};})(jQuery);$(window).on("resize",function(event){if(location.href.indexOf('affinity_card_mastercard.htm')==-1)
{if(navigator.userAgent.indexOf('MSIE 7.0')==-1&&navigator.userAgent.indexOf('MSIE 8.0')==-1)
{myEqualHeight();}}})
$(window).on("orientationchange",function(event){setTimeout(heightremove,250);setTimeout(myEqualHeight,250);})
function myEqualHeight(){var prole=$('.double-inner').length;if($('body').width()>'1024'){for(var j=0;j<=prole;j++){if(j<=1){$('.double-inner:eq('+j+')').addClass('dd').removeClass('dd2').removeClass('dd1').removeClass('dd3').removeClass('dd4').removeClass('dd5');$('.double-inner:eq('+j+')').parent().addClass('dd00').removeClass('dd11').removeClass('dd22').removeClass('dd33').removeClass('dd44').removeClass('dd55');$('.double-inner:eq('+j+')').children('h3').addClass('dd000').removeClass('dd111').removeClass('dd222').removeClass('dd333').removeClass('dd444').removeClass('dd555');}
if(j>=2&&j<=3){$('.double-inner:eq('+j+')').addClass('dd1').removeClass('dd2').removeClass('dd').removeClass('dd3').removeClass('dd4').removeClass('dd5');$('.double-inner:eq('+j+')').parent().addClass('dd11').removeClass('dd00').removeClass('dd22').removeClass('dd33').removeClass('dd44').removeClass('dd55');$('.double-inner:eq('+j+')').children('h3').addClass('dd111').removeClass('dd000').removeClass('dd222').removeClass('dd333').removeClass('dd444').removeClass('dd555');}
if(j>=4&&j<=5){$('.double-inner:eq('+j+')').addClass('dd2').removeClass('dd1').removeClass('dd').removeClass('dd3').removeClass('dd4').removeClass('dd5');$('.double-inner:eq('+j+')').parent().addClass('dd22').removeClass('dd00').removeClass('dd11').removeClass('dd33').removeClass('dd44').removeClass('dd55');$('.double-inner:eq('+j+')').children('h3').addClass('dd222').removeClass('dd000').removeClass('dd111').removeClass('dd333').removeClass('dd444').removeClass('dd555');}
if(j>=6&&j<=7){$('.double-inner:eq('+j+')').addClass('dd3').removeClass('dd1').removeClass('dd').removeClass('dd2').removeClass('dd4').removeClass('dd5');$('.double-inner:eq('+j+')').parent().addClass('dd33').removeClass('dd00').removeClass('dd11').removeClass('dd22').removeClass('dd44').removeClass('dd55');$('.double-inner:eq('+j+')').children('h3').addClass('dd333').removeClass('dd000').removeClass('dd111').removeClass('dd222').removeClass('dd444').removeClass('dd555');}}}
if($('body').width()<=1024&&$('body').width()>=558){for(var j=0;j<=prole;j++){if(j<=1){$('.double-inner:eq('+j+')').addClass('dd').removeClass('dd2').removeClass('dd1').removeClass('dd3').removeClass('dd4').removeClass('dd5');$('.double-inner:eq('+j+')').parent().addClass('dd00').removeClass('dd11').removeClass('dd22').removeClass('dd33').removeClass('dd44').removeClass('dd55');$('.double-inner:eq('+j+')').children('h3').addClass('dd000').removeClass('dd111').removeClass('dd222').removeClass('dd333').removeClass('dd444').removeClass('dd555');}
if(j>=2&&j<=3){$('.double-inner:eq('+j+')').addClass('dd1').removeClass('dd2').removeClass('dd').removeClass('dd3').removeClass('dd4').removeClass('dd5');$('.double-inner:eq('+j+')').parent().addClass('dd11').removeClass('dd00').removeClass('dd22').removeClass('dd33').removeClass('dd44').removeClass('dd55');$('.double-inner:eq('+j+')').children('h3').addClass('dd111').removeClass('dd000').removeClass('dd222').removeClass('dd333').removeClass('dd444').removeClass('dd555');}
if(j>=4&&j<=5){$('.double-inner:eq('+j+')').addClass('dd2').removeClass('dd1').removeClass('dd').removeClass('dd3').removeClass('dd4').removeClass('dd5');$('.double-inner:eq('+j+')').parent().addClass('dd22').removeClass('dd00').removeClass('dd11').removeClass('dd33').removeClass('dd44').removeClass('dd55');$('.double-inner:eq('+j+')').children('h3').addClass('dd222').removeClass('dd000').removeClass('dd111').removeClass('dd333').removeClass('dd444').removeClass('dd555');}
if(j>=6&&j<=7){$('.double-inner:eq('+j+')').addClass('dd3').removeClass('dd1').removeClass('dd').removeClass('dd2').removeClass('dd4').removeClass('dd5');$('.double-inner:eq('+j+')').parent().addClass('dd33').removeClass('dd00').removeClass('dd11').removeClass('dd22').removeClass('dd44').removeClass('dd55');$('.double-inner:eq('+j+')').children('h3').addClass('dd333').removeClass('dd000').removeClass('dd111').removeClass('dd222').removeClass('dd444').removeClass('dd555');}}}
$(".double-inner").each(function(){$("body").setEqualHeight1($(".dd00",this));$("body").setEqualHeight3($(".dd",this));$("body").setEqualHeight2($(".dd000",this));})
var prolegth1=$('.box').length;if($('body').width()>'1024')
{for(var i=0;i<=prolegth1;i++)
{if(i<=2)
{$('.box:eq('+i+')').addClass('dd').removeClass('dd2').removeClass('dd1').removeClass('dd3').removeClass('dd4').removeClass('dd5');$('.box:eq('+i+')').parent().addClass('dd000').removeClass('dd111').removeClass('dd222').removeClass('dd333').removeClass('dd444').removeClass('dd555');}
if(i>=3&&i<=5)
{$('.box:eq('+i+')').addClass('dd1').removeClass('dd').removeClass('dd2').removeClass('dd3').removeClass('dd4').removeClass('dd5');$('.box:eq('+i+')').parent().addClass('dd111').removeClass('dd000').removeClass('dd222').removeClass('dd333').removeClass('dd444').removeClass('dd555');}}}
$(".box").each(function(){$("body").setEqualHeight1($(".dd00",this));$("body").setEqualHeight3($(".dd",this));$("body").setEqualHeight2($(".dd000",this));})
var prolegth=$('.productsListDetails').length;if($('body').width()>'1024')
{for(var i=0;i<=prolegth;i++)
{if(i<=2)
{$('.productsListDetails:eq('+i+')').addClass('dd').removeClass('dd2').removeClass('dd1').removeClass('dd3').removeClass('dd4').removeClass('dd5');$('.productsListDetails:eq('+i+')').parent().children('h3').addClass('dd00').removeClass('dd11').removeClass('dd22').removeClass('dd33').removeClass('dd44').removeClass('dd55');$('.productsListDetails:eq('+i+')').parent().addClass('dd000').removeClass('dd111').removeClass('dd222').removeClass('dd333').removeClass('dd444').removeClass('dd555');}
if(i>=3&&i<=5)
{$('.productsListDetails:eq('+i+')').addClass('dd1').removeClass('dd').removeClass('dd2').removeClass('dd3').removeClass('dd4').removeClass('dd5');$('.productsListDetails:eq('+i+')').parent().children('h3').addClass('dd11').removeClass('dd00').removeClass('dd22').removeClass('dd33').removeClass('dd44').removeClass('dd55');$('.productsListDetails:eq('+i+')').parent().addClass('dd111').removeClass('dd000').removeClass('dd222').removeClass('dd333').removeClass('dd444').removeClass('dd555');}

if(i>=6&&i<=8)
{$('.productsListDetails:eq('+i+')').addClass('dd2').removeClass('dd1').removeClass('dd').removeClass('dd3').removeClass('dd4').removeClass('dd5');$('.productsListDetails:eq('+i+')').parent().children('h3').addClass('dd22').removeClass('dd55').removeClass('dd11').removeClass('dd33').removeClass('dd44').removeClass('dd00');$('.productsListDetails:eq('+i+')').parent().addClass('dd222').removeClass('dd111').removeClass('dd000').removeClass('dd333').removeClass('dd444').removeClass('dd555');}
if(i>=9&&i<=11)
{$('.productsListDetails:eq('+i+')').addClass('dd3').removeClass('dd1').removeClass('dd2').removeClass('dd').removeClass('dd4').removeClass('dd5');$('.productsListDetails:eq('+i+')').parent().children('h3').addClass('dd33').removeClass('dd11').removeClass('dd22').removeClass('dd55').removeClass('dd44').removeClass('dd00');$('.productsListDetails:eq('+i+')').parent().addClass('dd333').removeClass('dd111').removeClass('dd222').removeClass('dd000').removeClass('dd444').removeClass('dd555');}
if(i>=12&&i<=14)
{$('.productsListDetails:eq('+i+')').addClass('dd4').removeClass('dd1').removeClass('dd2').removeClass('dd3').removeClass('dd').removeClass('dd5');$('.productsListDetails:eq('+i+')').parent().children('h3').addClass('dd11').removeClass('dd55').removeClass('dd22').removeClass('dd33').removeClass('dd44').removeClass('dd00');$('.productsListDetails:eq('+i+')').parent().addClass('dd444').removeClass('dd111').removeClass('dd222').removeClass('dd333').removeClass('dd000').removeClass('dd555');}
if(i>=15&&i<=17)
{$('.productsListDetails:eq('+i+')').addClass('dd5').removeClass('dd1').removeClass('dd2').removeClass('dd3').removeClass('dd4').removeClass('dd');$('.productsListDetails:eq('+i+')').parent().children('h3').addClass('dd55').removeClass('dd11').removeClass('dd22').removeClass('dd33').removeClass('dd44').removeClass('dd00');$('.productsListDetails:eq('+i+')').parent().addClass('dd555').removeClass('dd111').removeClass('dd222').removeClass('dd333').removeClass('dd444').removeClass('dd000');}}}
if($('body').width()<=1024&&$('body').width()>=558)
{for(var i=0;i<=prolegth;i++)
{if(i<=1)
{$('.productsListDetails:eq('+i+')').addClass('dd').removeClass('dd2').removeClass('dd1').removeClass('dd3').removeClass('dd4').removeClass('dd5').removeClass('dd6').removeClass('dd7');$('.productsListDetails:eq('+i+')').parent().children('h3').addClass('dd00').removeClass('dd22').removeClass('dd77').removeClass('dd33').removeClass('dd44').removeClass('dd55').removeClass('dd66').removeClass('dd11');$('.productsListDetails:eq('+i+')').parent().addClass('dd000').removeClass('dd222').removeClass('dd777').removeClass('dd333').removeClass('dd444').removeClass('dd555').removeClass('dd666').removeClass('dd111');}
if(i>=2&&i<=3)
{$('.productsListDetails:eq('+i+')').addClass('dd1').removeClass('dd2').removeClass('dd').removeClass('dd3').removeClass('dd4').removeClass('dd5').removeClass('dd6').removeClass('dd7');$('.productsListDetails:eq('+i+')').parent().children('h3').addClass('dd11').removeClass('dd22').removeClass('dd77').removeClass('dd33').removeClass('dd44').removeClass('dd55').removeClass('dd66').removeClass('dd00');$('.productsListDetails:eq('+i+')').parent().addClass('dd111').removeClass('dd222').removeClass('dd777').removeClass('dd333').removeClass('dd444').removeClass('dd555').removeClass('dd666').removeClass('dd000');}
if(i>=4&&i<=5)
{$('.productsListDetails:eq('+i+')').addClass('dd2').removeClass('dd').removeClass('dd1').removeClass('dd3').removeClass('dd4').removeClass('dd5').removeClass('dd6').removeClass('dd7');$('.productsListDetails:eq('+i+')').parent().children('h3').addClass('dd22').removeClass('dd11').removeClass('dd77').removeClass('dd33').removeClass('dd44').removeClass('dd55').removeClass('dd66').removeClass('dd00');$('.productsListDetails:eq('+i+')').parent().addClass('dd222').removeClass('dd000').removeClass('dd777').removeClass('dd333').removeClass('dd444').removeClass('dd555').removeClass('dd666').removeClass('dd111');}
if(i>=6&&i<=7)
{$('.productsListDetails:eq('+i+')').addClass('dd3').removeClass('dd2').removeClass('dd1').removeClass('dd').removeClass('dd4').removeClass('dd5').removeClass('dd6').removeClass('dd7');$('.productsListDetails:eq('+i+')').parent().children('h3').addClass('dd33').removeClass('dd77').removeClass('dd11').removeClass('dd22').removeClass('dd44').removeClass('dd55').removeClass('dd66').removeClass('dd00');$('.productsListDetails:eq('+i+')').parent().addClass('dd333').removeClass('dd222').removeClass('dd777').removeClass('dd444').removeClass('dd000').removeClass('dd555').removeClass('dd666').removeClass('dd111');}
if(i>=8&&i<=9)
{$('.productsListDetails:eq('+i+')').addClass('dd4').removeClass('dd2').removeClass('dd1').removeClass('dd3').removeClass('dd').removeClass('dd5').removeClass('dd6').removeClass('dd7');$('.productsListDetails:eq('+i+')').parent().children('h3').addClass('dd44').removeClass('dd22').removeClass('dd11').removeClass('dd33').removeClass('dd77').removeClass('dd55').removeClass('dd66').removeClass('dd00');$('.productsListDetails:eq('+i+')').parent().addClass('dd444').removeClass('dd222').removeClass('dd777').removeClass('dd333').removeClass('dd000').removeClass('dd555').removeClass('dd666').removeClass('dd111');}
if(i>=10&&i<=11)
{$('.productsListDetails:eq('+i+')').addClass('dd5').removeClass('dd2').removeClass('dd1').removeClass('dd3').removeClass('dd4').removeClass('dd').removeClass('dd6').removeClass('dd7');$('.productsListDetails:eq('+i+')').parent().children('h3').addClass('dd55').removeClass('dd22').removeClass('dd11').removeClass('dd33').removeClass('dd44').removeClass('dd77').removeClass('dd66').removeClass('dd00');$('.productsListDetails:eq('+i+')').parent().addClass('dd555').removeClass('dd222').removeClass('dd777').removeClass('dd333').removeClass('dd444').removeClass('dd000').removeClass('dd666').removeClass('dd111');}
if(i>=12&&i<=13)
{$('.productsListDetails:eq('+i+')').addClass('dd6').removeClass('dd2').removeClass('dd1').removeClass('dd3').removeClass('dd4').removeClass('dd5').removeClass('dd').removeClass('dd7');$('.productsListDetails:eq('+i+')').parent().children('h3').addClass('dd66').removeClass('dd22').removeClass('dd11').removeClass('dd33').removeClass('dd44').removeClass('dd55').removeClass('dd77').removeClass('dd00');$('.productsListDetails:eq('+i+')').parent().addClass('dd666').removeClass('dd222').removeClass('dd777').removeClass('dd333').removeClass('dd444').removeClass('dd555').removeClass('dd000').removeClass('dd111');}
if(i>=14&&i<=15)
{$('.productsListDetails:eq('+i+')').addClass('dd7').removeClass('dd2').removeClass('dd1').removeClass('dd3').removeClass('dd4').removeClass('dd5').removeClass('dd6').removeClass('dd');$('.productsListDetails:eq('+i+')').parent().children('h3').addClass('dd77').removeClass('dd22').removeClass('dd11').removeClass('dd33').removeClass('dd44').removeClass('dd55').removeClass('dd66').removeClass('dd00');$('.productsListDetails:eq('+i+')').parent().addClass('dd777').removeClass('dd222').removeClass('dd000').removeClass('dd333').removeClass('dd444').removeClass('dd555').removeClass('dd666').removeClass('dd111');}}}
$(".productWrap").each(function(){$("body").setEqualHeight1($("h2",this));$("body").setEqualHeight($(".dd00",this));$("body").setEqualHeight($(".dd",this));$("body").setEqualHeight($(".dd000",this));})
$(".productWrap").each(function(){$("body").setEqualHeight($("h2",this));$("body").setEqualHeight($(".dd11",this));$("body").setEqualHeight($(".dd1",this));$("body").setEqualHeight($(".dd111",this));})
$(".productWrap").each(function(){$("body").setEqualHeight($("h2",this));$("body").setEqualHeight($(".dd22",this));$("body").setEqualHeight($(".dd2",this));$("body").setEqualHeight($(".dd222",this));})
$(".productWrap").each(function(){$("body").setEqualHeight($("h2",this));$("body").setEqualHeight($(".dd33",this));$("body").setEqualHeight($(".dd3",this));$("body").setEqualHeight($(".dd333",this));})
$(".productWrap").each(function(){$("body").setEqualHeight($("h2",this));$("body").setEqualHeight($(".dd44",this));$("body").setEqualHeight($(".dd4",this));$("body").setEqualHeight($(".dd444",this));})
$(".productWrap").each(function(){$("body").setEqualHeight($("h2",this));$("body").setEqualHeight($(".dd55",this));$("body").setEqualHeight($(".dd5",this));$("body").setEqualHeight($(".dd555",this));})
$(".bottomLinksWrap").each(function(){$("body").setEqualHeight($("li h3",this));$("body").setEqualHeight($("li.left, li.center, li.right",this));})
$(".microAccessLst, .micProdLstDet").each(function(){$("body").setEqualHeight($("h3",this));$("body").setEqualHeight($("p",this));$("body").setEqualHeight($(".left, .center, .right",this));})
$(".dealsDetails").each(function(){$("body").setEqualHeight($("li p",this));$("body").setEqualHeight($("li a",this));})
$(".promoInnBlock").each(function(){$("body").setEqualHeight($("li h3",this));$("body").setEqualHeight($("li.left, li.right",this));})
$(".promoInnBlock").each(function(){$("body").setEqualHeight($("li h3",this));$("body").setEqualHeight($("li.left.features, li.right.features",this));})
$(".promoBoxBlock").each(function(){$("body").setEqualHeight($("li h3",this));$("body").setEqualHeight($("li.left, li.right",this));})
$(".miciconBlockShow").each(function(){$("body").setEqualHeight($("li h3"));$("body").setEqualHeight($("li p"));})
$(".mainLst").each(function(){$("body").setEqualHeight($("h4",this));$("body").setEqualHeight($("p",this));$("body").setEqualHeight($("li.left, li.right",this));})
$(".premierMilesLstInn").each(function(){$("body").setEqualHeight($("h3",this));$("body").setEqualHeight($("p",this));})
$(".mobGetList").each(function(){$("body").setEqualHeight($(".mobGetList ul li",this));$("body").setEqualHeight($("p",this));$("body").setEqualHeight($("h3",this));})
var prolegth=$('.sitemap-col').length;if($('body').width()>'1024')
{for(var i=0;i<=prolegth;i++)
{if(i<=2)
{$('.sitemap-col:eq('+i+')').addClass('dd').removeClass('dd2').removeClass('dd1').removeClass('dd3').removeClass('dd4').removeClass('dd5');}
if(i>=3&&i<=5)
{$('.sitemap-col:eq('+i+')').addClass('dd1').removeClass('dd').removeClass('dd2').removeClass('dd3').removeClass('dd4').removeClass('dd5');}
if(i>=6&&i<=8)
{$('.sitemap-col:eq('+i+')').addClass('dd2').removeClass('dd1').removeClass('dd').removeClass('dd3').removeClass('dd4').removeClass('dd5');}
if(i>=9&&i<=11)
{$('.sitemap-col:eq('+i+')').addClass('dd3').removeClass('dd1').removeClass('dd2').removeClass('dd').removeClass('dd4').removeClass('dd5');}
if(i>=12&&i<=14)
{$('.sitemap-col:eq('+i+')').addClass('dd4').removeClass('dd1').removeClass('dd2').removeClass('dd3').removeClass('dd').removeClass('dd5');}
if(i>=15&&i<=17)
{$('.sitemap-col:eq('+i+')').addClass('dd5').removeClass('dd1').removeClass('dd2').removeClass('dd3').removeClass('dd4').removeClass('dd');}}}
if($('body').width()<=1024&&$('body').width()>=558)
{for(var i=0;i<=prolegth;i++)
{if(i<=1)
{$('.sitemap-col:eq('+i+')').addClass('dd').removeClass('dd2').removeClass('dd1').removeClass('dd3').removeClass('dd4').removeClass('dd5').removeClass('dd6').removeClass('dd7');}
if(i>=2&&i<=3)
{$('.sitemap-col:eq('+i+')').addClass('dd1').removeClass('dd2').removeClass('dd').removeClass('dd3').removeClass('dd4').removeClass('dd5').removeClass('dd6').removeClass('dd7');}
if(i>=4&&i<=5)
{$('.sitemap-col:eq('+i+')').addClass('dd2').removeClass('dd').removeClass('dd1').removeClass('dd3').removeClass('dd4').removeClass('dd5').removeClass('dd6').removeClass('dd7');}
if(i>=6&&i<=7)
{$('.sitemap-col:eq('+i+')').addClass('dd3').removeClass('dd2').removeClass('dd1').removeClass('dd').removeClass('dd4').removeClass('dd5').removeClass('dd6').removeClass('dd7');}
if(i>=8&&i<=9)
{$('.sitemap-col:eq('+i+')').addClass('dd4').removeClass('dd2').removeClass('dd1').removeClass('dd3').removeClass('dd').removeClass('dd5').removeClass('dd6').removeClass('dd7');}
if(i>=10&&i<=11)
{$('.sitemap-col:eq('+i+')').addClass('dd5').removeClass('dd2').removeClass('dd1').removeClass('dd3').removeClass('dd4').removeClass('dd').removeClass('dd6').removeClass('dd7');}
if(i>=12&&i<=13)
{$('.sitemap-col:eq('+i+')').addClass('dd6').removeClass('dd2').removeClass('dd1').removeClass('dd3').removeClass('dd4').removeClass('dd5').removeClass('dd').removeClass('dd7');}
if(i>=14&&i<=15)
{$('.sitemap-col:eq('+i+')').addClass('dd7').removeClass('dd2').removeClass('dd1').removeClass('dd3').removeClass('dd4').removeClass('dd5').removeClass('dd6').removeClass('dd');}}}
$(".sitemap-row").each(function(){$("body").setEqualHeight($(".dd",this));})
$(".sitemap-row").each(function(){$("body").setEqualHeight($(".dd1",this));})
$(".sitemap-row").each(function(){$("body").setEqualHeight($(".dd2",this));})
$(".sitemap-row").each(function(){$("body").setEqualHeight($(".dd3",this));})
$(".sitemap-row").each(function(){$("body").setEqualHeight($(".dd4",this));})}
$(window).load(function(){if(location.href.indexOf('affinity_card_mastercard.htm')==-1)
{if(navigator.userAgent.indexOf('MSIE 7.0')==-1&&navigator.userAgent.indexOf('MSIE 8.0')==-1)
{setTimeout(myEqualHeight,250);}else
{$(window).trigger('resize');setTimeout(myEqualHeight,250);}}});function heightremove()
{$('.dd00').removeAttr("height").css({height:""});$('.dd11').removeAttr("height").css({height:""});$('.dd22').removeAttr("height").css({height:""});$('.dd33').removeAttr("height").css({height:""});$('.dd44').removeAttr("height").css({height:""});$('.dd55').removeAttr("height").css({height:""});$('.dd66').removeAttr("height").css({height:""});$('.dd77').removeAttr("height").css({height:""});$('.dd000').removeAttr("height").css({height:""});$('.dd111').removeAttr("height").css({height:""});$('.dd222').removeAttr("height").css({height:""});$('.dd333').removeAttr("height").css({height:""});$('.dd444').removeAttr("height").css({height:""});$('.dd555').removeAttr("height").css({height:""});$('.dd666').removeAttr("height").css({height:""});$('.dd777').removeAttr("height").css({height:""});$('.productsList').removeAttr("height").css({height:""});$('.double-inner h3').removeAttr("height").css({height:""});$('.double-inner').removeAttr("height").css({height:""});$('.double-col').removeAttr("height").css({height:""});$('.dd').removeAttr("height").css({height:""});$('.dd1').removeAttr("height").css({height:""});$('.dd2').removeAttr("height").css({height:""});$('.dd3').removeAttr("height").css({height:""});$('.dd4').removeAttr("height").css({height:""});$('.dd5').removeAttr("height").css({height:""});$('.dd6').removeAttr("height").css({height:""});$('.dd7').removeAttr("height").css({height:""});}
$(document).ready(function(){$(".double-row .double-col:last-child").css("padding-right",0);$(".double-row .double-col:last-child").css("margin-right",0);$(".double-row .double-col:last-child").css("border-right",0);$(".common-list .tab-cnt-seven ul:first-child").css("margin-top",0);$(".common-list .tab-cnt-seven h3:first-child").css("margin-top",0);$(".common-list .tab-cnt-seven p:first-child").css("margin-top",0);var highestBox=0;});$(document).ready(function(){$('#tool-section').click(function(){$('#tool-div').toggle();});$('#tool_close').click(function(){$('#tool-div').hide();});})
function popup()
{$('.popup-val').removeClass('show');$(".popup-overlay").addClass('show');$(".popup").animate({display:'block'});$(".popup").addClass('show');$("#overlay").addClass('show');var ua=navigator.userAgent.toLowerCase();if(!ua.search('ipad'))
{disable_scroll();}
var pg_hgt=window.innerHeight;var popuphgt=$('.popup').height();var overlayhgt=$('.popup-overlay').height()+$(document).scrollTop();$('.popup-overlay').css('height',overlayhgt);var popup_top=((pg_hgt-popuphgt)/2)+$(document).scrollTop();$('.popup').css('top',popup_top);if(pg_hgt>popuphgt)
{$('.popup').css('top',popup_top);}
else
{$('.popup').css('top',$('#popupanchor').offset().top);}}
function close_popup()
{$(".close").click(function(){$(".popup-overlay").removeClass("show");$("#overlay").removeClass("show");$(".popup").removeClass('show');enable_scroll();return false;});}
function popitup(url)
{newwindow=window.open(url,'name','height=600,width=500');if(window.focus)
{newwindow.focus();}
return false;}
var keys=[37,38,39,40];function preventDefault(e){e=e||window.event;if(e.preventDefault)
e.preventDefault();e.returnValue=false;}
function keydown(e){for(var i=keys.length;i--;){if(e.keyCode===keys[i]){preventDefault(e);return;}}}
function wheel(e){preventDefault(e);}
function disable_scroll(){if(window.addEventListener){window.addEventListener('DOMMouseScroll',wheel,false);}
window.onmousewheel=document.onmousewheel=wheel;document.onkeydown=keydown;}
function enable_scroll(){if(window.removeEventListener){window.removeEventListener('DOMMouseScroll',wheel,false);}
window.onmousewheel=document.onmousewheel=document.onkeydown=null;}
$(document).ready(function(){var ua=navigator.userAgent.toLowerCase();var isAndroid=ua.indexOf("android")>-1;if(isAndroid){var telno=document.getElementsByClassName("TelNo");for(var i=0;i<telno.length;i++)
{var temp=telno[i].innerHTML;var phoneno='<a href="tel:';phoneno+=temp;phoneno+='">'+temp+'</a>';telno[i].innerHTML=phoneno;}}
if(navigator.userAgent.indexOf('SM-T211')!=-1){if($(window).width()==1024){$('.popup').css('top','30px !important')}
else{$('.popup').css('top','180px !important')}}
$(window).bind('orientationchange',function(e){setTimeout(function(){if($(window).width()==1024){$('.popup').css('top','30px !important')}
else{$('.popup').css('top','180px !important')}},500)})
if(navigator.userAgent.indexOf('SM-T211')!=-1){if($(window).width()==600){$('.pagination1.CitiblueSliderNav').css('display','none !important')}
else{$('.pagination1.CitiblueSliderNav').css('display','block !important')}}
$(window).bind('orientationchange',function(e){setTimeout(function(){if($(window).width()==600){$('.pagination1.CitiblueSliderNav').css('display','none !important')}
else{$('.pagination1.CitiblueSliderNav').css('display','block !important')}},500)})})
if(navigator.userAgent.indexOf('ipad')!=-1){if($(window).width()==768){$('.popup-overlay1').css('height','6700px !important')}
else{$('.popup-overlay1').css('height','6700px !important')}}
$(window).bind('orientationchange',function(e){setTimeout(function(){if($(window).width()==1024){$('.popup-overlay1').css('height','6700px !important')}
else{$('.popup-overlay1').css('height','6700px !important')}},500)})
function popup(url){url="../../social/inh-fb-disclaimer.htm"
newwindow=window.open(url,'name','height=392,width=667,top=150,left=550');if(window.focus){newwindow.focus()}
return false;}
$(document).ready(function(){$('.toggleLink1,.pluminimg').click(function(){var set_id=$(this).attr('id');set_id=set_id.replace(/[^\d.]/g,'');if($('#block'+set_id).css('display')=="none")
{$('.pluminimg').attr('src','/CMENA-371/v1/uae/data/images/add.png')
$('.toggle').slideUp();$('#block'+set_id).slideDown();$('#minusplus'+set_id).attr('src','/CMENA-371/v1/uae/data/images/sub.png');setTimeout(function(){$('html,body').animate({scrollTop:$('#img'+set_id).offset().top},500)},500)}
else
{$('#block'+set_id).slideUp();$('#minusplus'+set_id).attr('src','/CMENA-371/v1/uae/data/images/add.png')}})
$('.level-tab li').click(function(){var index=$(this).index();if(index!=2){$('.level-tab li').removeClass('current');$('.level-tab li').eq(index).addClass('current');$('.common-list-content').hide();$('.common-list-content').eq(index).fadeIn();}});$('.level-4 .tab-ph-heaer').click(function(){$('.level-4').removeClass('activated');$(this).next().siblings('.common-list-content').hide();$(this).siblings('.tab-ph-heaer').children().removeClass('current');});$('.level-4').on('click','.tab-ph-heaer a.current',function(){var that=this;$(this).removeClass('current').parent().next().slideUp('slow');});$('.level-content h3').removeAttr('style');$('.redeem_tab').click(function(){if(!($(this).hasClass('active_tab'))){$(this).addClass('active_tab');$(this).siblings('.redeem_tab').removeClass('active_tab');var relId=$(this).attr('rel');$('#'+relId).siblings('.redeem_tab_content').removeClass('active_tab_content');$('#'+relId).addClass('active_tab_content');}});$('.rtab_in').click(function(){if(!($(this).hasClass('atab'))){$(this).addClass('atab');$(this).siblings('.rtab_in').removeClass('atab');var relId=$(this).attr('rel');$('#'+relId).siblings('.redeem_tab_content').removeClass('active_tab_content');$('#'+relId).addClass('active_tab_content');}});$("body,html").on('click','.redIconImg',function(event){event.stopPropagation();if(!($(this).next('.tooltipTxt').is(':visible'))){$(this).next('.tooltipTxt').show();}else{$(this).next('.tooltipTxt').hide();}});$('body, html').on('click touchstart',function(event){event.stopPropagation();var tar=event.target;if(!$(tar).is($('.tooltipTxt *, .tooltipTxt')))
{$('.tooltipTxt').hide();}});});$(document).ready(function() {
    $('#wrapper').on('click', '.ext-link', function(e) {
          var url = $(this).attr('href');
            newwindow = window.open("/CMENA-371/v1/uae/social/terms_and_conditions-disclaimer2.htm?redirect=" + url, 'name', 'height=392,width=667,top=150,left=550', '_blank');
            if (window.focus) {
                newwindow.focus()
            }
        e.preventDefault();
    });
});
$(window).load(function(){if(mobile.detect()||tablet.detect()){$('.external-link').removeAttr('target');}});$(document).ready(function(){$(".header-blue").prepend("<div class='head-blue'></div>");$('.head-blue').load("/CMENA-371/v1/uae/data/header/en/header.htm");});$(function(){$(".header-gold").prepend("<div class='head-gold'></div>");$('.head-gold').load("/CMENA-371/v1/uae/data/header/en/gold-header.htm");});$(document).ready(function(){$(".footer-blue").load("/CMENA-371/v1/uae/data/footer/en/footer.htm");});$(document).ready(function(){$(".footer-gold").load("/CMENA-371/v1/uae/data/footer/en/footer.htm"); $(".footer-cpc").load("/CMENA-371/v1/uae/data/footer/en/footer.htm");});

$(document).ready(function(){

$(".header-cpc").prepend("<div class='head-cpc'></div>");
$('.head-cpc').load("/CMENA-371/v1/uae/data/header/en/cpc-header.htm");

});



/***creditcard***/
function SetAutoHeightDescription(){CardsWidth=$(".allcards").width(),TotalNumberCards=$(".allcards:visible").length,CardBorderPosition=Math.round($("#travel").width()/CardsWidth),TempCardCount1=CardBorderPosition,TempCardCount2=CardBorderPosition;var e=0,r=0,i=0,t=0;$("#travel h1").each(function(){$(this).css("height","auto"),$(this).parents().find("ul").css("height","auto")});for(var a=0;a<Math.ceil(TotalNumberCards/CardBorderPosition);a++){for(i=0,t=0;e<TempCardCount1;e++)i<$("#travel h1:visible:eq("+e+")").height()&&(i=$("#travel h1:visible:eq("+e+")").height()),t<$("#travel ul:visible:eq("+e+")").height()&&(t=$("#travel ul:visible:eq("+e+")").height());for(;r<TempCardCount2;r++)$("#travel h1:visible:eq("+r+")").css("height",i),$("#travel ul:visible:eq("+r+")").css("height",t);TempCardCount2+=CardBorderPosition,TempCardCount1+=CardBorderPosition}}$(window).load(function(){function e(e){var r="",i=top.window.location;str=new String(i);var t=str.indexOf(e);if(-1!=t){var a=str.substring(t),o=a.indexOf("&");if(-1==o)var t=a.indexOf("="),r=a.slice(t+1);else var t=a.indexOf("="),r=a.slice(t+1,o)}return r}SetAutoHeightDescription(),$(".cc-compare-select li a").click(function(){if(!$(this).parent().hasClass("active")){$(".cc-compare-select li").removeClass("active"),$(this).parent().addClass("active"),$(".level-2 .allcards").hide(),$("."+$(this).attr("id")).show(),$(".hr-line-desk").remove(),CardsWidth=$(".allcards").width(),CardBorderPosition=Math.round($(".level-2").width()/CardsWidth),TotalNumberCards=$(".allcards:visible").length,TotalNumberCards1=$(".allcards").length,TotalNumberBorder=TotalNumberCards/CardBorderPosition,CardBorderPositionTemp=CardBorderPosition,$(".level-2 .allcards").removeClass("last").removeClass("ipad-last").removeClass("ipad-prod-last").removeClass("last_total"),$(".ipad-line-product").hide();for(var e=1;e<=TotalNumberBorder;e++)CardBorderPositionTemp!=TotalNumberCards&&($(".level-2 .allcards:visible:eq("+(CardBorderPositionTemp-1)+")").addClass("last"),$(".level-2 .allcards:visible:eq("+(CardBorderPositionTemp-1)+")").after('<p class="prod-hr-line hr-line-desk hr-line-dev"></p>'),CardBorderPositionTemp+=CardBorderPosition),TotalNumberCards==TotalNumberCards1&&$(".level-2 .allcards:visible:eq("+(TotalNumberCards-1)+")").addClass("last"),4==TotalNumberCards&&$(".level-2 .allcards:visible:eq("+(TotalNumberCards-1)+")").addClass("last_total")}SetAutoHeightDescription()});var r=e("tab");"Travel"==r?$(".comp-sel-1 a").trigger("click"):"Lifestyle"==r?$(".comp-sel-2 a").trigger("click"):"premierCard"==r?$(".comp-sel-3 a").trigger("click"):"Lifestyle1"==r?$(".comp-sel-4 a").trigger("click"):"Lifestyle2"==r?$(".comp-sel-5 a").trigger("click"):"citilifecard"==r?$(".comp-sel-6-last a").trigger("click"):"LowRate"==r&&$(".comp-sel-6 a").trigger("click")}),-1!=navigator.userAgent.indexOf("ipad")&&-1==navigator.userAgent.indexOf("iphone")&&(768==$(window).width(),SetAutoHeightDescription()),$(window).bind("orientationchange",function(){setTimeout(function(){$(window).width()<769&&$(window).width()>599?SetAutoHeightDescription():$(window).width()>768?SetAutoHeightDescription():$(window).width()<=480&&$(".four-clm-cnt,.four-clm-cnt h1,.four-clm-cnt ul").css("height","auto")},300)});
/***creditcard***/

$(document).ready(function(){
	
  	$('.bx-card ul li').each(function(){
		var index = $(this).index();
		 $(this).children().attr('data-index',index);
  	});
	
	$('.bx-card').each(function(){
		var self = $(this);
	
		if(mobile.detect()||tablet.detect()){
			$(this).children('ul').bxSlider({
				minSlides: 4,
				maxSlides: 4,
				slideWidth:120,
				slideMargin: 10,
				pager: false,
				moveSlides: 1,
				hideControlOnEnd: true,
				infiniteLoop: false,
				onSliderLoad: function(currentIndex){
					self.find('ul').children().not('.bx-clone').eq(currentIndex).addClass('active faded-open');
				}
			});
		}else{
			$(this).children('ul').bxSlider({
				minSlides: 5,
				maxSlides: 5,
				slideWidth:120,
				slideMargin: 10,
				pager: false,
				moveSlides: 1,
				hideControlOnEnd: true,
				infiniteLoop: false,
				onSliderLoad: function(currentIndex){
					self.find('ul').children().not('.bx-clone').eq(currentIndex).addClass('active faded-open');
				}
			});
		}
		
		self.find('li').each(function(index){
			var html = self.siblings('.card-view').eq(index).html();
			$(this).after('<div class="card-mob">'+html+'</div>');
		});
		
		self.find('.card-mob').first().show();
		
	});
	
	$(".bx-card" ).on( "click", ".bx-viewport > ul > li", function(){
	  $(this).toggleClass('faded-open').siblings().removeClass('faded-open');
		$(this).addClass('active').siblings().removeClass('active');
		var index = $(this).children().first().data('index');
		$(this).parents('.bx-card').siblings('.card-view').hide().eq(index).fadeIn();
		
		if (mobile.detect()){
			var el = $(this).next();
			if(el.is(':visible')){
				$(this).siblings('.card-mob').hide();
			}else{
				$(this).next().show().siblings('.card-mob').hide();
			}
			var offset = $(this).offset().top
			$("html,body").animate({scrollTop: offset}, 600);
		}
	});
	
	});
	

$(window).load(function(){
	if(mobile.detect()||tablet.detect()){
		$('.swiper-wrapper').addClass('auto-height');
	}
});

/* Get url Variables */
function getUrlVars(){
	var queryString = {};
	window.location.href.replace(/[?&]+([^=&]+)=([^&]*)/gi, function(m,key,value) { 
			queryString[key] = value;
		}
	);
	return queryString;
}

$(function(){
if(typeof getUrlVars()['tab'] != "undefined"){
	if (getUrlVars()['tab'] == "howtoreedem"){
		$('.redeem').trigger("click");
	}

}
if(typeof getUrlVars()['slide'] != "undefined"){
	var target = parseInt(getUrlVars()['slide'])-1;
	$("html, body").animate({scrollTop: $('.emirates.allcards').eq(target).offset().top },1000);	
}
});

/* Rewards and redemption */

$(function(){
$('.redeem_tab_cls').click(function(){
if(!($(this).hasClass('active_cur')))
{
 $(this).addClass('active_cur');
$(this).siblings('.redeem_tab_cls').removeClass('active_cur');
var relId = $(this).attr('rel');
$('.redeem_tab_content-new').find('#'+relId).siblings('.redeem_tab_content').removeClass('active_cur_content');
$('.redeem_tab_content-new').find('#'+relId).addClass('active_cur_content');
}
})

$('.rtab_in_cls').click(function(){
if(!($(this).hasClass('active_cur')))
{
 $(this).addClass('active_cur');
$(this).siblings('.rtab_in_cls').removeClass('active_cur');
var relId = $(this).attr('rel');
$('.redeem_tab_content-new').find('#'+relId).siblings('.redeem_tab_content').removeClass('active_cur_content');
$('.redeem_tab_content-new').find('#'+relId).addClass('active_cur_content');
}
})
$(".redeem_mob_tab").click(function(){
    /* Save current selector */
    var self = $(this);
    /* Remove all active */
    $('.redeem_mob_tab').addClass('expand').removeClass('collapse');
    /* SlideUp all except self content */
    $('.redeem_tab_content').not(self.next()).slideUp();
    /* Check whether current item is visible */
    if(self.next().is(":visible")){
        self.next().slideUp();
		self.addClass('expand');
    }else{
		self.next().slideDown( "slow", function() {
			if(navigator.userAgent.match(/iPhone|iPad|iPod|Android/i)){
				$('html, body').animate({scrollTop: self.offset().top}, 1000);
			}
		});
        self.addClass('collapse').removeClass('expand');
    }
});
  $('ul.tabs li').click(function(){
         var tab_id = $(this).attr('data-tab');
         $('ul.tabs li').removeClass('current');
         $('.tab-content').removeClass('current');
         $(this).addClass('current');
         $("#"+tab_id).addClass('current');
     })
        
	
/*
$(this).next().siblings('.citilife-tab .redeem_tab_content').slideUp(1000);
$(this).next().slideToggle(1000);
$(this).siblings('.citilife-tab .redeem_mob_tab').addClass("expand").removeClass("collapse");
if($(this).hasClass('expand')){$(this).removeClass("expand").addClass("collapse");}
else{
$(this).removeClass("collapse").addClass("expand");
}

*/
});

/**** PERSONAL INSTALLMENT LOAN Pump It Section ****/
$(document).ready(function(){
/********* Thumble animation ***********/
	function thumbLoop(){
	   $('.btn_count i').animate({marginTop:20},1000).animate({marginTop:10},1000, thumbLoop);
	  }	  
	  thumbLoop();

	  $('.thumbleTxt').hide();
	$('.thumbleTxt:first').show();
	
	var timerId;
	var thumbTxtcount = 0;
	var thumbTxt;
	var thumbProgress;

/********* Pumping Man and progressbar ***********/
	var currentX = -178;
	var $window = $('.pumpPerson');
	var windowWidth = 178;
	var progressHeight = 0;
	var clickedCount = 0;
	var clicked = 0;
	var duration = 0;
	$('.btn_progress').on('click', function(){
		clicked  += 1;
		clickedCount += 1;
		
		if(clicked==1){
			countdown();
		}
		if(clicked<40){
			if(clickedCount==3){
				pumpProgressbar();
			}
		}
		else{
			if(clickedCount==6){
				pumpProgressbar();
			}
		}		
	});

	function pumpProgressbar(){
		clickedCount = 0;
		thumbProgress = setTimeout(function(){
			if(progressHeight<110)
			{
				progressHeight = progressHeight + 7.3;
			}
			else{
				progressHeight = progressHeight + 2;
			}
			$('.progressFillOverlay').css('height',progressHeight+'px');
			$window.css({'background-position-x': currentX + 'px'});
			currentX -= windowWidth;
			if (currentX == -5518) {
				progressHeight = 0;
			   $('.pumpIt').hide();
			   $('.pumpMsg').fadeIn();
			   $('.progressFillOverlay').css('height',progressHeight+'px');
			}
		},duration);
	}
	var score;
function countdown() {
	var count = 15;
	var timerId = setInterval(function() {
		count--;
		$('.clockTimer').text(count);
		if(count == 0) {
			count = 15;
				var pumpScore = (progressHeight/220)*100;
				var pumpItScore = Math.round(pumpScore);
				setTimeout(function(){
					$('.pumpClickScore').each(function () {
						$(this).prop('Counter',0).animate({
							Counter:pumpItScore
						}, {
							duration:1000,
							easing: 'swing',
							step: function (now) {
								if(now<=9){
									$(this).text('0'+Math.round(this.Counter));
								}
								else{
									$(this).text(Math.round(this.Counter));
								}
							}
						});
					});
				
				},400);
		
			clearInterval(timerId);
			$('.pumpIt').hide();
			$('.pumpMsg').fadeIn();
			setTimeout(function(){
				$('.clockTimer').text(count);
				progressHeight = 0;
				clickedCount = 0;
				clicked = 0;
				currentX = -178;
				$('.progressFillOverlay').css('height',progressHeight+'px');
				$window.css({'background-position-x': currentX + 'px'});
			},1000);
		}
	}, 1000);

	thumbTxt = setInterval(function() {
		thumbTxtcount++;
		$('.thumbleTxt').hide();
		$('.thumbleTxt'+thumbTxtcount).fadeIn();
		if(thumbTxtcount > 6) {
			thumbTxtcount = 0;
			clearInterval(thumbTxt);
			$('.thumbleTxt').hide();
			$('.thumbleTxt:first').show();
		}
	}, 2300);
}
	$('.btn_reply').on('click', function(e){
			$('.pumpMsg').hide();
			$('.pumpIt').fadeIn();
			$('.pumpClickScore').text('00');
	});
});