var app=angular.module("TopCitiesModel",[]);

////// Double Tab //////
hmGestures = ['hmHold:hold',
                  'hmTap:tap',
                  'hmDoubletap:doubletap',
                  'hmDrag:drag',
                  'hmDragstart:dragstart',
                  'hmDragend:dragend',
                  'hmDragup:dragup',
                  'hmDragdown:dragdown',
                  'hmDragleft:dragleft',
                  'hmDragright:dragright',
                  'hmSwipe:swipe',
                  'hmSwipeup:swipeup',
                  'hmSwipedown:swipedown',
                  'hmSwipeleft:swipeleft',
                  'hmSwiperight:swiperight',
                  'hmTransformstart:transformstart',
                  'hmTransform:transform',
                  'hmTransformend:transformend',
                  'hmRotate:rotate',
                  'hmPinch:pinch',
                  'hmPinchin:pinchin',
                  'hmPinchout:pinchout',
                  'hmTouch:touch',
                  'hmRelease:release'];

angular.forEach(hmGestures, function(name){
  var directive = name.split(':'),
  directiveName = directive[0],
  eventName = directive[1];
  app.directive(directiveName, ["$parse", function($parse) {
    return {
      scope: true,
      link: function(scope, element, attr) {
        var fn, opts;
        fn = $parse(attr[directiveName]);
        opts = $parse(attr["hmOptions"])(scope, {});
        if(opts && opts.group) {
          scope.hammer = scope.hammer || Hammer(element[0], opts);
        } else {
          scope.hammer = Hammer(element[0], opts);
        }
        return scope.hammer.on(eventName, function(event) {
          return scope.$apply(function() {
            return fn(scope, {
              $event: event
            });
          });
        });
      }
    };
    }
  ]);
});

app.controller("TopCitiesCntrl",function($scope,$timeout){
	$scope.BarWidth=200;
	$scope.sort="ASC";
	$scope.ActiveColumn="";
	$scope.TopSEM=0;
	$scope.TopREM=0;
	$scope.TopLTM=0;
	$scope.SortData=function(column){
		
		if($scope.ActiveColumn == column){
			$scope.sort= ($scope.sort == "ASC" ? "DSC":"ASC");
		}else{
			$scope.ActiveColumn = column;
			$scope.Sort="ASC";
		}
		
		var unsorted=[];	
		var temp=[];
		var sorted=[];
		angular.forEach(cityData,function(d,i){
			
			if(d.Rank != null){
				if($scope.TopSEM < parseInt(d["Socio-Economic-Momentum"])){
					$scope.TopSEM=parseInt(d["Socio-Economic-Momentum"]);
				}
				if($scope.TopREM < parseInt(d["Real-Estate-Momentum"])){
					$scope.TopREM=parseInt(d["Real-Estate-Momentum"]);
				}
				if($scope.TopLTM < parseInt(d["Long-Term-Momentum"])){
					$scope.TopLTM=parseInt(d["Long-Term-Momentum"]);
				}

				if(column != "Rank" && column != "City"){
					//console.log(column)
					unsorted.push(parseInt(d[column][0]));
				}else{
					if(column == "City"){
						unsorted.push(d[column]);
					}else{
						unsorted.push(parseInt(d[column]));
					}
				}
			}
		})
		
		temp=unsorted.slice();
		if(column != 'City'){
			$scope.sort == 'ASC' ? temp.sort(function(a,b){return a-b}) : temp.sort(function(a,b){return b-a})
			
		}else{
			temp.sort();
			if($scope.sort != 'ASC'){temp.reverse()};
		}
		
		angular.forEach(temp,function(x,y){
			var oldIndex=unsorted.indexOf(x);
			sorted.push(cityData[oldIndex]);
			unsorted.splice(oldIndex,1);
			cityData.splice(oldIndex,1);
		})
		//console.log(sorted)		
		$scope.CityData=sorted;
		cityData=sorted;
		$scope.FireAnimation();
	}
	$scope.setIcon=function(th){
		if(th == $scope.ActiveColumn)
		{
			return $scope.sort == 'ASC' ? 'glyphiconAsc' : 'glyphiconDesc' ;
		}
		return 'glyphiconArrow';
	}
	$scope.setWidth=function(r,y){
		return r/eval("$scope.Top"+y)*$scope.BarWidth;
	}
	$scope.FireAnimation=function(){
				
		$timeout(function(){
			angular.element('.barChart').each(function(){
				var w=parseInt(angular.element(this).attr("fig"))/parseInt(eval("$scope.Top"+angular.element(this).attr("col")))*$scope.BarWidth;
				//angular.element(this).css({"width":"0px"});
				angular.element(this).animate({"width":w+'px'},600);
			});
       
		 });        
		
	}
	
		$scope.SortData('Rank');
	
})
$(document).ready(function(){
	
	
})
