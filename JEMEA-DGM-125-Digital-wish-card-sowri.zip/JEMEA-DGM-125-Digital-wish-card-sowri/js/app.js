var app = angular.module('myApp', []);
// FOR RANGE REPEAT
app.filter('range', function() {
  return function(input, total) {
    total = parseInt(total);
    for (var i=0; i<total; i++)
      input.push(i);
    return input;
  };
});

// FOR DATA BINDING
app.controller('profileImg',function($scope,$http,$timeout){
    $http.get('js/data.json').success(function(data) {
         $scope.profileInfo = data;
         //console.log( $scope.profileInfo)
    });
    $scope.random = function() {
       return Math.random();
    } 
    $scope.onloadFun = function() {
        $timeout(function(){
        },5000)
    }    
})
// function getPos(e){
//   x=e.clientX;
//   y=e.clientY;
//   cursor= x + " , " + y ;
//   console.log(cursor);
//   if(y < 100){
//     var i = 0;
//     for(i=0; i<20; i++){
//       document.getElementsByClassName("img-over")[i].style.top = "0";
//     }
//   }
// }


