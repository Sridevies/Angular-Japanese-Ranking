$(window).on('load',function(){
    setTimeout(function() {
        $(".loading-bg").fadeOut();
        $(".loading-img").fadeOut();
        $("html").css({"overflow-y":"auto"})
        $(".image-box").click(function(){
            $(".popup-overlay").fadeIn();
            $(".video-box").slideDown('slow');
        })
        $(".popup-overlay").click(function(){
            $(".video-box").slideUp('slow',function(){
                $(".popup-overlay").fadeOut();
            });
        });

        $(".image-box").hover(function(e){
            var VideoId = $(this).attr("rel");
            myPlayer.catalog.getVideo(VideoId, function(error, video) {
                myPlayer.catalog.load(video);
                myPlayer.play();
            });
            //$(this).next(".image-box").css({"z-index":"1"})
            var boxWidth = $(".image-box").width();
            var boxWidth1 = boxWidth*19;
            x=e.clientX;
            y=e.clientY;
            cursor= x + " , " + y ;
            console.log(cursor);
            if(y < boxWidth){
                $(this).find(".img-over").css({"top":"0","bottom":"inherit"})
            }else{
                $(this).find(".img-over").css({"top":"inherit","bottom":"0"})
            }
            if(x > boxWidth1){
                $(this).find(".img-over").css({"right":"0","left":"inherit"})
            }else{
                $(this).find(".img-over").css({"right":"inherit","left":"0"})
            }
        },function(){
            //$(".image-box").css({"z-index":"13"})
        })

        // FOR ODER CHANGE
        $(".img-arrow:eq(2)").click(function(){
             $(".img-arrow:eq(2)").hide();
            addEmptySpace(); 
        })
        $(".img-arrow:eq(1)").click(function(){
             $(".img-arrow:eq(1)").hide();
            addEmptySpace() 
        })
        $(".img-arrow:eq(0)").click(function(){
             $(".img-arrow:eq(1)").show();
             $(".img-arrow:eq(2)").show();
            addEmptySpace()  
        })
        addEmptySpace()
        imagePosition()
    },1000);
    
    $(window).resize(function(){
        imagePosition()
    })

    function imagePosition(){
        var boxWidth = $(".image-box").width();
        $(".img-arrow").css({"top":boxWidth})
        $(".img-Meilleurs").css({"top":(boxWidth*2)})
        $(".img-Voeux_2018").css({"top":boxWidth})
        $(".img-jll-logo").css({"top":boxWidth*4})
        $(".img-managing-director").css({"top":boxWidth*5})
        $(".img-2018-logo").css({"top":boxWidth*9})
        $(".img-Achieve-Ambitions").css({"top":boxWidth*10})
    }
    function addEmptySpace(){            
        $(".image-box").css({"margin-right":"0%"})
        $(".image-box:eq(23),.image-box:eq(39),.image-box:eq(54)").css({"margin-right":"15%"})
        $(".image-box:eq(30)").css({"margin-right":"5%"})
        $(".image-box:eq(45),.image-box:eq(60)").css({"margin-right":"10%"})
        $(".image-box:eq(72)").css({"margin-right":"5%"})
        $(".image-box:eq(94),.image-box:eq(110),.image-box:eq(126),.image-box:eq(142)").css({"margin-right":"20%"})
        $(".image-box:eq(158),.image-box:eq(173)").css({"margin-right":"10%"})
        $(".image-box:eq(170),.image-box:eq(185),.image-box:eq(202)").css({"margin-right":"15%"})
    } 

    var myPlayer;
    videojs("myPlayerID").ready(function() {
        myPlayer = this;
        myPlayer.play();
    });
})