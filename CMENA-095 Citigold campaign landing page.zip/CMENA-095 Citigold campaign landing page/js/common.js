$(document).ready(function(){
	$('.flyout,.mainNavSignOn').css('z-index','999');
	$("body").tab();
	$(".importantLinks a.dropLink").click(function(e){
		e.stopPropagation();
		$(this).next().slideToggle()
	})

	$("body").on("click",".appFooterScrolBot", function () {
		$(this).addClass("appFooterScrolTop").removeClass("appFooterScrolBot");
		$(this).parents(".footerMenu").css({
			"height": "auto"
		})
	})
	$("body").on("click",".appFooterScrolTop", function () {
		$(this).addClass("appFooterScrolBot").removeClass("appFooterScrolTop");
		$(this).parents(".footerMenu").css({
			"height": "16px"
		})
	});
	
	$("body").on("click",".focusForm", function () {
		$("body,html").animate({'scrollTop':$("#sidebar").offset().top},600,function(){
			$("#Yes").focus();
		});
	});
	
	if ($.browser.msie && $.browser.version <= 9.0) {
		setTimeout(function () {
			$.getScript("js/PIE.js", function () {
				if (window.PIE) {
					$('.rounded, .curvedCorners').each(function () {
						PIE.attach(this);
					});
				}
			})
		}, 100);
	}

	


	$("body").on("click",".mainMenuIcon", function (e) {
		e.stopPropagation();
		$(this).toggleClass("active");
		$("#nav").slideToggle(600);
	});

	$(".searchIconmMob").click(function () {
		$(this).toggleClass('active');
		$(".searchMobWrap").toggleClass("active", function () {
		$(".searchBox").text('Search...');
		});
	});

	$("body").on("click", '.sbToggle, .sbSelector', function () {
		$this = $(this);
		if ($(this).siblings('a').hasClass('sbToggleOpen') || $(this).hasClass('sbToggleOpen')) {
			$(this).siblings('ul.sbOptions').addClass("scroll-pane");
		}
		setTimeout(function () {
			$this.siblings('.scroll-pane').jScrollPane({
				contentWidth: '0px'
			})
		}, 300);
	});

	$(document).click(function(e){
		if(!$(e.target).parents().hasClass("dropdown"))
		{
			$(".importantLinks a.dropLink").next().slideUp()
		}
		if(!$(e.target).parents().hasClass("mainNavList") || !$(e.target).hasClass("mainMenuIcon"))
		{
			$("#nav").slideUp(600);
		}
	})

	$(".stepToFrm").click(function(){
		$("#sname").focus();
	})

	$(".tabHeading,.tabHeadingCalc,.disclaimerHeadingTab,.tabHeading-important-documents").click(function () {
		if (!$(this).hasClass("active") && $(this).next().is(":hidden")) {
			$(this).addClass("active").next().slideDown("slow", function () {
				$("html,body").animate({
					scrollTop: $(this).offset().top - 83
				}, 1000)
			});
		} else {
			$(this).removeClass("active").next().slideUp();
		}
    })

	if (!mobile.detect() && !tablet.detect()) {
		$(".flyout a").live("click.fndtn", function () {
			var parent = $(this).parent().find("div.dropFlyout");
			var object = $(this);
			parent.clearQueue();
			parent.stop();
			$(this).stop();
			if ($(".activeMMenu").size() > 0) {
				$(".activeMMenu").stop(false, false).animate({
					"top": "-250px"
				}, 500, function () {
					$(this).removeClass("activeMMenu");
					$(".megaMenuCnt").css({
						"height": "0"
					});
					$(".activeTab").removeClass("activeTab");
					if ($(".activeSubMenu").size() > 0) {
						if (excuted == true) return false;
						parent.stop();
						$(".dropFlyoutList").fadeTo("slow", 0, function () {
							flagDispaly = $(parent).css("display");
							$(".activeSubMenu").stop(false, false).slideUp('slow', function () {
								if (flagDispaly != "block") {
									parent.addClass("activeSubMenu").stop(false, false).slideToggle(function () {
										$(".dropFlyoutList", parent).fadeTo("slow", 1);
										$(this).next("css3-container").show();
									}).parents("li").addClass("active");
								}
							}).removeClass("activeSubMenu").parents("li").removeClass("active");
						})
					} else {
						if (object.parent().find("div.dropFlyout")) {
							$(".dropFlyoutList", parent).fadeTo("slow", 0);
							parent.addClass("activeSubMenu").stop(false, false).slideDown(function () {
								$(".dropFlyoutList", parent).fadeTo("slow", 1);
								$(this).next("css3-container").show();
							}).parents("li").addClass("active");
							excuted = true;
						}
					}
				});
			} else {
				if ($(".activeSubMenu").size() > 0) {
					$(".dropFlyoutList").fadeTo("slow", 0, function () {
						flagDispaly = $(parent).css("display");
						$(".activeSubMenu").stop(false, false).slideUp('slow', function () {
							if (flagDispaly != "block") {
								parent.addClass("activeSubMenu").stop(false, false).slideToggle(function () {
									$(".dropFlyoutList", parent).fadeTo("slow", 1);
									$(this).next("css3-container").show();
								}).parents("li").addClass("active");
							}
						}).removeClass("activeSubMenu").parents("li").removeClass("active");
					})
				} else {
					if ($(this).parent().find("div.dropFlyout")) {
						$(".dropFlyoutList", parent).fadeTo("slow", 0);
						parent.addClass("activeSubMenu").stop(false, false).slideToggle(function () {
							$(".dropFlyoutList", parent).fadeTo("slow", 1);
							$(this).next("css3-container").show();
						}).parents("li").addClass("active");
					}
				}
			}
		})


		$("body").click(function (e) {
			if (!$(e.target).parents().hasClass("stoppropagationQL")) {
				if ($(".activeSubMenu").size() > 0) {
					$(".dropFlyoutList").fadeTo("slow", 0, function () {
						$(".activeSubMenu").stop(false, false).slideUp().removeClass("activeSubMenu").parents("li").removeClass("active");
					})
				}
			}

			if (!$(e.target).hasClass("selectTxt")) {
				$('.selectDiv').slideUp('slow');
			}

			if (!$(e.target).hasClass("applyTxt")) {
				$('.applyDiv').slideUp('slow');
			}
			if($(".cS-generalInfoHolder").css("display") == "block")
			{
				$("#generalInfo").parent('div').css({ "position":"relative"});
				$("#generalInfoMenu").fadeOut(200, function(){
					$(".cS-generalInfoHolder").animate({
									height: '0px'
								  }, 800, function() {
										$(this).slideUp('fast', function(){
											$("#generalInfo").parent('div').animate({
											width: '200px'
										}, 1000, function() {
											$("#generalInfo").parent('div').css("overflow","hidden");
											$("#generalInfo").parent('div').css("background-image","");
										});
								  });
					$("a#generalInfo").removeClass("active");
				
					});
				});
			}
			
		})
	}
	
})

$(window).bind('orientationchange', function () {
    setTimeout(function () {
		$(".nova").siblings('.sbHolder').each(function(){
			$this = $(this);
			$ts = $this.css('width');
			if ($(this).children('ul').is(":visible"))
			{
				$this.children('ul').css('width',$ts);
				$this.find('.scroll-pane').jScrollPane({
					contentWidth: '0px'
				})
			}
		})
	},850);
});



(function ($) {

	$.when(
		$.getScript("js/jquery.mousewheel.js"),
		$.getScript("js/jquery.jscrollpane.min.js"),
		$.Deferred(function (deferred) {
			$(deferred.resolve);
		})).done(function () {
		if (!tablet.detect() && !mobile.detect()) {
			$('.scroll-pane').jScrollPane();
		} else {
			$('.tooltip .scroll-pane').jScrollPane({
				showArrows: true
			});

		}
});


$.fn.tab = function (options) {
		$("body").on('click', "ul.tabs li:not('.active')", function () {
			$this = $(this);
			$tabsContainer = $this.parents('.tabsContainer');
			if (!$(this).hasClass("tabClose")) {
				$tabsContainer.find("ul.tabs li:first").removeClass('activeArrow');
				$tabsContainer.find("ul.tabs li.removeActive").removeClass("removeActive");
				$tabsContainer.find("ul.tabs li.active").removeClass('active');
				$this.addClass('active');
				$('.tabContentWrap').find(".tabContent").hide().removeClass('active_content')
				$('.tabContentWrap').find(".tabContent").eq($(this).index() ).addClass('active_content').fadeIn().css('display', 'block');
			  //  }
			} else {
				if ($this.hasClass("activeArrow")) {
					$this.removeClass("activeArrow");
					$tabsContainer.find("ul.tabs li.removeActive").addClass("active").removeClass("removeActive");
					$tabsContainer.find('div.tabContentWrap').slideDown(500);
				} else {
					$this.addClass("activeArrow");
					$tabsContainer.find("ul.tabs li.active").addClass("removeActive").removeClass("active");
					$tabsContainer.siblings('div.tabContentWrap').slideUp(500);
				}
			}

			if (!tablet.detect() && !mobile.detect()) {
				$('.scroll-pane').jScrollPane();
			}

		});
	};
})(jQuery);
function thswitch()
{
	$lc = (location.href).replace('/en/','/th/');
	top.location.href = $lc;
}

$(function(){
	$('.Mobile-Terms-Conditions .blueBtn').click(function(){
		var $Btn = $('.Mobile-Terms-Conditions .blueBtn');
		if($Btn.hasClass('closeTerms')){
			$Btn.addClass('openTerms').removeClass('closeTerms');
			$('.TermsConditions').show();
			$('body, html').animate({'scrollTop':$(this).offset().top},800);
		}else{
			$Btn.addClass('closeTerms').removeClass('openTerms');
			$('.TermsConditions').hide();
		}
	});

	$('.solutionBtn .blueBtn,#step_apply').click(function(){
		if (mobile.detect()) {
			$("#sidebar").show();
			$("#leftside,.solution_section,.CalcCOn").hide();
		}
	});
	$('.arrow-move').click(function(){
		if (mobile.detect()) {
			$("#sidebar").hide();
			$("#leftside,.solution_section,.CalcCOn").show();
		}
	});

	$('.cardlmtslt ').click(function(){
			$(this).addClass('selected');
			$(this).children().prop("checked", true);
			$(this).siblings().find('input[name=citibank_customer]').prop('checked',false); 
			$(this).siblings().removeClass('selected'); 
	})
});