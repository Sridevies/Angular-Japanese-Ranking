document.write('<div class="footerMenu">'+
'	<div class="footerLeft">'+
'		<a title="Citigroup.com" target="_blank" href="http://www.citigroup.com/?eOfferCode=AEHCGFL"  class="footerLeftLink">Citigroup.com</a>'+
'	</div>'+
'	<div class="footerLinksList">'+
'		<a title="About Citi" href="javascript:;" class="appFooterScrolBot visible-phone"></a>'+
'		<span class="visible-phone footerRhtLink">About Citi</span>'+
'		<ul class="footerList">'+
'			<li><a title="Privacy" target="_blank" href="http://www.citibank.com/uae/consumer/footer/privacy.htm">Privacy</a></li>'+
'			<li><a title="Terms, Conditions, caveats and small print" href="javascript:;">Terms, Conditions, caveats and small print</a></li>'+
'		</ul>'+
'	</div>'+
'</div>'+
'<div class="footerDisclaimer">'+
'	<div class="footerLogo" alt="Citibank" title="Citibank"></div>'+
'	<div class="copyRight">Copyright &copy; 2015 Citigroup Inc.</div>'+
'</div>');
