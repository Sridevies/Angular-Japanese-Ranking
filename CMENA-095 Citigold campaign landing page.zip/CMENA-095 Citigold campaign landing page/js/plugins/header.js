document.write('<div class="banner">'+
'	<div class="container">'+
'		<div class="mainMenu hidden-desktop">'+
'		<a id="logomainenth" class="logo " href="http://www.citi.com/uae/homepage/index.htm" target="_blank"></a>'+
'		<div class="pageTitle pageTitlePad"></div>'+
'		<a class="leftNavIcon" href="javascript:;"></a>'+
'		</div>'+
'		<a href="http://www.citi.com/uae/homepage/index.htm" target="_blank" id="enghome" class="logo visible-desktop" title="Citi"></a>'+
'	</div>'+
'</div>');
