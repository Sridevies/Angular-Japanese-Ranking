var zero=0;
var period='.'
var char_count=0;
var submit=false;var step_1=false;var step_2=false;var step_3=false;var step_4=false;var step_5=false;var step_6=false;
var regex_alpha_space_dot=/[^a-zA-Z. ]/g;
var regex_alpha=/[^a-zA-Z]/g;
var regex_alpha_spl_1=/[^a-zA-Z/,.]/g;
var regex_alpha_spl_all=/[^a-zA-Z./#=@%_:$,\-\+?& ]/g;
var regex_number=/[^0-9]/g;
var regex_alphanumeric=/[^a-zA-Z0-9]/g;
var regex_alpha_numeric_spl_all=/[^a-zA-Z0-9./#=@%_:$,\-\+?& ]/g;
var regex_passport=/[^a-zA-Z0-9]/g;
var regex_alpha_numeric_spl_1=/[^a-zA-Z0-9,./]/g;
var regex_email=/^([\w-]+(?:\.[\w-]+)*)@((?:[\w-]+\.)*\w[\w-]{0,66})\.([a-z]{2,6}(?:\.[a-z]{2})?)$/i
var dd=0;var mm=0;var yy=0;var age=0;
function trimSpace(x){
	var emptySpace = / /g;
	var trimAfter = x.replace(emptySpace,"");
	return(trimAfter);
}
function alpha_space_dot(incomingString, defaultValue)
{
	if(trimSpace(incomingString).length == 0 || incomingString.search(regex_alpha_space_dot) != -1 || incomingString==defaultValue)
		return false;
	else
		return true;
}
function alpha(incomingString, defaultValue)
{
	if(trimSpace(incomingString).length == 0 || incomingString.search(regex_alpha) != -1 || incomingString==defaultValue)
		return false;
	else
		return true;
}
function alpha_spl_1(incomingString, defaultValue)
{
	if(trimSpace(incomingString).length == 0 || incomingString.search(regex_alpha_spl_1) != -1 || incomingString==defaultValue)
		return false;
	else
		return true;
}
function alpha_spl_all(incomingString, defaultValue)
{
	if(trimSpace(incomingString).length == 0 || incomingString.search(regex_alpha_spl_all) != -1 || incomingString==defaultValue)
		return false;
	else
		return true;
}
function number(incomingString, defaultValue)
{
	if((trimSpace(incomingString).length == 0 || incomingString.search(regex_number) != -1) && incomingString != defaultValue) {
		return false;
	} else
		return true;	
}
function alpha_numeric_spl_all(incomingString, defaultValue) 
{
	if(trimSpace(incomingString).length == 0 || incomingString.search(regex_alpha_numeric_spl_all) != -1 || incomingString==defaultValue)
		return false;
	else
		return true;
}
function alphanumeric(incomingString, defaultValue)
{
	if(trimSpace(incomingString).length == 0 || incomingString.search(regex_alphanumeric) != -1 || incomingString==defaultValue)
		return false;
	else
		return true;
}
function passport(incomingString, defaultValue)
{
	if(trimSpace(incomingString).length == 0 || incomingString.search(regex_passport) != -1 || incomingString==defaultValue)
		return false;
	else
		return true;
}
function alpha_numeric_spl_1(incomingString, defaultValue)
{
	if(trimSpace(incomingString).length == 0 || incomingString.search(regex_alpha_numeric_spl_1) != -1 || incomingString==defaultValue)
		return false;
	else
		return true;
}
function email(email)
{
	return regex_email.test(email);
}
function nric(nric) 
{
	//S3221981J
	var checkOK = "ABCDEFGHIJSTZabcdefghijstz0123456789";
	var allValid = true;
	if(nric.length<9) {
		return false;
	}
	for(var i=0; i<nric.length;i++) {
		var ch = nric.charAt(i);
		for(var j=0; j<checkOK.length;j++) {
			if(ch == checkOK.charAt(j))
				break;
			if(j == checkOK.length-1)
				allValid = false;
		}
	}
	if(!allValid)
		return false;        

	var S1=0;
	var checkDigit = new Array("~" , "A" , "B" , "C" , "D" , "E" , "F" , "G" , "H" , "I" , "Z" , "J");
	if(nric.charAt(0)=='T' || nric.charAt(0)=='t')
		S1+=4;
	else if(nric.charAt(0)=='S' || nric.charAt(0)=='s')
		S1+=0;
	else
		return false;

	S1 += (nric.charAt(1)-'0')*2;
	S1 += (nric.charAt(2)-'0')*7;
	S1 += (nric.charAt(3)-'0')*6;
	S1 += (nric.charAt(4)-'0')*5;
	S1 += (nric.charAt(5)-'0')*4;
	S1 += (nric.charAt(6)-'0')*3;
	S1 += (nric.charAt(7)-'0')*2;

	var R1 = S1%11;
	var P = 11-R1;

	if(nric.charAt(8).toUpperCase()!=checkDigit[P])
		return false;
	return true;
}
function spl_check(char_val)
{
	if (trimSpace(char_val).charAt(0) == "-" || trimSpace(char_val).charAt(0) == "&" || trimSpace(char_val).charAt(0) == "=" || trimSpace(char_val).charAt(0) == ":" || trimSpace(char_val).charAt(0) == "?" || trimSpace(char_val).charAt(0) == "_" || trimSpace(char_val).charAt(0) == "#" || trimSpace(char_val).charAt(0) == "." || trimSpace(char_val).charAt(0) == "/" || trimSpace(char_val).charAt(0) == "+" || trimSpace(char_val).charAt(0) == "@" || trimSpace(char_val).charAt(0) == "$" || trimSpace(char_val).charAt(0) == "%" || trimSpace(char_val).charAt(0) == ",")
	{	
		return false;
	}	
	for(i=0;i<char_val.length;i++)
	{
		if(trimSpace(char_val).charAt(i) == "-" || trimSpace(char_val).charAt(i) == "&" || trimSpace(char_val).charAt(i) == "=" || trimSpace(char_val).charAt(i) == ":" || trimSpace(char_val).charAt(i) == "?" || trimSpace(char_val).charAt(i) == "_" || trimSpace(char_val).charAt(i) == "#" || trimSpace(char_val).charAt(i) == "." || trimSpace(char_val).charAt(i) == "/" || trimSpace(char_val).charAt(i) == "+" || trimSpace(char_val).charAt(i) == "@" || trimSpace(char_val).charAt(i) == "$" || trimSpace(char_val).charAt(i) == "%"|| trimSpace(char_val).charAt(i) == ",")
		{
			char_count++;
		}
		else
		{
			char_count=0;
		}
		if(char_count==2)
		{
			return false;
		}
	}
	return true;	
}

var submit_val=false;
$(document).ready(function(){
	/*$('input,select').blur(function(){
		if(trimSpace($(this).val())== $(this).attr( "data_value" ))
		{	
			//$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
			//$('#'+$(this).attr( "data_inner_error")).text($(this).attr( "data_missing"));$(this).focus().select();submit_val=false;return false;
			alert($(this).attr("data_missing"));
		}		
	});	*/
	
	/* Delete special characters */
	var specials=/[/\\|*!@#$%^&*)(?"<>]/;
	$(".alphaField").bind('keypress paste drop', function(e) {
		$ths = $(this);
		setTimeout(function(){if ($ths.val().match(/[^a-zA-Z ]/g)) { $ths.val($ths.val().replace(/[^a-zA-Z ]/g,'')); }},0);
	});
	
	// Condition to enter only  alpha
	  $('.alphaField').keydown(function (e) {
        if (e.ctrlKey || e.altKey) {
            e.preventDefault();
        } else {
            var key = e.keyCode;
            if (!((key == 8) || (key == 9) || (key == 32) || (key == 46) || (key >= 35 && key <= 40) || (key >= 65 && key <= 90))) {
                e.preventDefault();
            }
        }
		/*if(e.shiftKey){
			alert('Please use Capslock for the Capital letters');
		}*/
    });	
	
	$(".numberField").bind('keypress paste drop', function(e) {
		$ths = $(this);
		setTimeout(function(){if ($ths.val().match(/[^0-9]/g)) { $ths.val($ths.val().replace(/[^0-9]/g,'')); }},0);
	});
	// Condition to enter only  numeric values
	$(".numberField").keypress(function (e) {
        //if the letter is not digit then don't type anything
        if (e.which!= 46 && e.which != 8 && e.which != 0 && (e.which < 48 || e.which > 57)) {
            return false;
        }
    });
	$('.DOB').change(function(){	
	if($(this).attr( "data_field_type" )=='drop_down')
		{				
			if($(this).attr( "data_value" )=='DD' )
			{
				
				dd=$(this).val()
			}
			if($(this).attr( "data_value" )=='MM' )
			{
			
				mm=$(this).val();
			}
			if($(this).attr( "data_value" )=='YYYY' )
			{
			
				yy=$(this).val()
			}
		}	
	})		

	/*$('.req').change(function(){
	
		if($(this).attr( "data_field_type" )=='Alpha')
		{	
			if(trimSpace($(this).val())== $(this).attr( "data_value" ))
			{
				$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				$('#'+$(this).attr( "data_inner_error")).text($(this).attr( "data_missing"));$(this).focus().select();submit_val=false;return false;
			}
			if(trimSpace($(this).val()).length<$(this).attr( "data_min_length" ))
			{
				$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
			}
			if($(this).attr( "data_regex" )=='alpha_space_dot')
			{
				if(!alpha_space_dot(trimSpace($(this).val()),''))
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
				}
			}
			if($(this).attr( "data_regex" )=='alpha')
			{
				if(!alpha(trimSpace($(this).val()),''))
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
				}
			}
			if($(this).attr( "data_regex" )=='alpha_spl_1')
			{
				if(!alpha_spl_1(trimSpace($(this).val()),''))
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
				}
			}
			if($(this).attr( "data_regex" )=='alpha_spl_all')
			{
				if(!alpha_spl_all(trimSpace($(this).val()),''))
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
				}
			}
			if(!spl_check(trimSpace($(this).val()),''))
			{
				$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
			}
			$(this).removeClass('mandy_notfilled').addClass('mandy_filled');
			$('#'+$(this).attr( "data_inner_error")).text('')
		}
		
		if($(this).attr( "data_field_type" )=='AlphaNumber')
		{	
			if(trimSpace($(this).val()) == $(this).attr( "data_value" ))
			{
				$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				$('#'+$(this).attr( "data_inner_error")).text($(this).attr( "data_missing"));$(this).focus().select();submit_val=false;return false;
			}
			if(trimSpace($(this).val()).length<$(this).attr( "data_min_length" ))
			{
				$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
			}
			if(trimSpace($(this).val())==zero)
			{
				$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
			}
			if($(this).attr( "data_regex" )=='alphanumeric')
			{
				if(!alphanumeric(trimSpace($(this).val()),''))
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
				}
			}
			if($(this).attr( "data_regex" )=='passport')
			{
				if(!passport($(this).val()))
				{	
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
				}
			}
			if($(this).attr( "data_regex" )=='nric')
			{
				if(!nric($(this).val()))
				{	
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
				}
			}
			if($(this).attr( "data_regex" )=='email')
			{		
				if(!email($(this).val()))
				{	
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
				}
				if(trimSpace($(this).val()).charAt(0) == "-" || trimSpace($(this).val()).charAt(0) == "." || trimSpace($(this).val()).charAt(0) == "_")
				{	
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
				}
			}
			if($(this).attr( "data_regex" )=='alpha_numeric_spl_1')
			{
				if(!alpha_numeric_spl_1(trimSpace($(this).val()),''))
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
				}
			}
			if($(this).attr( "data_regex" )=='alpha_numeric_spl_all')
			{
				if(!alpha_numeric_spl_all(trimSpace($(this).val()),''))
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
				}
			}
			if(!spl_check(trimSpace($(this).val()),''))
			{
				$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
			}
			$(this).removeClass('mandy_notfilled').addClass('mandy_filled');
			$('#'+$(this).attr( "data_inner_error")).text('')
		}
		if($(this).attr( "data_field_type" )=='Number')
		{	
			if(trimSpace($(this).val()) == $(this).attr( "data_value" ) )
			{
				$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				$('#'+$(this).attr( "data_inner_error")).text($(this).attr( "data_missing"));$(this).focus().select();submit_val=false;return false;
			}
			if(trimSpace($(this).val()).length<$(this).attr( "data_min_length" ))
			{
				$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
			}
			if(trimSpace($(this).val())==zero)
			{
				$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
			}
			if(!number(trimSpace($(this).val()),''))
			{
				$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
			}
			if($(this).attr( "data_regex" )=='SG_phone' )
			{
				if (trimSpace($(this).val()) != "")
				{
					if((trimSpace($(this).val()).charAt(0) != 3 && trimSpace($(this).val()).charAt(0) != 6 && trimSpace($(this).val()).charAt(0) != 8 && trimSpace($(this).val()).charAt(0) != 9))
					{
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
					}
				}
			}
			$(this).removeClass('mandy_notfilled').addClass('mandy_filled');
			$('#'+$(this).attr( "data_inner_error")).text('')
		}
		if($(this).attr( "data_field_type" )=='radio')
		{	
			var category =$("[name="+$(this).attr( 'data_value' )+"]"); 
			var check1 = 0;
			for(i=0;i<category.length;i++){
					if(category[i].checked){
					check1++;break;
				}
			}
			if(check1){
			}else{
				$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				$('#'+$(this).attr( "data_inner_error")).text($(this).attr( "data_missing"));$(this).focus().select();submit_val=false;return false;
			}
			$(this).removeClass('mandy_notfilled').addClass('mandy_filled');
			$('#'+$(this).attr( "data_inner_error")).text('')
		}
		//alert($(this).attr( "data_field_type" ));	
		if($(this).attr( "data_field_type" )=='drop_down')
		{	
			if( trimSpace($(this).val()) == '' )
			{
				//$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				$('#'+$(this).attr( "data_inner_error")).text($(this).attr( "data_missing"));$(this).siblings('.sbHolder').focus();
				alert($(this).attr( "data_missing"));
				submit_val=false;return false;
			}
			if($(this).attr( "data_value" )=='DD' )
			{
				//$(this).attr( "data_dd",$(this).val() );
				dd=$(this).val()
			}
			if($(this).attr( "data_value" )=='MM' )
			{
				//$(this).attr( "data_mm",$(this).val() );
				mm=$(this).val();
			}
			if($(this).attr( "data_value" )=='YYYY' )
			{
				//$(this).attr( "data_yyyy",$(this).val() );
				yy=$(this).val()
			}
			
			if($(this).attr( "data_regex" )=='DOB')
			{			 
				if (dd != 0 && mm != 0 && yy != 0)
				{
					var today_date=new Date();
					var birth_year = year = yy;
					var birth_month = month = mm;
					var birth_day = date = dd;
					var today_year = today_date.getFullYear();
					var today_month = today_date.getMonth();
					var today_day = today_date.getDate();
					age = today_year - birth_year;
					
					if ( today_month < (birth_month - 1)) { age--; }
					if (((birth_month - 1) == today_month) && (today_day < birth_day)) { age--; }
					
					if(year % 4 == 0)
					{			
						if(month ==02 && date >29)
						{

							//$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
							alert($(this).attr( "data_invalid" ));$(this).focus().select();
							//alert ("February " + year + " doesn't have " + day + " days!" + $(this).attr("data_invalid") );
							alert($(this).attr("data_invalid"));
							submit_val=false;return false;
						}
					}
					else if(month ==02 && date > 28)
					{
						//$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();
						//alert ("February " + year + " doesn't have " + day + " days!" + $(this).attr("data_invalid") );
						alert($(this).attr("data_invalid"));
						submit_val=false;return false;
					}
					if(month ==04 || month ==06 || month ==09 || month ==11)
					{
						if(date >30)
						{
							$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
							alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
						}
					}
				
				}
			}
			$(this).removeClass('mandy_notfilled').addClass('mandy_filled');
			$('#'+$(this).attr( "data_inner_error")).text('')
		}


		if($(this).attr( "data_field_type" )=='check_box')
		{
			if($(this).is(":not(:checked)"))
			{
				$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				$('#'+$(this).attr( "data_inner_error")).text($(this).attr( "data_missing"));$(this).focus().select();submit_val=false;return false;
			}
			$(this).removeClass('mandy_notfilled').addClass('mandy_filled');
			$('#'+$(this).attr( "data_inner_error")).text('')
		}
		if($(this).attr( "data_field_type" )=='Non_mandy_alpha')
		{	
			if(trimSpace($(this).val())!=$(this).attr( "data_value" ) )
			{
				if($(this).val().length<$(this).attr( "data_min_length" ))
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
				}
				if($(this).attr( "data_regex" )=='alpha_space_dot')
				{
					if(!alpha_space_dot(trimSpace($(this).val()),''))
					{
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
					}
				}
				if($(this).attr( "data_regex" )=='alpha')
				{
					if(!alpha(trimSpace($(this).val()),''))
					{
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
					}
				}
				if($(this).attr( "data_regex" )=='alpha_spl_1')
				{
					if(!alpha_spl_1(trimSpace($(this).val()),''))
					{
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
					}
				}
				if($(this).attr( "data_regex" )=='alpha_spl_all')
				{
					if(!alpha_spl_all(trimSpace($(this).val()),''))
					{
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
					}
				}
				if(!spl_check(trimSpace($(this).val()),''))
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
				}		
			}
			$(this).removeClass('mandy_notfilled').addClass('mandy_filled');
			$('#'+$(this).attr( "data_inner_error")).text('')
		}
		if($(this).attr( "data_field_type" )=='Non_mandy_number')
		{	
			if($(this).val()!=$(this).attr( "data_value" ) )
			{
				if($(this).val().length<$(this).attr( "data_min_length" ))
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
				}
				if(trimSpace($(this).val())==zero)
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
				}
				if(!number(trimSpace($(this).val()),''))
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
				}
				if($(this).attr( "data_regex" )=='SG_phone' )
				{
					if (trimSpace($(this).val()) != "")
					{
						if((trimSpace($(this).val()).charAt(0) != 3 && trimSpace($(this).val()).charAt(0) != 6 && trimSpace($(this).val()).charAt(0) != 8 && trimSpace($(this).val()).charAt(0) != 9))
						{
							$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
							alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
						}
					}
				}
			}
			$(this).removeClass('mandy_notfilled').addClass('mandy_filled');
			$('#'+$(this).attr( "data_inner_error")).text('')
		}
		if($(this).attr( "data_field_type" )=='Non_mandy_alpha_number')
		{	
			if($(this).val()!=$(this).attr( "data_value" ) )
			{
				if($(this).val().length<$(this).attr( "data_min_length" ))
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
				}
				if(trimSpace($(this).val())==zero)
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
				}
				if($(this).attr( "data_regex" )=='alphanumeric')
				{
					if(!alphanumeric(trimSpace($(this).val()),''))
					{
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
					}
				}
				if($(this).attr( "data_regex" )=='passport')
				{
					if(!passport($(this).val()))
					{	
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
					}
				}
				if($(this).attr( "data_regex" )=='nric')
				{
					if(!nric($(this).val()))
					{	
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
					}
				}
				if($(this).attr( "data_regex" )=='email')
				{		
					if(!email($(this).val()))
					{	
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
					}
					if(trimSpace($(this).val()).charAt(0) == "-" || trimSpace($(this).val()).charAt(0) == "." || trimSpace($(this).val()).charAt(0) == "_")
					{	
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;		
					}
				}
				if($(this).attr( "data_regex" )=='alpha_numeric_spl_1')
				{
					if(!alpha_numeric_spl_1(trimSpace($(this).val()),''))
					{
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
					}
				}
				if($(this).attr( "data_regex" )=='alpha_numeric_spl_all')
				{
					if(!alpha_numeric_spl_all(trimSpace($(this).val()),''))
					{
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
					}
				}
				if(!spl_check(trimSpace($(this).val()),''))
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit_val=false;return false;
				}
			}
			$(this).removeClass('mandy_notfilled').addClass('mandy_filled');
			$('#'+$(this).attr( "data_inner_error")).text('')
		}
		submit_val=true;		
	})*/
	
})


function submit_form(val,submit_val)
{			 
	$("."+val).each(function() {
		if($(this).attr( "data_field_type" )=='Alpha')
		{				// alert($(this).attr( "data_value" ));
			if(trimSpace($(this).val()) == $(this).attr( "data_value" ))
			{
				//$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				 $('#'+$(this).attr( "data_inner_error")).text($(this).attr( "data_missing"));$(this).focus().select();
				alert($(this).attr("data_missing"));
				submit=false;return false;
			}
			if(trimSpace($(this).val()).length<$(this).attr( "data_min_length" ))
			{
				//$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
				alert($(this).attr("data_invalid"));
				submit=false;return false;
			}
			if($(this).attr( "data_regex" )=='alpha_space_dot')
			{
				if(!alpha_space_dot(trimSpace($(this).val()),''))
				{
					//$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
					alert($(this).attr("data_invalid"));
					submit=false;return false;
				}
			}
			if($(this).attr( "data_regex" )=='alpha')
			{
				if(!alpha(trimSpace($(this).val()),''))
				{
					//$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
					alert($(this).attr("data_invalid"));
					submit=false;return false;
				}
			}
			if($(this).attr( "data_regex" )=='alpha_spl_1')
			{
				if(!alpha_spl_1(trimSpace($(this).val()),''))
				{
					//$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
					alert($(this).attr("data_invalid"));
					submit=false;return false;
				}
			}
			if($(this).attr( "data_regex" )=='alpha_spl_all')
			{
				if(!alpha_spl_all(trimSpace($(this).val()),''))
				{
					//$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
					alert($(this).attr("data_invalid"));
					submit=false;return false;
				}
			}
			if($(this).attr( "data_regex" )=='alpha_lang')
			{
				if(!alpha_lang(trimSpace($(this).val()),''))
				{
					//$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
					alert($(this).attr("data_invalid"));
					submit=false;return false;
				}
			}
			if(!spl_check(trimSpace($(this).val()),''))
			{
				//$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				alert($(this).attr( "data_invalid" ));$(this).focus().select();
				alert($(this).attr("data_invalid"));
				submit=false;return false;
			}
			$(this).removeClass('mandy_notfilled').addClass('mandy_filled');
			$('#'+$(this).attr( "data_inner_error")).text('')
		}
		if($(this).attr( "data_field_type" )=='AlphaNumber')
		{	
			if(trimSpace($(this).val()) == $(this).attr( "data_value" ))
			{
				//$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				$('#'+$(this).attr( "data_inner_error")).text($(this).attr( "data_missing"));$(this).focus().select();
				alert($(this).attr("data_missing"));
				submit=false;return false;
			}
			if(trimSpace($(this).val()).length<$(this).attr( "data_min_length" ))
			{
				$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
			}
			if(trimSpace($(this).val())==zero)
			{
				$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
			}
			if($(this).attr( "data_regex" )=='alphanumeric')
			{
				if(!alphanumeric(trimSpace($(this).val()),''))
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
				}
			}
			if($(this).attr( "data_regex" )=='passport')
			{
				if(!passport($(this).val()))
				{	
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
				}
			}
			if($(this).attr( "data_regex" )=='nric')
			{
				if(!nric($(this).val()))
				{	
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
				}
			}
			if($(this).attr( "data_regex" )=='email')
			{	
				if(!email($(this).val()))
				{	
					//$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					//alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
					alert($(this).attr("data_invalid"));
					submit=false;return false;
				}
				if(trimSpace($(this).val()).charAt(0) == "-" || trimSpace($(this).val()).charAt(0) == "." || trimSpace($(this).val()).charAt(0) == "_")
				{
					//$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();
					alert($(this).attr("data_invalid"));
					submit=false;return false;		
				}
			}
			if($(this).attr( "data_regex" )=='alpha_numeric_spl_1')
			{
				if(!alpha_numeric_spl_1(trimSpace($(this).val()),''))
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
				}
			}
			if($(this).attr( "data_regex" )=='alpha_numeric_spl_all')
			{
				if(!alpha_numeric_spl_all(trimSpace($(this).val()),''))
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
				}
			}
			if(!spl_check(trimSpace($(this).val()),''))
			{
				$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
			}
			$(this).removeClass('mandy_notfilled').addClass('mandy_filled');
			$('#'+$(this).attr( "data_inner_error")).text('')
		}
		if($(this).attr( "data_field_type" )=='Number')
		{	
			if(trimSpace($(this).val()) == $(this).attr( "data_value" ) )
			{
				//$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				$('#'+$(this).attr( "data_inner_error")).text($(this).attr( "data_missing"));$(this).focus().select();
				alert($(this).attr("data_missing"));
				submit=false;return false;
			}
			if(trimSpace($(this).val()).length<$(this).attr( "data_min_length" ))
			{
				//$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				alert($(this).attr( "data_invalid" ));$(this).focus().select();
				//alert($(this).attr("data_invalid"));
				submit=false;return false;
			}
			if(trimSpace($(this).val())==zero)
			{
				//$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				alert($(this).attr( "data_invalid" ));$(this).focus().select();
				//alert($(this).attr("data_invalid"));
				submit=false;return false;
			}
			if(!number(trimSpace($(this).val()),''))
			{
				//$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				alert($(this).attr( "data_invalid" ));$(this).focus().select();
				//alert($(this).attr("data_invalid"));
				submit=false;return false;
			}
			if($(this).attr( "data_regex" )=='SG_phone' )
			{
				if (trimSpace($(this).val()) != "")
				{
					if((trimSpace($(this).val()).charAt(0) != 3 && trimSpace($(this).val()).charAt(0) != 6 && trimSpace($(this).val()).charAt(0) != 8 && trimSpace($(this).val()).charAt(0) != 9))
					{
						//$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();
						alert($(this).attr("data_invalid"));
						submit=false;return false;
					}
				}
			}
			//$(this).removeClass('mandy_notfilled').addClass('mandy_filled');
			$('#'+$(this).attr( "data_inner_error")).text('')
			//alert($(this).attr("data_invalid"));
		}
		if($(this).attr( "data_field_type" )=='radio')
		{	
			var category =$("[name="+$(this).attr( 'data_value' )+"]");
			//console.log(category);
			var check1 = 0;
			for(i=0;i<category.length;i++){
					if(category[i].checked){
					check1++;break;
				}
			}
			if(check1){
			  }else{
				//$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				$('#'+$(this).attr( "data_inner_error")).text($(this).attr( "data_missing"));$(this).focus().select();
				alert($(this).attr( "data_missing"));
				submit=false;return false;
			  }
			  $(this).removeClass('mandy_notfilled').addClass('mandy_filled');
			$('#'+$(this).attr( "data_inner_error")).text('')
		}	
		
		if($(this).attr( "data_field_type" )=='drop_down')
		{	
			if( $(this).val() == '' )
			{
				alert($(this).attr( "data_missing"));$(this).siblings('.sbHolder').focus();submit=false;return false;
			}
			if($(this).attr( "data_value" )=='DD' )
			{
				//$(this).attr( "data_dd",$(this).val() );
				dd=$(this).val()
			}
			if($(this).attr( "data_value" )=='MM' )
			{
				//$(this).attr( "data_mm",$(this).val() );
				mm=$(this).val();
			}
			if($(this).attr( "data_value" )=='YYYY' )
			{
				//$(this).attr( "data_yyyy",$(this).val() );
				yy=$(this).val()
			}

			if($(this).attr( "data_regex" )=='DOB')
			{
				if (dd != 0 && mm != 0 && yy != 0)
				{
					var today_date=new Date();
					var birth_year = year = yy;
					var birth_month = month = mm;
					var birth_day = date = dd;
					var today_year = today_date.getFullYear();
					var today_month = today_date.getMonth();
					var today_day = today_date.getDate();
					age = today_year - birth_year;

					if ( today_month < (birth_month - 1)) { age--; }
					if (((birth_month - 1) == today_month) && (today_day < birth_day)) { age--; }
					//console.log(date+'-'+month)
					if(year % 4 == 0)
					{
						if(month ==02 && date >29)
						{
							alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
						}
					}
					else if(month ==02 && date > 28)
					{
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
					}
					if(month ==04 || month ==06 || month ==09 || month ==11)
					{
						if(date >30)
						{
							alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
						}
					}
				/*	if(age>=65 || age<23)
					{
						
						
					}*/
				}
			}

		}
		if($(this).attr( "data_field_type" )=='check_box')
		{	
			if($(this).is(":not(:checked)"))
			{
				$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
				$('#'+$(this).attr( "data_inner_error")).text($(this).attr( "data_missing"));$(this).focus().select();
				submit=false;return false;
			 }
			 $(this).removeClass('mandy_notfilled').addClass('mandy_filled');
			$('#'+$(this).attr( "data_inner_error")).text('')
		}
		if($(this).attr( "data_field_type" )=='Non_mandy_alpha')
		{	
			if(trimSpace($(this).val())!=$(this).attr( "data_value" ) )
			{
				if(trimSpace($(this).val()).length<$(this).attr( "data_min_length" ))
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
				}
				if($(this).attr( "data_regex" )=='alpha_space_dot')
				{
					if(!alpha_space_dot(trimSpace($(this).val()),''))
					{
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
					}
				}
				if($(this).attr( "data_regex" )=='alpha')
				{
					if(!alpha(trimSpace($(this).val()),''))
					{
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
					}
				}
				if($(this).attr( "data_regex" )=='alpha_spl_1')
				{
					if(!alpha_spl_1(trimSpace($(this).val()),''))
					{
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
					}
				}
				if($(this).attr( "data_regex" )=='alpha_spl_all')
				{
					if(!alpha_spl_all(trimSpace($(this).val()),''))
					{
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
					}
				}
				if(!spl_check(trimSpace($(this).val()),''))
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
				}		
			}
			$(this).removeClass('mandy_notfilled').addClass('mandy_filled');
			$('#'+$(this).attr( "data_inner_error")).text('')
		}
		if($(this).attr( "data_field_type" )=='Non_mandy_number')
		{	
			if(trimSpace($(this).val())!=$(this).attr( "data_value" ) )
			{
				if(trimSpace($(this).val()).length<$(this).attr( "data_min_length" ))
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
				}
				if(trimSpace($(this).val())==zero)
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
				}
				if(!number(trimSpace($(this).val()),''))
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
				}
				if($(this).attr( "data_regex" )=='SG_phone' )
				{
					if (trimSpace($(this).val()) != "")
					{
						if((trimSpace($(this).val()).charAt(0) != 3 && trimSpace($(this).val()).charAt(0) != 6 && trimSpace($(this).val()).charAt(0) != 8 && trimSpace($(this).val()).charAt(0) != 9))
						{
							$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
							alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
						}
					}
				}
			}
			$(this).removeClass('mandy_notfilled').addClass('mandy_filled');
			$('#'+$(this).attr( "data_inner_error")).text('')
			
		}
		if($(this).attr( "data_field_type" )=='Non_mandy_alpha_number')
		{	
			if(trimSpace($(this).val())!=$(this).attr( "data_value" ) )
			{
				if(trimSpace($(this).val()).length<$(this).attr( "data_min_length" ))
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
				}
				if(trimSpace($(this).val())==zero)
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
				}
				if($(this).attr( "data_regex" )=='alphanumeric')
				{
					if(!alphanumeric(trimSpace($(this).val()),''))
					{
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
					}
				}
				if($(this).attr( "data_regex" )=='passport')
				{
					if(!passport($(this).val()))
					{	
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
					}
				}
				if($(this).attr( "data_regex" )=='nric')
				{
					if(!nric($(this).val()))
					{	
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
					}
				}
				if($(this).attr( "data_regex" )=='email')
				{		
					if(!email($(this).val()))
					{	
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
					}
					if(trimSpace($(this).val()).charAt(0) == "-" || trimSpace($(this).val()).charAt(0) == "." || trimSpace($(this).val()).charAt(0) == "_")
					{	
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;		
					}
				}
				if($(this).attr( "data_regex" )=='alpha_numeric_spl_1')
				{
					if(!alpha_numeric_spl_1(trimSpace($(this).val()),''))
					{
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
					}
				}
				if($(this).attr( "data_regex" )=='alpha_numeric_spl_all')
				{
					if(!alpha_numeric_spl_all(trimSpace($(this).val()),''))
					{
						$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
						alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
					}
				}
				if(!spl_check(trimSpace($(this).val()),''))
				{
					$(this).removeClass('mandy_filled').addClass('mandy_notfilled');
					alert($(this).attr( "data_invalid" ));$(this).focus().select();submit=false;return false;
				}
			}
			$(this).removeClass('mandy_notfilled').addClass('mandy_filled');
			$('#'+$(this).attr( "data_inner_error")).text('')
		}
		submit=true;
	});
	//alert("submit : "+submit);
	if(submit==false)
	{
		return false;				
	}
	else
	{return true;}
	/*else
	{
		if(submit_val=='step_1')
		{
			//step_1=true;
			checknewcus1();
		}
		else if(submit_val=='step_2')
		{
			step_2=true;submit_fn_2()
		}
		else if(submit_val=='step_3')
		{
			step_3=true;
		}
		else if(submit_val=='step_4')
		{
			step_4=true;
		}
		else if(submit_val=='step_5')
		{
			step_5=true;
		}
		if(submit_val=='single_step')
		{
			single_step=true;//submit_single()
		}		
	} */		

}