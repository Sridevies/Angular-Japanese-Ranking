/* facebook app init */
window.fbAsyncInit = function() {
	FB.init({
	  appId      : '1027727960626738', // live 
    //	appId      : '1594965314094472',	 // local
	//	appId      : '413446008780566', // Wip10
	  status     : true,
	  xfbml      : true
	});

	/* the below code is working because of ga.js */
	//_ga.trackFacebook();
  };
  
  (function(d, s, id){
	 var js, fjs = d.getElementsByTagName(s)[0];
	 if (d.getElementById(id)) {return;}
	 js = d.createElement(s); js.id = id;
	 js.src = "//connect.facebook.net/en_US/all.js";
	 fjs.parentNode.insertBefore(js, fjs);
   }(document, 'script', 'facebook-jssdk'));
   /* end facebook app init */

/* FACEBOOK.UI CODE & TRACKER */
$(".fbClick").on("click", function(e){
	e.preventDefault();
	var title			=	'Polish Biggest Cities Quiz';
	var description		=	'Can you identify 7 cities using up to 3 clues for each? #JLLCitiesQuiz';
	var image			=	'http://www.officefinder.pl/citiesquiz/images/icon2.jpg';
	var score			=	"I scored "+ $(".score_box").text() + " out of 21"; 
	
//	if( $.trim(url) != "" && url )
//	{
		FB.ui(
		  {
			method: 'feed',
			name: title,
			picture: image,
			caption: score,
			description: description
		  }
		);
	//}
});/* END FB.UI SCRIPT */
/* FACEBOOK.UI CODE & TRACKER */
$(".fbClick_top").on("click", function(e){
	e.preventDefault();

	var title			=	'Polish Biggest Cities Quiz';
	var description		=	'Can you identify 7 cities using up to 3 clues for each? #JLLCitiesQuiz';
	var image			=	'http://www.officefinder.pl/citiesquiz/images/icon2.jpg';
	var link			=	window.location.assign("http://www.officefinder.pl/citiesquiz/index.htm")
	
//	if( $.trim(url) != "" && url )
//	{
		FB.ui(
		  {
			method: 'feed',
			name: title,
			picture: image,
			caption: link,
			description: description
		  }
		);
	//}
});/* END FB.UI SCRIPT */

/* FACEBOOK TRACKER   
_ga.trackFacebook = function (e) {
	try {
		if (FB && FB.Event && FB.Event.subscribe) {
			FB.Event.subscribe("edge.create", function (t) {
				ga('send', 'social', 'Facebook', 'like',top.location.href);
			});
			FB.Event.subscribe("edge.remove", function (t) {
				ga('send', 'social', 'Facebook', 'unlike',top.location.href);
			});
			FB.Event.subscribe("message.send", function (t) {
				ga('send', 'social', 'Facebook', 'send',top.location.href);
			})
		}
	} catch (t) {}
};*/