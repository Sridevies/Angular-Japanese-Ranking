$(document).ready(function(){	

	$(".moblie-overlay").hide();
	if(/Android|webOS|iPhone|BlackBerry|IEMobile|Opera Mini/i.test(navigator.userAgent)) {
		$(".hole-wrapper").hide();
		$(".moblie-overlay").show();
	}

});



$( window ).load(function() {
	$('#status').fadeOut(); // will first fade out the loading animation
	$('#preloader').delay(450).fadeOut('slow'); // will fade out the white DIV that covers the website.
	$('body').delay(450).css({'overflow':'visible'});

	
	var questionNo  = 1;
	setQuestionClueImages(questionNo);

	function setQuestionClueImages(quesNo){
		$(".clueImgs li img").each(function(i,val){
			$(this).attr("src",eval("quiz.question"+quesNo+".clueImages")[i]);
		});
	}

	var winWidth = $( window ).width();
	var winHeight = $( window ).height();

	var topwpWidth = $(".top-wrapper").width();
	var topwpHeight = $(".top-wrapper").height();
	
	var homewpwidth = winWidth/2 - topwpWidth/2;
	var homewpheight = winHeight/2 - topwpHeight/2;

	var clueBoxHeight = $(".clue-box").height()/2

	$(".container-1").css({"width":winWidth, "height":winHeight});
	$(".top-wrapper").css({"top":homewpheight}); // home content center  
			
	$(".intro-btn a").click(function(){
		$(".middle-cir").fadeOut();
		var btnRel = $(this).attr("rel");
		$(btnRel).fadeIn();
	});
	$(".str-bt a").click(function(){
		$(".new-intro").animate({"top":"-100%"},1000,function(){
			$(".new-intro").hide();
		})
	});

	$(".needcluebtn").click(function(){			 
		var clueNum = $("#clueCount").val();
		if(clueNum >= 3){return false;}
		$(".q1-question li").fadeOut();
		$(".q1-question li").eq(clueNum).fadeIn()
		$(".bullet-point li").eq(clueNum).addClass("active");
		$(".q1-clue li").fadeOut();
		$(".q1-clue li").eq(clueNum).fadeIn();
		clueNum = parseInt(clueNum)+1;
		$("#clueCount").val(clueNum);

		if (clueNum == 3)
		{
			$(" .q1-clue1").hide();
			$(" .q1-clue2").show();
		}else {
			$(" .q1-clue2").hide();
			$(" .q1-clue1").show();
		}
		 
	});

	
	var totalbox =  [];
	$(".submit-btn").click(function(){
		var clueNum = $("#clueCount").val();
		var SubmitNum = $("#sumbitCount").val(); 
		if(SubmitNum >= 7){return false;}

		$(".quiz-body .top-button li .cr-btn").removeClass("red-border");
		$(".top-button li .cr-btn").eq(SubmitNum).text((4 - clueNum )).addClass("bg");
		var pointval = $(".top-button li .cr-btn").eq(SubmitNum).text();
		
		$(".top-button li .city-name").eq(SubmitNum).show();
		var rectcitiname =  $(".top-button li .city-name").eq(SubmitNum).text();
		
		var CurCitiName = $(".top-button li .city-name").eq(SubmitNum).text();
		var submiteVal = $("#submite-val").val();

		if(CurCitiName.toLowerCase() == submiteVal.toLowerCase()){
			$(".quiz-body .clue-box .question1 .submit-box").css({"visibility":"hidden"});
			$(".quiz-body .clue-box .question1 .qust-tittle").css({"visibility":"hidden"});
			$(".quiz-body .clue-box .question1 .cir-main").animate({"margin-left":"0","margin-right":"0"},1000,function(){
				$(".quiz-body .clue-box .question1 .ans-result").fadeIn(500);				
				$(".ans-result h2").show();
			})
			$(".source-cont").fadeIn(500);
		}else {				
			$(".top-button li .cr-btn").eq(SubmitNum).text(0);
			$(".quiz-body .clue-box .question1 .submit-box").css({"visibility":"hidden"});
			$(".quiz-body .clue-box .question1 .qust-tittle").css({"visibility":"hidden"});
			$(".quiz-body .clue-box .question1 .cir-main").animate({"margin-left":"0","margin-right":"0"},1000,function(){
				$(".ans-result h2").hide();
				$(".quiz-body .clue-box .question1 .ans-result").fadeIn(500);				
			});
			$(".source-cont").fadeIn(500);
		}

		$(".ans-result h1 span").empty().text(rectcitiname);
		$(".ans-result h2 span").empty().text(pointval);
		
		if(pointval > 1){
			$(".quiz-body .clue-box .question1 .ans-result h2 strong").text("s");
		}else{
			$(".quiz-body .clue-box .question1 .ans-result h2 strong").text("");
		}

		var totalScore = 0;
		$(".top-button li .bg").each(function(){
			var curScore = parseInt($(this).text());
			totalScore += curScore;
		});
		$(".quiz-body .menu-box .total-val").empty().text(totalScore);


		SubmitNum = parseInt(SubmitNum)+1;
		$("#sumbitCount").val(SubmitNum);

	
		var quzscore = $(".ans-result h1 span").text();
		if (quzscore == 'Tri-City (Gdańsk, Gdynia, Sopot)'){
			$(".ans-result p span").html("Tri-City (Gdańsk, Gdynia, Sopot) hosts one of the biggest open air music festivals in Poland which gathered approx. 90,000 people in 2015.");
		}else if (quzscore == 'Wrocław'){
			$(".ans-result p span").html("The largest single office investment deal in 2015 was the sale of Dominikański in Wrocław (€ 117 mio). <p style='margin-top:10px;'>Wrocław is the European Capital of Culture in 2016.</p>");
		}else if (quzscore == 'Katowice'){
			$(".ans-result p span").html("46% of the city is forested and covered with green areas. ");
		}else if (quzscore == 'Łódź'){
			$(".ans-result p span").html("The largest lease agreement signed in 2015 was mBank in Łódź (24,000 sqm). <p style='margin-top:10px;'>It takes just over one hour to get to Łódź from Warsaw which is roughly what it takes to get from one end of Warsaw to another in rush hours.</p>");
		}else if (quzscore == 'Warsaw'){
			$(".ans-result p span").html("Nearly 90% of flights at the Fryderyk Chopin airport are on time. Warsaw's airport is one of the global frontrunners in this respect.");
		}else if (quzscore == 'Poznań'){
			$(".ans-result p span").html("Poznań Business Garden (40,600 sqm) was the largest single office completion in 2015. <p style='margin-top:10px;'> Poznań has the lowest unemployment rate amongst the Polish cities.</p> ");
		}else if (quzscore == 'Kraków'){
			$(".ans-result p span").html("The all-stock vacancy rate in Kraków was 5.5% in Q4 2015, the lowest ratio countrywide.<p style='margin-top:10px;'>  Kraków  has one of the biggest airports in Poland, second only to Warsaw, and the train trip between the airport and downtown Kraków  takes only  17 minutes.</p>");
		}
		
	});

	$(".next-btn").click(function(){
		$(".quiz-body .clue-box .question1 .submit-box").css({"visibility":"visible"});
		$(".quiz-body .clue-box .question1 .qust-tittle").css({"visibility":"visible"});
		$(".quiz-body .clue-box .question1 .ans-result").hide();
		$(".source-cont").hide();
		
		$(".quiz-body .clue-box .question1 .cir-main").css({"margin-left":"171px"},function(){
			$(".ans-result h2").show();
		});
		$(".quiz-body .clue-box .question1 .ans-result h2 span").empty();
		$("#clueCount").val(1);
		$(".quiz-body .clue-box .question1 .q1-question li").hide();
		$(".quiz-body .clue-box .question1 .q1-question li:eq(0)").show();
		$(".quiz-body .clue-box .question1 .bullet-point li").removeClass("active");
		$(".quiz-body .clue-box .question1 .bullet-point li:eq(0)").addClass("active");
		$(".quiz-body .clue-box .question1 .q1-clue li").hide();
		$(".quiz-body .clue-box .question1 .q1-clue li:eq(0)").fadeIn(1000);
		$(".q1-clue2").hide();
		$(".q1-clue1").show();
		$(".input-box").val("");
		
		var SubmitNum = $("#sumbitCount").val();
		questionNo  = parseInt(SubmitNum)+1;
		setQuestionClueImages(questionNo);
		$(".quiz-body .top-button li .cr-btn").removeClass("red-border");
		$(".quiz-body .top-button li .cr-btn").eq(SubmitNum).addClass("red-border");

		if (SubmitNum == ((quiz.totalQuiz*1)-1)) {
			$(".next-btn").hide();
			$(".final-score-btn").show();			
		}
		

	});
	$(".final-score-btn").on("click",function(){
		$(".quiz-body").fadeOut();
		$(".final-chart").fadeIn();
		$(".source-cont").fadeOut();
		TotalResultChart();

		$('#tweetBtn iframe').remove();

		var tweetBtn = $('<a></a>')
			.addClass('twitter-share-button')
			.attr('href', 'http://twitter.com/share')
			.attr('data-url', 'http://www.officefinder.pl/citiesquiz')
			.attr('data-via', 'jllcities')
			.attr('data-text', "I scored " + $(".text-box h2 span").text()+ " out of 21 \nCan you identify 7 cities using up to 3 clues for each? #JLLCitiesQuiz");
		$('#tweetBtn').append(tweetBtn);
		twttr.widgets.load();

	});

	$(".quiz-header .head h1 , .restart-btn").click(function(){
		 location.reload();
		 $("#clueCount").val(1);
		 $("#sumbitCount").val(0); 
		$(".input-box").val("");
	});
	$(".input-box").click(function(){
		$(".input-box").val("");
	});
	//*******************WINDOW RESIZE**************
	$(window).resize(function() {

		var winWidth = $( window ).width();
		var winHeight = $( window ).height();

		var topwpWidth = $(".top-wrapper").width();
		var topwpHeight = $(".top-wrapper").height();
		
		var homewpwidth = winWidth/2 - topwpWidth/2;
		var homewpheight = winHeight/2 - topwpHeight/2;

		var clueBoxHeight = $(".clue-box").height()/2

		$(".container-1").css({"width":winWidth, "height":winHeight});
		$(".top-wrapper").css({"top":homewpheight, "left":homewpwidth}); // home content center  
				
		$(".str-bt a").click(function(){
			$(".container-1").animate({"margin-top":-winHeight},1500);
			$(".footer-text").delay("1000").css({"color":"#000"});
		});

		$(".quiz-wrapper").css({"height": winHeight});
		
		var cleboxHe = $(".clue-box").height()/2; 	
		var winHeightDivTwo = $( window ).height()/2;
	});	
	

	$(".quiz-wrapper").css({"height": winHeight});
	
	var cleboxHe = $(".clue-box").height()/2; 	
	var winHeightDivTwo = $( window ).height()/2;

});


//--------------Chart------------------	
function TotalResultChart(){ 
	var totalVal = parseInt($(".total-val").text());
	var doughnutData = [
		{value:totalVal,color:"#a3c5cc"},
		{value:21-totalVal,color:"#eee"}
	];

	$( "#myDoughnut" ).doughnutit({
		dnData: doughnutData,
		dnSize: 470,
		dnInnerCutout: 80,
		dnAnimation: true,
		dnAnimationSteps: 100,
		dnAnimationEasing: 'linear',
		dnStroke: false,
		dnShowText: true,
		dnFontSize: '70px',
		dnFontColor: "#819596",
		dnText: totalVal,
		dnStartAngle: 270,
		dnCounterClockwise: false
	});// End Doughnut
		
	$(".text-box h2 span").empty().text(totalVal);
	
	$(".replay-bt").click(function(){
		 location.reload();
		 $("#clueCount").val(1);
		 $("#sumbitCount").val(0); 
		$(".input-box").val("");
	});
	if (totalVal >= 0  && totalVal <= 5){
		$(".text-box .content-list li, .social-icon").hide();
		$(".text-box .content-list li:eq(0)").show();
	}else if (totalVal >= 6  && totalVal <= 10){
		$(".text-box .content-list li, .social-icon").hide();
		$(".text-box .content-list li:eq(1)").show();

	}else if (totalVal >= 11  && totalVal <= 15){
		$(".text-box .content-list li, .social-icon").hide();
		$(".text-box .content-list li:eq(2)").show();
		$(".text-box p").css({"font-size":"15px","line-height":"21px"});
		$(".replay-bt").css({"margin-top":"5px"});

	}else if (totalVal >= 16  && totalVal <= 20){
		$(".text-box .content-list li, .social-icon").hide();
		$(".text-box .content-list li:eq(3)").show();
		$(".text-box p").css({"font-size":"15px","line-height":"21px"});
		$(".replay-bt").css({"margin-top":"5px"});

	}else if (totalVal >= 21  && totalVal <= 25){
		$(".text-box .content-list li, .social-icon").hide();
		$(".text-box .content-list li:eq(4)").show();
		$(".text-box p").css({"font-size":"15px","line-height":"21px"});
		$(".replay-bt").css({"margin-top":"5px"});
	}else if (totalVal >= 26  && totalVal <= 30){
		$(".text-box .content-list li, .social-icon").hide();
		$(".text-box .content-list li:eq(5)").show();
		$(".text-box p").css({"font-size":"15px","line-height":"21px"});
		$(".replay-bt").css({"margin-top":"5px"});

	}else{
		$(".text-box .content-list li, .social-icon").hide();
	}

}
$(function() {
    var source = [	
	"Katowice",
	"Kraków",
	"Łódź",
	"Poznań",
	"Tri-City (Gdańsk, Gdynia, Sopot)",
	"Warsaw",
	"Wrocław"
    ];

	/*$("#submite-val").autocomplete({
        source: function (request, response) {
            var term = $.ui.autocomplete.escapeRegex(request.term)
                , startsWithMatcher = new RegExp("^" + term, "i")
                , startsWith = $.grep(source, function(value) {
                    return startsWithMatcher.test(value.label || value.value || value);
                })
                , containsMatcher = new RegExp(term, "i")
                , contains = $.grep(source, function (value) {
                    return $.inArray(value, startsWith) < 0 && 
                        containsMatcher.test(value.label || value.value || value);
                });
            
            response(startsWith);
        }
    });*/


	$('#submite-val').autocomplete({
                source: source,
                minLength: 0,
                scroll: true
            }).focus(function() {
                $(this).autocomplete("search", "");
            });

});










