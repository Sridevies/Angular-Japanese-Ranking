function preload(arrayOfImages) {
    $(arrayOfImages).each(function(){
        $('<img/>')[0].src = this;
        // Alternatively you could use:
        // (new Image()).src = this;
    });
	//console.log(arrayOfImages);
}
// Usage:

preload([
    "images/quiz/01-Tri-City-1.png","images/quiz/01-Tri-City-2.png","images/quiz/01-Tri-City-3.png",
	"images/quiz/02-Wroclaw-1.png","images/quiz/02-Wroclaw-2.png","images/quiz/02-Wroclaw-3.png",
	"images/quiz/03-Katowice-1.png","images/quiz/03-Katowice-2.png","images/quiz/03-Katowice-3.png",
	"images/quiz/04-Lodz-1.png","images/quiz/04-Lodz-2.png","images/quiz/04-Lodz-3.png",
	"images/quiz/05-Warsaw-1.png","images/quiz/05-Warsaw-2.png","images/quiz/05-Warsaw-3.png",
	"images/quiz/06-Poznan-1.png","images/quiz/06-Poznan-2.png","images/quiz/06-Poznan-3.png",
	"images/quiz/07-Krakow-1.png","images/quiz/07-Krakow-2.png","images/quiz/07-Krakow-3.png",
	"images/bg-country.png","images/bg-country2.png"
]);

var quiz = {
	"question1":{
		"clueImages":["images/quiz/01-Tri-City-1.png","images/quiz/01-Tri-City-2.png","images/quiz/01-Tri-City-3.png"]
	},
	"question2":{
		"clueImages":["images/quiz/02-Wroclaw-1.png","images/quiz/02-Wroclaw-2.png","images/quiz/02-Wroclaw-3.png"]
	},
	"question3":{
		"clueImages":["images/quiz/03-Katowice-1.png","images/quiz/03-Katowice-2.png","images/quiz/03-Katowice-3.png"]
	},
	"question4":{
		"clueImages":["images/quiz/04-Lodz-1.png","images/quiz/04-Lodz-2.png","images/quiz/04-Lodz-3.png"]
	},
	"question5":{
		"clueImages":["images/quiz/05-Warsaw-1.png","images/quiz/05-Warsaw-2.png","images/quiz/05-Warsaw-3.png"]
	},
	"question6":{
		"clueImages":["images/quiz/06-Poznan-1.png","images/quiz/06-Poznan-2.png","images/quiz/06-Poznan-3.png"]
	},
	"question7":{
		"clueImages":["images/quiz/07-Krakow-1.png","images/quiz/07-Krakow-2.png","images/quiz/07-Krakow-3.png"]
	},
    "totalQuiz":7
}
