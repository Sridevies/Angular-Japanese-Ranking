[
{"City":"Dhahran Tower","Status":"Completed","Category":"Alpha","lattitude":26.337597,"longitude":50.200428},
{"City":"Lotus Residence","Status":"Completed","Category":"Alpha","lattitude":26.21965,"longitude":50.205547},
{"City":"Marbella Apartments","Status":"Completed","Category":"Alpha","lattitude":26.338481,"longitude":50.153131},
{"City":"Al Khobar Views","Status":"Future","Category":"Alpha","lattitude":26.325794,"longitude":50.215575},
{"City":"Jenan City","Status":"Future","Category":"Alpha","lattitude":26.328161,"longitude":50.18095},
{"City":"Retal Square","Status":"Future","Category":"Alpha","lattitude":26.329208,"longitude":50.2057},

{"City":"Dammam Business Gate","Status":"Completed","Category":"Beta","lattitude":26.411561,"longitude":50.133575},
{"City":"Khobar Gate Tower","Status":"Completed","Category":"Beta","lattitude":26.307825,"longitude":50.211353},
{"City":"Battoyor Tower","Status":"Completed","Category":"Beta","lattitude":26.377064,"longitude":50.178792},
{"City":"Al Othman Business Tower","Status":"Completed","Category":"Beta","lattitude":26.36685,"longitude":50.177414},
{"City":"Dar Al Yawm","Status":"Completed","Category":"Beta","lattitude":26.37885,"longitude":50.170756},
{"City":"Abdulhadi Al Hugayt","Status":"Future","Category":"Beta","lattitude":26.300119,"longitude":50.221347},

{"City":"Mall of Dhahran","Status":"Completed","Category":"Gamma","lattitude":26.306042,"longitude":50.169836},
{"City":"Al Rashid Mall","Status":"Completed","Category":"Gamma","lattitude":26.290669,"longitude":50.180842},
{"City":"Oasis Mall","Status":"Completed","Category":"Gamma","lattitude":26.205906,"longitude":50.198044},
{"City":"Dhahran Boulevard","Status":"Future","Category":"Gamma","lattitude":26.305344,"longitude":50.163178},
{"City":"Dammam Mall","Status":"Future","Category":"Gamma","lattitude":26.391506,"longitude":50.037272},
{"City":"Al Faisaliah Mall","Status":"Future","Category":"Gamma","lattitude":26.389889,"longitude":50.073969},

{"City":"Novotel Dammam Business Park","Status":"Completed","Category":"Delta","lattitude":26.407622,"longitude":50.138178},
{"City":"Holiday Inn Al Khobar Al Corniche","Status":"Completed","Category":"Delta","lattitude":26.316906,"longitude":50.218075},
{"City":"Park Inn By Radisson Dammam","Status":"Completed","Category":"Delta","lattitude":26.4531,"longitude":50.130661},
{"City":"Kempinski Al Othman","Status":"Completed","Category":"Delta","lattitude":26.366675,"longitude":50.177856},
{"City":"Centro By Rotana","Status":"Future","Category":"Delta","lattitude":26.305008,"longitude":50.225194},
{"City":"Garden Inn Hilton","Status":"Future","Category":"Delta","lattitude":26.306725,"longitude":50.175753}

]