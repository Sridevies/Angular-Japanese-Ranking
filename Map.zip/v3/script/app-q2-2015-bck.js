
var map;
	var plots=[], infoBubble1 = [], markers = [], availableTags = [],checkauto=0;

(function( $ ){
	$.ajaxSetup({ cache: true });
	
	var zind=1000;
	var zind1=1000;
		var zind2=1000;

  var parent, lastPlotCategory = "", markerFlag = true, indexLabels = ['Population','Commercial_Attraction','Economic_Size','Real_Estate_Investment','Cross_Border_Investment','BusinessHubIndexRank', 'CorporatePresenceIndexRank', 'ConnectivityIndexRank', 'InvestmentIndexRank', 'OfficeRentGrowthIndexRank', 'TransparencyIndexRank','City'], indexLabelsRanksTotal = ['0', '300', '660', '133', '128'],  infoBubbles = [], contentString, contentString1 = [], contentString2 = [], infoBubble,images = [{ 'Alpha' : 'images/red_dot.png', 'Gamma' : 'images/green_dot.png', 'Delta' : 'images/orange_dot.png', 'Beta' : 'images/blue_dot.png', 'NA': 'images/blue_dot.jpg' }], cityList, mapCanvas = jQuery('#map_canvas'), 
	  /*indicesDescription = [
		{	'BusinessHubIndexRank' : 'Our primary benchmark of the size and strength of a city\'s economy and real estate market ',
			'CorporatePresenceIndexRank' : 'A measure of corporate activity & attractiveness', 
			'ConnectivityIndexRank' : 'An indicator of accessibility which shows how well connected a city is',
			'InvestmentIndexRank' : 'Our proprietary index that measures the level of real estate investment activity in a city ',
			'OfficeRentGrowthIndexRank' : 'Our measure of prime office rental market momentum ',
			'TransparencyIndexRank': 'Which city has the most transparent market?  A ranking is based on Jones Lang LaSalle\'s biannual Global Real Estate Transparency Index.  For more information visit: <a href="http://www.joneslanglasalle.com/GRETI/en-gb/Pages/GlobalTransparencyIndex.aspx" target="_blank">http://www.joneslanglasalle.com/GRETI/en-gb/Pages/GlobalTransparencyIndex.aspx</a>' }]*/ indicesDescription = [
		{	'Population': "", 'CommercialAttraction' : 'Our primary benchmark of the size and strength of a city\'s economy and real estate market ',
			'EconomicSize' : 'A measure of corporate activity & attractiveness', 
			'RealEstateInvestment' : 'An indicator of accessibility which shows how well connected a city is',
			'CrossBorderInvestment' : 'Our proprietary index that measures the level of real estate investment activity in a city ' }] ,methods = {
    init : function( options ) {
		parent = this;

		var styles = [
			{
				featureType: 'landscape',
				elementType: 'all',
				stylers: [
					{ hue: '#D5D5D5' },
					{ saturation: -100 },
					{ lightness: -6 },
					{ visibility: 'simplified' }
				]
			},{
				featureType: 'landscape.man_made',
				elementType: 'all',
				stylers: [
					{ hue: '#BDBDBD' },
					{ saturation: -100 },
					{ lightness: -17 },
					{ visibility: 'simplified' }
				]
			},{
				featureType: 'road',
				elementType: 'geometry',
				stylers: [
					{ hue: '#D5D5D5' },
					{ saturation: -100 },
					{ lightness: 54 },
					{ visibility: 'on' }
				]
			},{
				featureType: 'road.highway',
				elementType: 'all',
				stylers: [
					{ hue: '#AEAEAE' },
					{ saturation: -100 },
					{ lightness: 12 },
					{ visibility: 'on' }
				]
			},{
				featureType: 'road.arterial',
				elementType: 'all',
				stylers: [
					{ hue: '#AEAEAE' },
					{ saturation: -100 },
					{ lightness: -11 },
					{ visibility: 'on' }
				]
			},{
				featureType: 'road.local',
				elementType: 'all',
				stylers: [
					{ hue: '#AEAEAE' },
					{ saturation: -100 },
					{ lightness: -32 },
					{ visibility: 'on' }
				]
			},{
				featureType: 'poi',
				elementType: 'all',
				stylers: [
					{ hue: '#BDBDBD' },
					{ saturation: -100 },
					{ lightness: -5 },
					{ visibility: 'simplified' }
				]
			}
		];


		map = new google.maps.Map(jQuery('#map_canvas')[0], {
			mapTypeControlOptions: {
				mapTypeIds: [ 'Styled']
			},
			zoom: 3,
		    minZoom: 10,
			styles: styles,
			center: new google.maps.LatLng(26.3101221, 49.9658218),
			mapTypeId: google.maps.MapTypeId.ROADMAP
		});	

		$.ajax({
			type: 'get',
			async: false,
			url: "data/data.js",
			dataType: "json",
			contentType: "application/json; charset=utf-8",
			cache: false,
			data: {},
			success: function(json){
				//alert(JSON.stringify(json));
				cityList = json;
				cityList.sort(function(a, b){
					return [a.City] < [b.City] ? -1 : 1;
				});
				parent.citytool("renderMap");
				parent.citytool("bindCitiesList");
				parent.citytool("setCategoryChange");
			},
			error: function(XMLHttpRequest,status,error){
				alert(error);
			}
		})

		setTimeout(function(){ $("input[type=checkbox]").removeAttr("checked"); }, 500 );
		
    },
	setCategoryChange: function(){
	
		/*plots.push("Alpha");
			plots.push("Beta");*/
			
			$(".globalb").removeClass("active");			
		$(".btn-category-map li").bind("click", function(e){
			e.preventDefault();
			$(this).find("a").toggleClass("active");
			var rel	=	$("a", this).attr("rel");
			$.each(infoBubble1, function(ix, vx) {
				//setTimeout(function(){
					if(ix >= 0) {
						infoBubble1[ix].close();
					}
				//}, 40)
			});
			//
		
			for (i in markers) 
			{
				//setTimeout(function(){
					markers[i].setVisible(false);
				//}, 50)
				
				/*markers[i].setMap(null);
				console.log(markers[i].catogery); */
			}
			
			$(".ui-autocomplete-input").val("");
			
			lastPlotCategory = rel;
//			
		
            if( rel == "" || rel == undefined ) {
				//console.log("in else");
				 plots.splice(0,plots.length);
				 parent.citytool("renderMap", [rel]);
					$(".btn-category-map li a").removeClass("active");
					$(".globalb").addClass("active");		
				 }
			 else{
					
					$(".globalb").removeClass("active");
					if($.inArray(rel,plots) == -1)
					{
						//console.log("test");
						plots.push(rel);
						//console.log("If Statement Set Visible");
					 
					}
					else{
						if(checkauto != 1){
							$(this).find("a").removeClass("active");
							plots.splice($.inArray(rel,plots),1);
							//console.log("Else Statement Set Visible");
						}
						else{
							$(this).find("a").addClass("active");
						}
					}
					
					
					$.each(plots,function(i){
					//console.log("plot value"+plots[i]);
						setTimeout(function(){
						
						for (j in markers) 
							{
							//setTimeout(function(){
							if(markers[j].catogery == plots[i])
								{
								//parent.citytool("renderMap", [rel]);
									//markers[j].setMap(null);
									markers[j].setVisible(true);
									//console.log("Set Visible");
									 
								}
							//}, 50)
								//console.log(markers[j].catogery); 
							}
							
						}, 30)
					//parent.citytool("renderMap", plots[i]);
					});
					//console.log(plots.length);
					/*
					if(plots.length == 0)
					 { 
						parent.citytool("renderMap", [rel]);
					}*/
				}
			 checkauto=0;
			 // parent.citytool("renderMap", [rel])
			
			parent.citytool("bindAutoComplete", [rel])
		})

		$(".compare-city-map").live("click touchstart", function(e){
			e.preventDefault();
			var id = $(this).attr("rel");
			if( $(".city-chk-list-all:checked").size() == 11 ) {
				alert("You can select a maximum of 10 Cities to Compare. Please deselect a City to select another");
				return false;
			}
			$(".city-chk-list"+id+", .chk-city-list-dd-sel[rel="+id+"]").attr("checked", "checked").parent().removeClass("highlight").addClass("highlight")

			//$(".comcit").trigger("click");
			if( $(".fullscreen").is(":visible") ) {
				$(".compareCities").css({ "z-index": "100000", "top": -50, "left": -20 }).show()
				$(".background-greyed-out").css({ "width": $(window).width(), "height": $(window).height(), "padding-left" : ( $(window).width() - $(".main_container:visible").width() ) / 2 })
			} else {
				$(".compareCities").css({ "top": $(".citiesWrap").offset().top - ( $(".mainNav").height() + 40 ), "left": $(".citiesWrap").offset().left - 20 }).show()
				$(".background-greyed-out").css({ "width": $(".citiesWrap").width(), "height": $(".citiesWrap").height() + 150, "padding-left" : ( $(".citiesWrap").width() - $(".main_container:visible").width() ) / 2 })
				
			}
			$('.divHide, #thisdiv, #thisdiv1').hide(); 
			$('#thisdiv2, #thisdiv3, .compareCities').show();
			
		})

		/*$(".infoIcon").live("mouseover",function(e){
			$(this).find('span').show();
		});

		$(".infoIcon").live("mouseout",function(e){
			$(this).find('span').hide();
		});*/

			$('a.clickable').live('mouseover', function () {
				$('.infoIcon1').hide();
				//var rel_Att= $(this).attr('rel');
				//$("#TipBox"+rel_Att).fadeIn();
				$(this).next().show();
			});
			$('.infoIcon1').live('mouseleave', function(){
					$(this).hide();
			})
			

			if ( (navigator.userAgent.match(/iPhone/i)) 
			   || (navigator.userAgent.match(/iPod/i) ) 
			   || (navigator.userAgent.match(/iPad/i))) 
			{
				  $('a.clickable').live('touchstart', function () {
					$('.infoIcon1').css("z-index","99999999 !important");
					$('.clickable').css("z-index","99999999 !important");

					$('.infoIcon1').hide();
					var rel_Att= $(this).attr('rel');
						$("#TipBox"+rel_Att).fadeIn();
					});
					$('.close_button').live('touchstart', function(){
					$('.infoIcon1').stop("false","false").hide();
				})
				
			}




			/*$('a.clickable1').live('click', function () {
			$('.infoIcon').hide();
			var rel_Att= $(this).find("a").attr("href");
				$(rel_Att).fadeIn();
			});
				$('.close_button1').click(function(){
				$('.infoIcon').stop("false","false").hide();
			}) */


		$(".city-chk-list-all").live("click", function(e){
			if( $(this).is(":checked") ) {
				if( $(".city-chk-list-all:checked").size() == 11 ) {
					alert("You can select a maximum of 10 Cities to Compare. Please deselect a City to select another");
					return false;
				}
				$("#thisdiv1").niceScroll({autohidemode: "false" });

				$(".chk-city-list-dd-sel[rel="+($(this).attr("rel"))+"]").prop("checked",true);
				$(".chk-city-list-dd-sel[rel="+($(this).attr("rel"))+"]").parent().addClass("highlight");
				$(this).parent().addClass("highlight");
			}
			else{
				$(".chk-city-list-dd-sel[rel="+($(this).attr("rel"))+"]").prop("checked",false);
				$(".chk-city-list-dd-sel[rel="+($(this).attr("rel"))+"]").parent().removeClass("highlight");
				$(this).parent().removeClass("highlight");
			}

			//$("#thisdiv1").getNiceScroll().resize()
		})

		$(".city-chk-index").live("click", function(){
			if( $(this).is(":checked") ) {
				if( $(".city-chk-index:checked").size() == 4 ) {
					alert("You can select a maximum of 3 indicators. Please deselect an indicator to choose another");
					return false;
				}
				$(this).parent().toggleClass("highlight");
				$(".chk-label-index-graph[rel="+($(this).attr("rel"))+"]").prop("checked",true);
				$(".chk-label-index-graph[rel="+($(this).attr("rel"))+"]").parent().addClass("highlight");
			}
			else{
				$(this).parent().toggleClass("highlight");
				$(".chk-label-index-graph[rel="+($(this).attr("rel"))+"]").prop("checked",false);
				$(".chk-label-index-graph[rel="+($(this).attr("rel"))+"]").parent().removeClass("highlight");
			}
		})

		$(".city-cobweb-map").live("click touchstart", function(e){
			e.preventDefault();
			var id = $(this).attr("rel");

			if( $(".city-chk-list-cobweb-all:checked").size() == 11 ) {
				alert("You can select a maximum of 10 Cities to Compare. Please deselect a City to select another");
				return false;
			}
			//alert("highlight")
			$(".city-chk-cobweb-list"+id).attr("checked", "checked").parent().removeClass("highlight").addClass("highlight")
			//$(".comcob").trigger("click");

			if( $(".fullscreen").is(":visible") ) {
				$(".compareCobweb").css({ "z-index": "100000", "top": -50, "left": -20 }).show()
				$(".background-greyed-out1").css({ "width": $(window).width(), "height": $(window).height(), "padding-left" : ( $(window).width() - $(".main_container:visible").width() ) / 2 })
			} else {
				$(".compareCobweb").css({ "top": $(".citiesWrap").offset().top - ( $(".mainNav").height() + 50 ), "left": $(".citiesWrap").offset().left - 20 }).show()
				$(".background-greyed-out1").css({ "width": $(".citiesWrap").width(), "height": $(".citiesWrap").height() + 150, "padding-left" : ( $(".citiesWrap").width() - $(".main_container:visible").width() ) / 2 })
				
			}
			$('#thisdiv, #thisdiv1').show();
			$('.compareCityIndi').hide(); 
			$("#thisdiv1").niceScroll({autohidemode: "false" });

			$(".cobweb-image-cnt").hide();
			$(".city-chk-list-cobweb-all").each(function(){
				if( $(this).is(":checked") ) {
					$(".cobweb-image-cnt"+$(this).attr("rel")).show()
				}
			})
			$("#thisdiv1").getNiceScroll().resize();
			//$("#thisdiv1").niceScroll();			
		})

		$(".city-chk-list-cobweb-all").live("click", function(e){
			if( $(".city-chk-list-cobweb-all:checked").size() == 13 ) {
				alert("You can select a maximum of 12 Cities to Compare. Please deselect a City to select another");
				return false;
			}
			$(this).parent().toggleClass("highlight")
			
			$(".cobweb-image-cnt").hide()

			$(".city-chk-list-cobweb-all").each(function(){
				if( $(this).is(":checked") ) {
					$(".cobweb-image-cnt"+$(this).attr("rel")).show()
				}
			})

			$("#thisdiv1").getNiceScroll().resize();
		})

		$(".close-cob-web").live("click", function(e){
			e.preventDefault();
			$(this).parents(".cobweb-image-cnt").hide();

			$(".city-chk-cobweb-list"+$(this).parents(".cobweb-image-cnt").attr("rel")).attr("checked", false).parent().removeClass("highlight");
			$("#thisdiv1").getNiceScroll().resize();
		})

		$(".compare-cities-graph").click(function(e){
			e.preventDefault();			

			if( $(".city-chk-list-all:checked").size() < 2 )
			{
				alert("Please select atleast 2 countries");
				return false;
			}

			if( $(".city-chk-index:checked").size() < 1 )
			{
				alert("Please select atleast 1 indicator");
				return false;
			}

			parent.citytool("renderGraph");			

			$('.divHide, #thisdiv, #thisdiv1, #thisdiv2, #thisdiv3').hide();

			if( !$(".fullscreen").is(":visible") )
			{
				$(".compareCityIndi").css({ "top": $(".citiesWrap").offset().top - ( $(".mainNav").height() + 25 ), "left": $(".citiesWrap").offset().left - 20 }).show()
				$(".background-greyed-out2").css({ "width": $(".citiesWrap").width(), "height": $(".citiesWrap").height() + 100, "padding-left" : ( $(".citiesWrap").width() -	$(".main_container:visible").width() ) / 2 })
			} else {
				$(".compareCityIndi").css({ "z-index": "100000", "top": -50, "left": -20 }).show()
				$(".background-greyed-out2").css({ "width": $(window).width(), "height": $(window).height(), "padding-left" : ( $(window).width() - $(".main_container:visible").width() ) / 2, "padding-top": "50px" })
			}
			//$('.compareCityIndi').show();
		})

		$(".reset-compare-cities-graph").click(function(e){
			$(".city-chk-list-all").prop('checked', false);
			$(".city-chk-list-all").parent().removeClass("highlight");

			$(".city-chk-index").prop('checked', false);
			$(".city-chk-index").parent().removeClass("highlight");

			$(".chk-city-list-dd-sel").prop('checked', false);
			$(".chk-city-list-dd-sel").parent().removeClass("highlight");
			
			$(".chk-label-index-graph").prop('checked', false);
			$(".chk-label-index-graph").parent().removeClass("highlight");
		})

		$(".reset-compare-cobweb").click(function(e){
			$(".city-chk-list-cobweb-all").prop('checked', false);
			$(".city-chk-list-cobweb-all").parent().removeClass("highlight");
			$(".cobweb-image-cnt").hide();
		})

		$(".chk-label-index-graph").live("click", function(e){
			if( $(this).is(":checked") ) {
				if( $(".chk-label-index-graph:checked").size() == 4 ) {
					alert("You can select a maximum of 3 indicators. Please deselect an indicator to choose another");
					return false;
				}

				$(".city-chk-index[rel="+($(this).attr("rel"))+"]").prop("checked",true);
				$(".city-chk-index[rel="+($(this).attr("rel"))+"]").parent().addClass("highlight");

				$(this).parent().addClass("highlight");
			} else {
				$(".city-chk-index[rel="+($(this).attr("rel"))+"]").prop("checked",false);
				$(".city-chk-index[rel="+($(this).attr("rel"))+"]").parent().removeClass("highlight");
				$(this).parent().removeClass("highlight");
			}
			parent.citytool("renderGraph");
		})

		$(".chk-city-list-dd-sel").live("click", function(e){
			if( $(this).is(":checked") ) {
				if( $(".city-chk-list-all:checked").size() == 10 ) {
					alert("You can select a maximum of 10 Cities. Please deselect a City to choose another");
					return false;
				}
				$(".city-chk-list-all[rel="+($(this).attr("rel"))+"]").prop("checked",true);
				$(".city-chk-list-all[rel="+($(this).attr("rel"))+"]").parent().addClass("highlight");
				$(this).parent().addClass("highlight");
			} else {
				$(".city-chk-list-all[rel="+($(this).attr("rel"))+"]").prop("checked",false);
				$(".city-chk-list-all[rel="+($(this).attr("rel"))+"]").parent().removeClass("highlight");
				$(this).parent().removeClass("highlight");
			}

			parent.citytool("renderGraph");
		})

		parent.citytool("bindAutoComplete", [""])
		
	},
	renderGraph: function(){
		
		var tmpChkdCities = [], tmpChkIndex = [], tmp = [];

		$(".city-chk-list-all:checked").each(function(){
			tmpChkdCities.push({ "id": $(this).attr("rel"), "city_name": $(this).parent().find("span").html(), "category": $(this).attr("data-category") });
			
		})

		$(".city-chk-index:checked").each(function(){
			tmpChkIndex.push({ "id": $(this).attr("rel"), "label_name": $(this).parent().find("span").html() });
		})
		$(".graph-container").empty();
		var tmpStr = "", tmpStr1 = "", tmpStrtit = "";

		$.each(tmpChkIndex, function(k,v){	
			var t = (indexLabels[v.id]), tmpStr1 = "";
			setTimeout(function(){
			$.each(tmpChkdCities, function(k1,v1){
				setTimeout(function(){
				if( typeof(eval("dataList[v1.city_name]."+t)) != "undefined" && (eval("dataList[v1.city_name]."+t)) != "" ) {
					
					var calc  = (eval("dataList[v1.city_name]."+t)).split(")");
					var total = indexLabelsRanksTotal[v.id];
					var bgPos = eval(calc[1]) * ( 178 / eval(total) );
					//var bgPos = ( eval(calc[0]) / eval(total) ) * 178;
					
					
					tmpStr1 += '<div class="'+v1.category+'-graph graph-bars" rel="'+bgPos+'" data-dummy="'+(eval("cityList[v1.id]."+t))+'" style="display: none; background-position: -'+(bgPos)+'px">'+v1.city_name+ ' ('+$.trim(calc[1])+')</div>';

				} else {
					tmpStr1 += '<div class="'+v1.category+'-graph graph-bars" rel="'+bgPos+'" data-dummy="'+(eval("cityList[v1.id]."+t))+'" style="display: none; color: #CCC; background-position: -'+(bgPos)+'px">'+(v1.city_name)+' (NA)</div>';
				}
				}, 100)
			})
			
			tmpStrtit +='<td valign="top"><div class="select-city-indi-width"><div class="select-cob-web1">'+v.label_name+' <a href="javascript:;" class="clickable" rel="11"></a><div class="infoIcon1" id="TipBox20" style="display:none"><img src="images/closeBtn.png" width="27" height="27" alt="" class="close_button"/>'+(eval("indicesDescription[0]."+t))+'</div></div></div></td><td width="15"><img src="images/spacer.gif" alt="" /></td>';

			tmpStr += '<td valign="bottom"><table><tr><td valign="top" style="border-left:1px solid #AEAFB0; border-bottom:1px solid #AEAFB0;"><div class="select-city-indi-width"><div class="Select-Cob-Webs-compare-graph">'+tmpStr1+'</div></div></td></tr><tr><td valign="top"><b>Lower</b>&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<b>Higher</b></td></tr></table></td><td width="15"><img src="images/spacer.gif" alt="" /></td>';
			}, 50)
			// <img src="images/number.jpg" border="0" />
		})

		$(".chk-city-list-dd checkbox").removeAttr("checked")
		$.each(tmpChkdCities, function(k,v){
			setTimeout(function(){
				$(".chk-city-list-dd-sel[rel="+v.id+"]").attr("checked", "checked");
				$(".chk-city-list-dd-sel[rel="+v.id+"]").addClass("highlight");
			}, 75);
		})

		$(".chk-label-index-graph").removeAttr("checked")
		$.each(tmpChkIndex, function(k,v){
			$(".chk-label-index-graph[rel="+v.id+"]").attr("checked", "checked")
		})
		$(".graph-containertitle").html( tmpStrtit );
		$(".graph-container").html( tmpStr );
		
		$.getScript("script/jquery.tinysort.min.js", function(){
			//alert("Test");
			$(".graph-bars").tsort({attr:'rel', order: 'asc'})
		})

		$('.graph-bars').show()
	},
	bindAutoComplete: function(category){
			//console.log(plots);
		if( category != "" ) {
			var tmp = [];
			$("body").append( $("<div>").addClass("formatDummy") );
			$.each(cityList, function(k,v){
				//if( v.Category == category ) {
					$(".formatDummy").html(v.City);
					tmp.push( { label: $(".formatDummy").html(), value: $(".formatDummy").html(), desc: k } );
				//}
			})

			$(".formatDummy").remove();
			$( ".tags" ).autocomplete("destroy")
			availableTags = tmp;
		}
		else{
			var tmp = [];
			$("body").append( $("<div>").addClass("formatDummy") );
			$.each(cityList, function(k,v){
				$(".formatDummy").html(v.City);
				tmp.push( { label: $(".formatDummy").html(), value: $(".formatDummy").html(), desc: k } );
			})

			$(".formatDummy").remove();
			//$( ".tags" ).autocomplete("destroy")
			availableTags = tmp;
		}
		
		if(availableTags.length < 100){			
			$('.ui-autocomplete').css({"":""});
		}
		
		$( ".tags" ).autocomplete({
		  source: availableTags,
		  focus: function( event, ui ) {
			$( ".tags" ).val( ui.item.label );
			return false;
		  },
          select: function( event, ui ) {
				  $.each(cityList,function(i,v){
					if(v.City == ui.item.value)
					  {
						category=v.Category;
					  }
			      })
			 checkauto=1;
			 $('a[rel='+category+']').parent().trigger("click");
			 
			 //$(".btn-category-map li").trigger("click")
			 $.each(infoBubble1, function(ix, vx) {
				 
				if(ix >= 0){
					infoBubble1[ix].close();
				}
			});
			
			infoBubble1[ui.item.desc].open(map, markers[ui.item.desc]);
          }
		});

		 $.ui.autocomplete.filter = function (array, term) {
			var matcher = new RegExp("^" + $.ui.autocomplete.escapeRegex(term), "i");
			return $.grep(array, function (value) {
				return matcher.test(value.label || value.value || value);
			});
		};
	},
	renderMap: function(category){
		
		//console.log(category);
		var condFilter	=	"";

		if( category == "" || category == undefined ) {
			condFilter	=	"true";
		//condFilter	=	"v.Category == 'Alpha'";
		} else {
			condFilter	=	"v.Category == '"+category+"'";
		}

		google.maps.Map.prototype.setCenterWithOffset= function(latlng, offsetX, offsetY) {
			var map = this;
			var ov = new google.maps.OverlayView();
			ov.onAdd = function() {
				var proj = this.getProjection();
				var aPoint = proj.fromLatLngToContainerPixel(latlng);
				aPoint.x = aPoint.x+offsetX;
				aPoint.y = aPoint.y+offsetY;
				map.panTo(proj.fromContainerPixelToLatLng(aPoint));
			}; 
			ov.draw = function() {}; 
			ov.setMap(this); 
		};

		$.each(cityList, function(k, v) {
			
			setTimeout(function(){
			if( eval(condFilter) )
			{

				var color="";
				if((v.Category).toLowerCase()=="alpha")
				{
					if((v.Status).toLowerCase()=="completed")
					{
						color="green";
					}else{
						color="greenin";
					}
				}

				else if((v.Category).toLowerCase()=="beta")
				{
					if((v.Status).toLowerCase()=="completed")
					{
						color="blue";
					}else{
						color="bluein";
					}
				}
				else if((v.Category).toLowerCase()=="gamma")
				{
					if((v.Status).toLowerCase()=="completed")
					{
						color="red";
					}else{
						color="redin";
					}
				}
				else if((v.Category).toLowerCase()=="delta")
				{
					if((v.Status).toLowerCase()=="completed")
					{
						color="orange";
					}else{
						color="orangein";
					}
				}
				var zoomLevel = map.getZoom();
				
				
				var tmpImg = "images/"+color+"_dot.png";
				
				if( zoomLevel > 5 ) {

					tmpImg = "images/"+color+"_pin_small.png";
					
				}
				
				function hideMarkers() {
					//Loop through all the markers and remove
					for (var i = 0; i < markers.length; i++) {
						markers[i].setMap(null);
					}
					markers = [];
				};

				var marker = new google.maps.Marker({
					position: new google.maps.LatLng(v.lattitude, v.longitude),
					map: map, 
					
					optimized:false,
				    suppressMarkers : true,
					catogery: v.Category,
					icon: tmpImg
				});
				//markers[i].setVisible(false);
				contentString = "<div class='tooltip "+(v.Category).toLowerCase()+" tool'><img src='images/tooltip-down-arrow_"+color+".png' class='callout' />"+(v.City)+"</div></div>";
				contentString2[k]	=	"";
								if(v.City =="San Jose,USA" || v.City =="San Jose, Costa Rica" || v.City =="Hyderabad, India" || v.City =="Hyderabad, Pakistan")
								{
								contentString1[k] = '<div class="cityname box '+(v.Category).toLowerCase()+'"><span class="'+(v.Category).toLowerCase()+'"><b>'+(v.City)+'</b></span></div>'+
									'<div class="citydetails" style="overflow:hidden;">';
								}
								else
				                {
									
								contentString1[k] = '<div class="cityname box '+(v.Category).toLowerCase()+'"><span class="'+(v.Category).toLowerCase()+'"><b style="font-size: 14px;">'+(v.City)+'</b></span></div>'+
									'<div class="citydetails" style="overflow:hidden;">';
								}


				
						if((v.Category).toLowerCase()=="alpha" && v.Cobweb && v.Cobweb != undefined && (v.Cobweb).toLowerCase() != "" )
						{
							contentString1[k] += '<div class="Citygreyhead one '+(v.Category).toLowerCase()+'img" style="overflow:hidden;font-size: 14px;line-height: 2.6;padding-left: 37px;"><span class="pullLeft">Charting City Competitiveness</span><img src="images/arrow-bottom_white_6.png" style="float: right; margin-top: 15px;" /></div>'+
							'<a href="javascript:;" class="city-cobweb-img finfaccd"  style="position:relative;" rel="'+v.Cobweb+'" data-title="'+( v.Status )+'" data-id="'+k+'"><IMG SRC="images/magnifying-glass-icon_50.png" class="testimg" width="50px" height="50px" BORDER="0" ALT="Zoom" style="position:absolute; top:127px;z-index: 200; left:192px; "><img src="images/cobwebs/large/q2-2015/'+v.Cobweb+'" width="430" alt="" border="0" style="position:relative" /></a>';
							//'<div class="Cityhead '+(v.Category).toLowerCase()+'" style="overflow:hidden;line-height: 2.6;padding-left: 37px;"><a href="javascript:;" class="city-cobweb-map smCnt" rel="'+k+'"><img src="images/whitearrow.png" alt="" border="0">Compare cities (top 30)</a></div>';
							
						}
						
						contentString1[k] += 
						'<div class="citydata '+(v.Category).toLowerCase()+'cont accord-cont">'+
							'<table cellspacing="0" cellpadding="5" border="0" width="100%">';
								contentString1[k] += '<tr>'+
										'<td class="indextxt1"><span><strong style="font-size: 14px;">Status</strong></span></td>'+'<td class="rank" nowrap><b style="font-size: 14px; float:right;">'+( v.Status )+'</b></td>'+
									'</tr>';
						//console.log(v.City);
						//console.log(dataList[v.City]);
								/*if( dataList[v.City].Population && dataList[v.City].Population != undefined && dataList[v.City].Population != "" )
								{
									if(v.City =="Chennai")
									{*/
									//console.log(v.City);

									//}
									/*
									if(v.City =="Chennai")
									{
										var chk="123,4556";
										console.log(parseInt(chk.replace(',','')));
									}
									

									contentString1[k] += '<tr>'+
										'<td class="indextxt1"><span><strong style="font-size: 14px;">Status</strong></span></td>'+'<td class="rank" nowrap><b style="font-size: 14px; float:right;">'+( v.Status )+'</b></td>'+
									'</tr>';
									
								}*/ /*else {
									contentString2[k]	+= '<tr style="color: #b2b2b2">'+
										'<td class="indextxt1"><span>Business Hub Index</span><a href="javascript:;" class="infoIcon" ><img src="images/info-icon-static-20.png"/></a><span class="iDesc">Description</span></td>'+
										'<td class="rank">NA</td>'+
									'</tr>';
								}*/
								//console.log(dataList[v.City].Commercial_Attraction.split(")").pop())
								/*if(typeof(dataList[v.City].Commercial_Attraction)!="undefined" && dataList[v.City].Commercial_Attraction.split(")").pop() != "null")
								{
									//console.log((dataList[v.City].Commercial_Attraction).split(')')[1]);
									//console.log(dataList[v.City].Commercial_Attraction.split(')')[1]+","+v.City);

									contentString1[k] += '<tr>'+
										'<td class="indextxt1"><a href="javascript:;" class="clickable flowit" rel="11"><img src="images/info-icon-static-30.png" border="0"  /></a><div class="infoIcon1 comat" id="TipBox11" style="display:none"><p style="color:#ffffff;">Our primary benchmark of the size and strength of a city\'s economy and real estate market</p></div><span><b style="font-size: 14px;">Commercial Attraction</b></span></td>'+'<td class="rank" style="font-size: 14px !important;" ><span class="test" style="font-size: 16px;float:left;font-family: Times, Times New Roman, Georgia, serif; margin-left: 30px;">'+(dataList[v.City].Commercial_Attraction).split(')')[0]+') </span><span style="float: right; font-size: 14px;"><b>'+(dataList[v.City].Commercial_Attraction).split(')')[1]+'</b></span></td>'+
									'</tr>';
								} else {
									contentString2[k]	+= '<tr style="color: #b2b2b2">'+
										'<td class="indextxt1"><span>Corporate Presence Index</span><a href="javascript:;" class="infoIcon"><img src="images/info-icon-static-20.png"/></a><span class="iDesc">Description</span></td>'+
										'<td class="rank">NA</td>'+
									'</tr>';
								}*/

								/*if(typeof(dataList[v.City].Economic_Size)!="undefined" && dataList[v.City].Economic_Size.split(")").pop() != "null")
								{
									contentString1[k] += '<tr>'+
										'<td class="indextxt1"><a href="javascript:;" class="clickable flowit" rel="12"><img src="images/info-icon-static-30.png" border="0"  /></a><div class="infoIcon1 eco" id="TipBox12" style="display:none"><p style="color:#ffffff;line-height: 2;">Estimate of annual economic output of the metropolitan area.</p></div><span><b style="font-size: 14px;">Economic Size</b></span></td>'+'<td class="rank"><span class="test" style="font-size: 16px;float:left;font-family: Times, Times New Roman, Georgia, serif; margin-left: 30px;">'+(dataList[v.City].Economic_Size).split(')')[0]+') </span><span style="float: right; font-size: 14px;"><b>'+(dataList[v.City].Economic_Size).split(')')[1]+'</b></span></td>'+
									'</tr>';
								} else {
									contentString2[k]	+= '<tr style="color: #b2b2b2">'+
										'<td class="indextxt1"><span>Connectivity Index</span><a href="javascript:;" class="infoIcon"><img src="images/info-icon-static-20.png"/></a><span class="iDesc">Description</span></td>'+
										'<td class="rank">NA</td>'+
									'</tr>';
								}*/

								/*if( typeof(dataList[v.City].Real_Estate_Investment)!="undefined" && dataList[v.City].Real_Estate_Investment.split(")").pop() != "null")
								{
									contentString1[k] += '<tr>'+ 
										'<td class="indextxt1"><a href="javascript:;" class="clickable flowit" rel="13"><img src="images/info-icon-static-30.png" border="0"  /></a><div class="infoIcon1 real" id="TipBox13" style="display:none"><p style="color:#ffffff;">Our proprietary index that measures the level of real estate investment activity in a city</p></div><span><b style="font-size: 14px;">Real Estate Investment</b></span></td>'+'<td class="rank"><span class="test" style="font-size: 16px;float:left;font-family: Times, Times New Roman, Georgia, serif; margin-left: 30px;">'+(dataList[v.City].Real_Estate_Investment).split(')')[0]+') </span><span style="float: right; font-size: 14px;"><b>'+(dataList[v.City].Real_Estate_Investment).split(')')[1]+'</b></span> </td>'+
									'</tr>';
								} else {
									contentString2[k]	+= '<tr style="color: #b2b2b2">'+
										'<td class="indextxt1"><span>Real Estate Investment</span><a href="javascript:;" class="infoIcon"><img src="images/info-icon-static-20.png"/></a><span class="iDesc">Description</span></td>'+
										'<td class="rank">NA</td>'+
									'</tr>';
								}*/

								/*if( typeof(dataList[v.City].Cross_Border_Investment)!="undefined" && dataList[v.City].Cross_Border_Investment.split(")").pop() != "null")
								{
									//console.log((dataList[v.City].Cross_Border_Investment).split(')')[0] + "---test")
									contentString1[k] += '<tr>'+
										'<td class="indextxt1"><a href="javascript:;" class="clickable flowit" rel="13"><img src="images/info-icon-static-30.png" border="0"  /></a><div class="infoIcon1 cross" id="TipBox13" style="display:none"><p style="color:#ffffff;">Our proprietary index that measures the level of cross-border real estate investment activity in a city.</p></div><span><b style="font-size: 14px;">Cross Border Investment</b></span></td>'+'<td class="rank"><span class="test" style="margin-left: 30px;float:left; font-size: 16px;font-family: Times, Times New Roman, Georgia, serif">'+(dataList[v.City].Cross_Border_Investment).split(')')[0]+') </span><span style="float: right;font-size: 14px;"><b>'+(dataList[v.City].Cross_Border_Investment).split(')')[1]+'</b></span></td>'+

									'</tr>';
								} else {
									contentString2[k]	+= '<tr style="color: #b2b2b2">'+
										'<td class="indextxt1"><span>Office Rent Growth</span><a href="javascript:;" class="infoIcon"><img src="images/info-icon-static-20.png"/></a><span class="iDesc">Description</span></td>'+
										'<td class="rank">NA</td>'+
									'</tr>';
								}*/

								/*if( typeof(dataList[v.City].Transparency_Level) !="undefined" && dataList[v.City].Transparency_Level != "" )
								{
									contentString1[k] += '<tr>'+
										'<td class="indextxt1"><a href="javascript:;" class="clickable flowit" rel="14"><img src="images/info-icon-static-30.png" border="0"  /></a><div class="infoIcon1" id="TipBox14" style="display:none"><p style="color:#ffffff;">Based on our global biennial survey and a series of quantitative measures, this index provides a benchmark of real estate market transparency</p></div><span><b style="font-size: 14px;">Transparency Level</b></span></td>'+
										'<td class="rank" nowrap><b style="font-size: 14px; float: right;">'+dataList[v.City].Transparency_Level+'</b></td>'+
									'</tr>';
								} else {
									contentString2[k]	+= '<tr style="color: #b2b2b2">'+
										'<td class="indextxt1"><span>Real Estate Transparency index</span><a href="javascript:;" class="infoIcon"><img src="images/info-icon-static-20.png"/></a><span class="iDesc">Description</span></td>'+
										'<td class="rank">NA</td>'+
									'</tr>';
								}*/

								contentString1[k] += contentString2[k];
								contentString1[k] += '</table>'+'</div>';

								if((v.Category).toLowerCase()=="alpha")
								{
									contentString1[k] += '<div class="Cityhead '+(v.Category).toLowerCase()+'"  style="overflow:hidden;display: none;line-height: 2.6;padding-left: 37px;">';
									contentString1[k] += '<img src="images/whitearrow.png" alt="" border="0">'+(v.City)+' Paragraph';
									contentString1[k] += '</div><div class="'+(v.Category).toLowerCase()+'cont" style="display: none;padding:10px 10px 10px 10px">'+(v.City)+' paragraph contents will come here.</div>';
								}

								
						/*if( v.SelectionChoiceForComparison=="YES" && ( v.Category == 'Alpha' || v.Category == 'Beta' ))
						{
							contentString1[k] += '<div class="Cityhead '+(v.Category).toLowerCase()+'"  style="overflow:hidden;line-height: 2.6;padding-left: 37px;">';
							contentString1[k] +='<a href="javascript:;" class="compare-city-map smCnt" rel='+(k)+'><img src="images/whitearrow.png" alt="" border="0">Compare indices (top 100)</a>';
							contentString1[k] += '</div>';
						}*/
						//'<div class="Citygreyhead" style="overflow:hidden;">City Cobweb</div>'+
						
						//contentString1[k] += '<div class="cityinndata '+(v.Category).toLowerCase()+'cont rad">'+'<ul class="roundbot">';
								//'<li><a href="javascript:;">'+(v.City)+' City profile</a></li>'+
								//contentString1[k] += '<li><a href="javascript:;">Search '+(v.City)+' Research</a></li>';
								if( v.BusinessLink != "" && v.BusinessLink != undefined ) {
										contentString1[k] +='<li><p><a href="'+v.BusinessLink+'" color="#2E75C1" target="_blank">Our Real Estate services in this market</a></p></li>';
								}
							contentString1[k] += '</ul>'+
						'</div>'+
					'</div>';
							zind++;
							//console.log(zind);
				// Creating / Initiating Infobox					
				infoBubble = new InfoBox({
					 content: contentString, // Tab content gets appended here
					 disableAutoPan: true, 
					 maxWidth: 0, 
					 pixelOffset: new google.maps.Size(0,-55), 
					 zIndex: zind, 
					 boxClass: 'tooltiph',
					 boxStyle: { 
						//background: "url('tipbox.gif') no-repeat", 
						opacity: 1, 
						width: "300px"
					 }, 
						 closeBoxURL: "",
					 infoBoxClearance: new google.maps.Size(1, 1), 
					 isHidden: false, 
					 pane: "floatPane", 
					 enableEventPropagation: true
				});
					 						//console.log(infoBubble1[k]);
					zind1=zind1+zind;
				/*infoBubble1[k] = new InfoBox({

					 content: contentString1[k], // Tab content gets appended here.
					 disableAutoPan: false, 
					 maxWidth: 0, 
					 pixelOffset: new google.maps.Size(5, 5), 
					 zIndex:9999, 
					 boxClass: 'popupinfobox',
					 boxStyle: { 
						//background: "url('tipbox.gif') no-repeat", 
						opacity: 1, 
						width: "300px"
						//font-family:"Arial, Helvetica Neue, Helvetica, sans-serif"
					 },		
					 closeBoxMargin: "11px 6px 0px 0px", 
					 closeBoxURL: "images/infoboxclose.png", 
					 //closeBoxURL: "http://www.google.com/intl/en_us/mapfiles/close.gif",
					 infoBoxClearance: new google.maps.Size(1, 1), 
					 isHidden: false, 
					 pane: "floatPane", 
					 enableEventPropagation: true
				});*/
				
				markers[k] = marker;
				infoBubbles[k] = infoBubble;
				
				//Marker Mouse events
				google.maps.event.addListener(markers[k], 'mouseover', function() {
					var zoomLevel = map.getZoom();
					infoBubbles[k].open(map, marker);

					if( zoomLevel <= 5 && markerFlag ) {						
						markers[k].setIcon("images/"+color+"_dot_large.png");
					}
				});

				google.maps.event.addListener(marker, 'mouseout', function() {
					var zoomLevel = map.getZoom();
					$.each(infoBubbles, function(ix, vx) {
						if(ix >= 0) {
							//console.log(infoBubbles[ix].getMap());
							//if(infoBubbles[ix].getMap()!=null || !infoBubbles[ix].getMap()!="undefined"){
								infoBubbles[ix].close();
							//}
						}
					});

					if( zoomLevel <= 5 && markerFlag ) {
						markers[k].setIcon("images/"+color+"_dot.png");
					}
				});			
				

				google.maps.event.addListener(marker, 'click', function() {
					var zoomLevel = map.getZoom();
					infoBubbles[k].open(map, marker);

					$.each(infoBubble1, function(ix, vx) {					
		
						if(ix > 0) {
							infoBubble1[ix].close();

						}
					});
					
					infoBubble1[k].open(map, marker);

					//console.log(map.getCenter())
					map.setCenterWithOffset(infoBubble1[k].getPosition(), 50, 200)
					if( zoomLevel <= 5 && markerFlag ) {						
						markers[k].setIcon("images/"+color+"_dot_large.png");
					}
					
					if( $.browser.msie && $.browser.version < 9 ) {
						if (window.PIE) {						
							setTimeout(function(){
								$(".popupinfobox,.mkrad,.box, .rad, .roundbot p").each(function() {
									PIE.attach(this);
								});
							}, 1000);
						}
					}
					//map.setCenter(marker.getPosition());
				});

				google.maps.event.addListener(map,'zoom_changed', function() {
					var zoomLevel = map.getZoom();
					if( zoomLevel > 5 && markerFlag ) {
						$.each(markers,function(i,j){
							//markers[i].setIcon(null);
							//console.log((markers[i].icon).split('_')[0].split('/')[1]);
							markers[i].setIcon("images/"+ (markers[i].icon).split('_')[0].split('/')[1] +"_pin_small.png");
						})
						markerFlag = false;						
					} else if( zoomLevel <= 5 && markerFlag == false){
						$.each(markers,function(i,j){
							//markers[i].setIcon(null);
							//console.log((markers[i].icon).split('_')[0].split('/')[1]);
							markers[i].setIcon("images/"+ (markers[i].icon).split('_')[0].split('/')[1] +"_dot.png");
						})
						$("a[rel="+lastPlotCategory+"]", $(".btn-category-map")).trigger("click");
						markerFlag = true;	
					}
				});

				google.maps.event.addListener(infoBubble1[k],'closeclick',function(){
				   $(".ui-autocomplete-input, input.tags").val("");
				});
			}
			}, 100)
		});
		
	},
	bindCitiesList: function(){	
		$("body").append( $("<div>").addClass("formatDummy") );
		$(".city-cob-webs, .cobweb-img-list, .chk-city-list-dd").empty();

		$.each(cityList, function(k,v){
			setTimeout(function(){
			$(".formatDummy").html(v.City);
			availableTags.push( { label: $(".formatDummy").html(), value: $(".formatDummy").html(), desc: k } );

			if(v.SelectionChoiceForComparison=="YES")
			{
				$(".chk-city-list-dd").append( $("<li>").html( '<input type="checkbox" class="chk-city-list-dd-sel" rel="'+k+'" data-category="'+v.Category+'"></input><span>'+v.City+'</span>' ) )
				$(".bind-city-list").append( $("<div>").addClass("checkbox-width1").html( "<input type='checkbox' class='city-chk-list-all city-chk-list"+k+"' rel='"+k+"' data-category='"+v.Category+"'></input><span>"+v.City+"</span>" ) );
			}

			if( (v.Cobweb).toLowerCase() != '' ) {
				$(".city-cob-webs").append( $("<div>").addClass("checkbox-width").html( "<input type='checkbox' class='city-chk-list-cobweb-all city-chk-cobweb-list"+k+"' rel='"+k+"'></input><span>"+v.City+"</span>" ) );

				$(".cobweb-img-list").append( $("<div>").addClass("thumbimg_titleimg").addClass("cobweb-image-cnt cobweb-image-cnt"+k).attr({ "rel": k }).hide().html(
					'<div class="country-title-closeimg-topwidth">'+
						'<div class="country">'+(v.City)+'</div>'+
						'<div class="closeimg">'+
							'<a href="javascript:;"><img src="images/zoom_1.png" width="17" height="17" alt="" class="Zoom-cobWebs" data-title="'+(v.City)+", "+(v.Status)+'" rel="'+(v.Cobweb)+'" /></a>'+
							'<a href="javascript:;" class="close-cob-web"><img src="images/close-inner.jpg" width="17" height="17" alt="" class="close" /></a>'+
						'</div>'+
					'</div>'+
					'<div class="country-title-closeimg-topwidth">'+
						'<div class="thumnail"><img src="images/cobwebs/'+v.Cobweb+'" width="184" height="114" alt="" /></div>'+
					'</div>' ) )
					
			}
			}, 75);
		})
		
		$(".formatDummy").remove();
		
	},
	setMarkers: function(category){	
		var marker;
		$.each(cityList, function(key, value){
			setTimeout(function(){
			var tmp	=	value.split(",");
			if( tmp[2] == category ) {} 
			else if( category == "" ) {}
			}, 50);
		})
	}
  };

  $.fn.citytool = function( method ) {
    // Method calling logic
    if ( methods[method] ) {
      return methods[ method ].apply( this, Array.prototype.slice.call( arguments, 1 ));
    } else if ( typeof method === 'object' || ! method ) {
      return methods.init.apply( this, arguments );
    } else {
      $.error( 'Method ' +  method + ' does not exist on jQuery.tooltip' );
    }
  };
})( jQuery );

$(document).ready(function(){
	// calls the init method
	
	$('body').citytool();
	
		/*
	$(".roundbot p").hover(function(){
		alert("hi");
	});

	if ($.browser.msie && $.browser.version <= 9.0) {
		$.getScript("script/PIE.js", function () {
			if (window.PIE) {
				alert("ie")
				$(".box").each(function () {
					PIE.attach(this);
				});
			}
		});
	}
	
	$(".popupinfobox").live("mouseenter", function(){
		if(!$(".cityname span").hasClass("alpha"))
			//console.log("has class");
			return false;
			$(".two img").show();
						$(".one img").show();
						
			
	});*/
	$("body").delegate(".Citygreyhead", "click", function(event){
		var par = $(this).parent();
		var that = $(this);
		var next = $(this).next();
		var e = par.children().filter(".active");
		if(that.hasClass("active")){
			event.preventDefault();
		}
		else{
			if(e.length > 0) {
				e.removeClass("active");
				e.next().slideUp("slow");
				that.addClass("active");
				next.slideDown("slow");
			}
			else {
				that.addClass("active");
				next.slideDown("slow");
			}
		}
	});
	$(".finfaccd img").live("mouseenter",function(){
		$(".finfaccd img:first").attr("src","images/magnifying-glass-blue-icon_50.png");
	
	  });
		   $(".finfaccd img").live("mouseleave",function(){
	    	$(".finfaccd img:first").attr("src","images/magnifying-glass-icon_50.png");
	
		   });
		   
	/*$("body").delegate(".Citygreyhead", "click", function(){
//			console.log($(".cityname span"));

		//if( !$(".alphal a").hasClass("active") && !$(".global a").hasClass("active") && !$(".cityname span").hasClass("alpha"))
		if(!$(".cityname span").hasClass("alpha"))
			//console.log("has class");
			return false;

var nextHelp = $(".cityname span").attr("class");


if(nextHelp.split(" ")[1] =="one")
		{
	
			$(".finfaccd").slideToggle("slow");
			$(".accord-cont").slideToggle("slow");
			$(".one").css("background-color","#343434");
	$(".two").css("background-color","#7F7F7F");
		}
		else
		{
	
			$(".accord-cont").slideToggle("slow");
						$(".finfaccd").slideToggle("slow");
						$(".one").css("background-color","#7F7F7F");
						$(".two").css("background-color","#343434");
	
		}

	});/*
			$(".one").live("mouseenter", function(){
				$(this).css("background-color","#2E75C1");
			});
			$(".two").live("mouseenter", function(){
				$(this).css("background-color","#2E75C1");
			});
			$(".one").live("mouseleave", function(){
				$(this).css("background-color","#7F7F7F");
			});
			$(".two").live("mouseleave", function(){
				$(this).css("background-color","#7F7F7F");
			});*/

	$(".citifinder").on("click", function(){
		var searchboxval = $("#searchBox").val();

		$.each(availableTags, function(key, value){
			
			if(value.label == searchboxval){
				$.each(infoBubble1, function(ix, vx) {
					//console.log(ix)
					infoBubble1[ix].close();
					/*if(ix > 0) {
						
					}*/
				});

				infoBubble1[value.desc].open(map, markers[value.desc]);
			}
		})

		/**/
	});
			
})