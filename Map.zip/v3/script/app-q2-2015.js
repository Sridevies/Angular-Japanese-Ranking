var map;
var plots = [],
    infoBubble1 = [],
    markers = [],
    availableTags = [],
    checkauto = 0;

(function($) {
    $.ajaxSetup({
        cache: true
    });

    var zind = 1000;
    var zind1 = 1000;
    var zind2 = 1000;

    var parent, lastPlotCategory = "",
        markerFlag = true,
		//indexLabelsRanksTotal = ['0', '300', '660', '133', '128'],
        infoBubbles = [],
        contentString, contentString1 = [],
        contentString2 = [],
        infoBubble, images = [{
            'Alpha': 'images/red_dot.png',
            'Gamma': 'images/green_dot.png',
            'Delta': 'images/orange_dot.png',
            'Beta': 'images/blue_dot.png',
            'NA': 'images/blue_dot.jpg'
        }],
        cityList, mapCanvas = jQuery('#map_canvas'),
        
        methods = {
            init: function(options) {
                parent = this;

                var styles = [{
                    featureType: 'landscape',
                    elementType: 'all',
                    stylers: [{
                        hue: '#D5D5D5'
                    }, {
                        saturation: -100
                    }, {
                        lightness: -6
                    }, {
                        visibility: 'simplified'
                    }]
                }, {
                    featureType: 'landscape.man_made',
                    elementType: 'all',
                    stylers: [{
                        hue: '#BDBDBD'
                    }, {
                        saturation: -100
                    }, {
                        lightness: -17
                    }, {
                        visibility: 'simplified'
                    }]
                }, {
                    featureType: 'road',
                    elementType: 'geometry',
                    stylers: [{
                        hue: '#D5D5D5'
                    }, {
                        saturation: -100
                    }, {
                        lightness: 54
                    }, {
                        visibility: 'on'
                    }]
                }, {
                    featureType: 'road.highway',
                    elementType: 'all',
                    stylers: [{
                        hue: '#AEAEAE'
                    }, {
                        saturation: -100
                    }, {
                        lightness: 12
                    }, {
                        visibility: 'on'
                    }]
                }, {
                    featureType: 'road.arterial',
                    elementType: 'all',
                    stylers: [{
                        hue: '#AEAEAE'
                    }, {
                        saturation: -100
                    }, {
                        lightness: -11
                    }, {
                        visibility: 'on'
                    }]
                }, {
                    featureType: 'road.local',
                    elementType: 'all',
                    stylers: [{
                        hue: '#AEAEAE'
                    }, {
                        saturation: -100
                    }, {
                        lightness: -32
                    }, {
                        visibility: 'on'
                    }]
                }, {
                    featureType: 'poi',
                    elementType: 'all',
                    stylers: [{
                        hue: '#BDBDBD'
                    }, {
                        saturation: -100
                    }, {
                        lightness: -5
                    }, {
                        visibility: 'simplified'
                    }]
                }];


                map = new google.maps.Map(jQuery('#map_canvas')[0], {
                    mapTypeControlOptions: {
                        mapTypeIds: ['Styled']
                    },
                    zoom: 3,
                    minZoom: 10,
                    styles: styles,
                    center: new google.maps.LatLng(26.3101221, 49.9658218),
                    mapTypeId: google.maps.MapTypeId.ROADMAP
                });

                $.ajax({
                    type: 'get',
                    async: false,
                    url: "data/data.js",
                    dataType: "json",
                    contentType: "application/json; charset=utf-8",
                    cache: false,
                    data: {},
                    success: function(json) {
                        //alert(JSON.stringify(json));
                        cityList = json;
                        cityList.sort(function(a, b) {
                            return [a.City] < [b.City] ? -1 : 1;
                        });
                        parent.citytool("renderMap");
                        parent.citytool("bindCitiesList");
                        parent.citytool("setCategoryChange");
                    },
                    error: function(XMLHttpRequest, status, error) {
                        alert(error);
                    }
                })
                setTimeout(function() {
                    $("input[type=checkbox]").removeAttr("checked");
                }, 500);
            },
            setCategoryChange: function() {

                $(".globalb").removeClass("active");
                $(".btn-category-map li").bind("click", function(e) {
                    e.preventDefault();
                    $(this).find("a").toggleClass("active");
                    var rel = $("a", this).attr("rel");
                    $.each(infoBubble1, function(ix, vx) {
                        //setTimeout(function(){
                        if (ix >= 0) {
                            infoBubble1[ix].close();
                        }
                        //}, 40)
                    });
                    //

                    for (i in markers) {
                        //setTimeout(function(){
                        markers[i].setVisible(false);
                        //}, 50)

                        /*markers[i].setMap(null);
                        console.log(markers[i].catogery); */
                    }

                    $(".ui-autocomplete-input").val("");

                    lastPlotCategory = rel;
                    //			

                    if (rel == "" || rel == undefined) {
                        //console.log("in else");
                        plots.splice(0, plots.length);
                        parent.citytool("renderMap", [rel]);
                        $(".btn-category-map li a").removeClass("active");
                        $(".globalb").addClass("active");
                    } else {

                        $(".globalb").removeClass("active");
                        if ($.inArray(rel, plots) == -1) {
                            //console.log("test");
                            plots.push(rel);
                            //console.log("If Statement Set Visible");

                        } else {
                            if (checkauto != 1) {
                                $(this).find("a").removeClass("active");
                                plots.splice($.inArray(rel, plots), 1);
                                //console.log("Else Statement Set Visible");
                            } else {
                                $(this).find("a").addClass("active");
                            }
                        }


                        $.each(plots, function(i) {
                            //console.log("plot value"+plots[i]);
                            setTimeout(function() {

                                    for (j in markers) {
                                        //setTimeout(function(){
                                        if (markers[j].catogery == plots[i]) {
                                            //parent.citytool("renderMap", [rel]);
                                            //markers[j].setMap(null);
                                            markers[j].setVisible(true);
                                            //console.log("Set Visible");

                                        }
                                        //}, 50)
                                        //console.log(markers[j].catogery); 
                                    }

                                }, 30)
                                //parent.citytool("renderMap", plots[i]);
                        });
                       
                    }
                    checkauto = 0;
                    // parent.citytool("renderMap", [rel])

                    parent.citytool("bindAutoComplete", [rel])
                })
                parent.citytool("bindAutoComplete", [""])

            },
           
            bindAutoComplete: function(category) {
                //console.log(plots);
                if (category != "") {
                    var tmp = [];
                    $("body").append($("<div>").addClass("formatDummy"));
                    $.each(cityList, function(k, v) {
                        //if( v.Category == category ) {
                        $(".formatDummy").html(v.City);
                        tmp.push({
                            label: $(".formatDummy").html(),
                            value: $(".formatDummy").html(),
                            desc: k
                        });
                        //}
                    })

                    $(".formatDummy").remove();
                    $(".tags").autocomplete("destroy")
                    availableTags = tmp;
                } else {
                    var tmp = [];
                    $("body").append($("<div>").addClass("formatDummy"));
                    $.each(cityList, function(k, v) {
                        $(".formatDummy").html(v.City);
                        tmp.push({
                            label: $(".formatDummy").html(),
                            value: $(".formatDummy").html(),
                            desc: k
                        });
                    })

                    $(".formatDummy").remove();
                    //$( ".tags" ).autocomplete("destroy")
                    availableTags = tmp;
                }

                if (availableTags.length < 100) {
                    $('.ui-autocomplete').css({
                        "": ""
                    });
                }

                $(".tags").autocomplete({
                    source: availableTags,
                    focus: function(event, ui) {
                        $(".tags").val(ui.item.label);
                        return false;
                    },
                    select: function(event, ui) {
                        $.each(cityList, function(i, v) {
                            if (v.City == ui.item.value) {
                                category = v.Category;
                            }
                        })
                        checkauto = 1;
                        $('a[rel=' + category + ']').parent().trigger("click");

                        //$(".btn-category-map li").trigger("click")
                        $.each(infoBubble1, function(ix, vx) {

                            if (ix >= 0) {
                                infoBubble1[ix].close();
                            }
                        });

                        infoBubble1[ui.item.desc].open(map, markers[ui.item.desc]);
                    }
                });

                $.ui.autocomplete.filter = function(array, term) {
                    var matcher = new RegExp("^" + $.ui.autocomplete.escapeRegex(term), "i");
                    return $.grep(array, function(value) {
                        return matcher.test(value.label || value.value || value);
                    });
                };
            },
            renderMap: function(category) {

                //console.log(category);
                var condFilter = "";

                if (category == "" || category == undefined) {
                    condFilter = "true";
                    //condFilter	=	"v.Category == 'Alpha'";
                } else {
                    condFilter = "v.Category == '" + category + "'";
                }

                google.maps.Map.prototype.setCenterWithOffset = function(latlng, offsetX, offsetY) {
                    var map = this;
                    var ov = new google.maps.OverlayView();
                    ov.onAdd = function() {
                        var proj = this.getProjection();
                        var aPoint = proj.fromLatLngToContainerPixel(latlng);
                        aPoint.x = aPoint.x + offsetX;
                        aPoint.y = aPoint.y + offsetY;
                        map.panTo(proj.fromContainerPixelToLatLng(aPoint));
                    };
                    ov.draw = function() {};
                    ov.setMap(this);
                };

                $.each(cityList, function(k, v) {

                    setTimeout(function() {
                        if (eval(condFilter)) {

                            var color = "";
                            if ((v.Category).toLowerCase() == "alpha") {
                                if ((v.Status).toLowerCase() == "completed") {
                                    color = "green";
                                } else {
                                    color = "greenin";
                                }
                            } else if ((v.Category).toLowerCase() == "beta") {
                                if ((v.Status).toLowerCase() == "completed") {
                                    color = "blue";
                                } else {
                                    color = "bluein";
                                }
                            } else if ((v.Category).toLowerCase() == "gamma") {
                                if ((v.Status).toLowerCase() == "completed") {
                                    color = "red";
                                } else {
                                    color = "redin";
                                }
                            } else if ((v.Category).toLowerCase() == "delta") {
                                if ((v.Status).toLowerCase() == "completed") {
                                    color = "orange";
                                } else {
                                    color = "orangein";
                                }
                            }
                            var zoomLevel = map.getZoom();


                            var tmpImg = "images/" + color + "_dot.png";

                            if (zoomLevel > 5) {
                                tmpImg = "images/" + color + "_pin_small.png";
                            }

                            function hideMarkers() {
                                //Loop through all the markers and remove
                                for (var i = 0; i < markers.length; i++) {
                                    markers[i].setMap(null);
                                }
                                markers = [];
                            };

                            var marker = new google.maps.Marker({
                                position: new google.maps.LatLng(v.lattitude, v.longitude),
                                map: map,

                                optimized: false,
                                suppressMarkers: true,
                                catogery: v.Category,
                                icon: tmpImg
                            });
                            //markers[i].setVisible(false);
                            contentString = "<div class='tooltip " + (v.Category).toLowerCase() + " tool'><img src='images/tooltip-down-arrow_" + color + ".png' class='callout' />" + (v.City) + "</div></div>";
                            contentString2[k] = "";
                            if (v.City == "San Jose,USA" || v.City == "San Jose, Costa Rica" || v.City == "Hyderabad, India" || v.City == "Hyderabad, Pakistan") {
                                contentString1[k] = '<div class="cityname box ' + (v.Category).toLowerCase() + '"><span class="' + (v.Category).toLowerCase() + '"><b>' + (v.City) + '</b></span></div>' +
                                    '<div class="citydetails" style="overflow:hidden;">';
                            } else {

                                contentString1[k] = '<div class="cityname box ' + (v.Category).toLowerCase() + '"><span class="' + (v.Category).toLowerCase() + '"><b style="font-size: 14px;">' + (v.City) + '</b></span></div>' +
                                    '<div class="citydetails" style="overflow:hidden;">';
                            }



                            if ((v.Category).toLowerCase() == "alpha" && v.Cobweb && v.Cobweb != undefined && (v.Cobweb).toLowerCase() != "") {
                                contentString1[k] += '<div class="Citygreyhead one ' + (v.Category).toLowerCase() + 'img" style="overflow:hidden;font-size: 14px;line-height: 2.6;padding-left: 37px;"><span class="pullLeft">Charting City Competitiveness</span><img src="images/arrow-bottom_white_6.png" style="float: right; margin-top: 15px;" /></div>' +
                                    '<a href="javascript:;" class="city-cobweb-img finfaccd"  style="position:relative;" rel="' + v.Cobweb + '" data-title="' + (v.Status) + '" data-id="' + k + '"><IMG SRC="images/magnifying-glass-icon_50.png" class="testimg" width="50px" height="50px" BORDER="0" ALT="Zoom" style="position:absolute; top:127px;z-index: 200; left:192px; "><img src="images/cobwebs/large/q2-2015/' + v.Cobweb + '" width="430" alt="" border="0" style="position:relative" /></a>';
                                //'<div class="Cityhead '+(v.Category).toLowerCase()+'" style="overflow:hidden;line-height: 2.6;padding-left: 37px;"><a href="javascript:;" class="city-cobweb-map smCnt" rel="'+k+'"><img src="images/whitearrow.png" alt="" border="0">Compare cities (top 30)</a></div>';

                            }

                            contentString1[k] +=
                                '<div class="citydata ' + (v.Category).toLowerCase() + 'cont accord-cont">' +
                                '<table cellspacing="0" cellpadding="5" border="0" width="100%">';
                            contentString1[k] += '<tr>' +
                                '<td class="indextxt1"><span><strong style="font-size: 14px;">Status</strong></span></td>' + '<td class="rank" nowrap><b style="font-size: 14px; float:right;">' + (v.Status) + '</b></td>' +
                                '</tr>';
                       

                            contentString1[k] += contentString2[k];
                            contentString1[k] += '</table>' + '</div>';

                            if ((v.Category).toLowerCase() == "alpha") {
                                contentString1[k] += '<div class="Cityhead ' + (v.Category).toLowerCase() + '"  style="overflow:hidden;display: none;line-height: 2.6;padding-left: 37px;">';
                                contentString1[k] += '<img src="images/whitearrow.png" alt="" border="0">' + (v.City) + ' Paragraph';
                                contentString1[k] += '</div><div class="' + (v.Category).toLowerCase() + 'cont" style="display: none;padding:10px 10px 10px 10px">' + (v.City) + ' paragraph contents will come here.</div>';
                            }

                            if (v.BusinessLink != "" && v.BusinessLink != undefined) {
                                contentString1[k] += '<li><p><a href="' + v.BusinessLink + '" color="#2E75C1" target="_blank">Our Real Estate services in this market</a></p></li>';
                            }
                            contentString1[k] += '</ul>' +
                                '</div>' +
                                '</div>';
                            zind++;
                            //console.log(zind);
                            // Creating / Initiating Infobox					
                            infoBubble = new InfoBox({
                                content: contentString, // Tab content gets appended here
                                disableAutoPan: true,
                                maxWidth: 0,
                                pixelOffset: new google.maps.Size(0, -55),
                                zIndex: zind,
                                boxClass: 'tooltiph',
                                boxStyle: {
                                    //background: "url('tipbox.gif') no-repeat", 
                                    opacity: 1,
                                    width: "300px"
                                },
                                closeBoxURL: "",
                                infoBoxClearance: new google.maps.Size(1, 1),
                                isHidden: false,
                                pane: "floatPane",
                                enableEventPropagation: true
                            });
                            //console.log(infoBubble1[k]);
                            zind1 = zind1 + zind;
                            

                            markers[k] = marker;
                            infoBubbles[k] = infoBubble;

                            //Marker Mouse events
                            google.maps.event.addListener(markers[k], 'mouseover', function() {
                                var zoomLevel = map.getZoom();
                                infoBubbles[k].open(map, marker);

                                if (zoomLevel <= 5 && markerFlag) {
                                    markers[k].setIcon("images/" + color + "_dot_large.png");
                                }
                            });

                            google.maps.event.addListener(marker, 'mouseout', function() {
                                var zoomLevel = map.getZoom();
                                $.each(infoBubbles, function(ix, vx) {
                                    if (ix >= 0) {
                                        //console.log(infoBubbles[ix].getMap());
                                        //if(infoBubbles[ix].getMap()!=null || !infoBubbles[ix].getMap()!="undefined"){
                                        infoBubbles[ix].close();
                                        //}
                                    }
                                });

                                if (zoomLevel <= 5 && markerFlag) {
                                    markers[k].setIcon("images/" + color + "_dot.png");
                                }
                            });


                            google.maps.event.addListener(marker, 'click', function() {
                                var zoomLevel = map.getZoom();
                                infoBubbles[k].open(map, marker);

                                $.each(infoBubble1, function(ix, vx) {

                                    if (ix > 0) {
                                        infoBubble1[ix].close();

                                    }
                                });

                                infoBubble1[k].open(map, marker);

                                //console.log(map.getCenter())
                                map.setCenterWithOffset(infoBubble1[k].getPosition(), 50, 200)
                                if (zoomLevel <= 5 && markerFlag) {
                                    markers[k].setIcon("images/" + color + "_dot_large.png");
                                }

                                if ($.browser.msie && $.browser.version < 9) {
                                    if (window.PIE) {
                                        setTimeout(function() {
                                            $(".popupinfobox,.mkrad,.box, .rad, .roundbot p").each(function() {
                                                PIE.attach(this);
                                            });
                                        }, 1000);
                                    }
                                }
                                //map.setCenter(marker.getPosition());
                            });

                            google.maps.event.addListener(map, 'zoom_changed', function() {
                                var zoomLevel = map.getZoom();
                                if (zoomLevel > 5 && markerFlag) {
                                    $.each(markers, function(i, j) {
                                        //markers[i].setIcon(null);
                                        //console.log((markers[i].icon).split('_')[0].split('/')[1]);
                                        markers[i].setIcon("images/" + (markers[i].icon).split('_')[0].split('/')[1] + "_pin_small.png");
                                    })
                                    markerFlag = false;
                                } else if (zoomLevel <= 5 && markerFlag == false) {
                                    $.each(markers, function(i, j) {
                                        //markers[i].setIcon(null);
                                        //console.log((markers[i].icon).split('_')[0].split('/')[1]);
                                        markers[i].setIcon("images/" + (markers[i].icon).split('_')[0].split('/')[1] + "_dot.png");
                                    })
                                    $("a[rel=" + lastPlotCategory + "]", $(".btn-category-map")).trigger("click");
                                    markerFlag = true;
                                }
                            });

                            google.maps.event.addListener(infoBubble1[k], 'closeclick', function() {
                                $(".ui-autocomplete-input, input.tags").val("");
                            });
                        }
                    }, 100)
                });

            },
            bindCitiesList: function() {
                $("body").append($("<div>").addClass("formatDummy"));
                $(".city-cob-webs, .cobweb-img-list, .chk-city-list-dd").empty();

                $.each(cityList, function(k, v) {
                    setTimeout(function() {
                        $(".formatDummy").html(v.City);
                        availableTags.push({
                            label: $(".formatDummy").html(),
                            value: $(".formatDummy").html(),
                            desc: k
                        });
						
                        if (v.SelectionChoiceForComparison == "YES") {
                            $(".chk-city-list-dd").append($("<li>").html('<input type="checkbox" class="chk-city-list-dd-sel" rel="' + k + '" data-category="' + v.Category + '"></input><span>' + v.City + '</span>'))
                            $(".bind-city-list").append($("<div>").addClass("checkbox-width1").html("<input type='checkbox' class='city-chk-list-all city-chk-list" + k + "' rel='" + k + "' data-category='" + v.Category + "'></input><span>" + v.City + "</span>"));
                        }

                        if ((v.Cobweb).toLowerCase() != '') {
                            $(".city-cob-webs").append($("<div>").addClass("checkbox-width").html("<input type='checkbox' class='city-chk-list-cobweb-all city-chk-cobweb-list" + k + "' rel='" + k + "'></input><span>" + v.City + "</span>"));

                            $(".cobweb-img-list").append($("<div>").addClass("thumbimg_titleimg").addClass("cobweb-image-cnt cobweb-image-cnt" + k).attr({
                                "rel": k
                            }).hide().html(
                                '<div class="country-title-closeimg-topwidth">' +
                                '<div class="country">' + (v.City) + '</div>' +
                                '<div class="closeimg">' +
                                '<a href="javascript:;"><img src="images/zoom_1.png" width="17" height="17" alt="" class="Zoom-cobWebs" data-title="' + (v.City) + ", " + (v.Status) + '" rel="' + (v.Cobweb) + '" /></a>' +
                                '<a href="javascript:;" class="close-cob-web"><img src="images/close-inner.jpg" width="17" height="17" alt="" class="close" /></a>' +
                                '</div>' +
                                '</div>' +
                                '<div class="country-title-closeimg-topwidth">' +
                                '<div class="thumnail"><img src="images/cobwebs/' + v.Cobweb + '" width="184" height="114" alt="" /></div>' +
                                '</div>'))

                        }
                    }, 75);
                })

                $(".formatDummy").remove();

            },
            setMarkers: function(category) {
                var marker;
                $.each(cityList, function(key, value) {
                    setTimeout(function() {
                        var tmp = value.split(",");
                        if (tmp[2] == category) {} else if (category == "") {}
                    }, 50);
                })
            }
        };

    $.fn.citytool = function(method) {
        // Method calling logic
        if (methods[method]) {
            return methods[method].apply(this, Array.prototype.slice.call(arguments, 1));
        } else if (typeof method === 'object' || !method) {
            return methods.init.apply(this, arguments);
        } else {
            $.error('Method ' + method + ' does not exist on jQuery.tooltip');
        }
    };
})(jQuery);

$(document).ready(function() {
    // calls the init method

    $('body').citytool();
   
})