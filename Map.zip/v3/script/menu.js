	$(document).ready(function() {
		$(".sunburst").hover(function(){
			$(".sunburst_con").show();},function(){
			$(".sunburst_con").hide();
		
		})
		$(".bubble").hover(function(){
			$(".bubble_con").show();},function(){
			$(".bubble_con").hide();
		
		})
		$(".bar").hover(function(){
			$(".bar_con").show();},function(){
			$(".bar_con").hide();
		
		})
		$(".cobweb").hover(function(){
			$(".cobweb_con").show();},function(){
			$(".cobweb_con").hide();
		
		})
		$(".map").hover(function(){
			$(".map_con").show();},function(){
			$(".map_con").hide();
		
		})
		$(".home").hover(function(){
			$(".home_con").show();},function(){
			$(".home_con").hide();
		
		})
	});