$(window).load(function() {
	setTimeout(function(){
		$("body").css({"overflow":"auto"}); 
		$(".loadingbg").fadeOut(600);
		$(".loading").fadeOut(600);
		$(".search-loadImg").fadeOut();	
		$(".search-overlay").fadeOut();
		new WOW().init();
	},5000);

	setTimeout(function(){
		gridLayout();
		$('.slick-slider .slides').slick({
			//dots: true,
			prevArrow: false,
			nextArrow: false,
			dots: true,
			infinite: false,
			speed: 300,
			slidesToShow: 1,
			slidesToScroll: 1
		});
		//==================For search details page==========
		$(".left-box-2 ul li, .imageHolder").click(function(){
			var thisImgSrc = $(this).find("img").attr("src") 
			$(".overlay-light-box").fadeIn();
			$(".light-box").find("img").attr("src",thisImgSrc);
			$(".light-box").fadeIn().addClass("light-box-animation");
		});	

		$(".closeBt, .overlay-light-box").click(function(){
			
			$(".light-box").removeClass("light-box-animation").fadeOut();
			$(".overlay-light-box").delay(200).fadeOut();
		});

		$("#HEnScroll").enscroll({
			horizontalScrolling: true,
			horizontalTrackClass: 'horizontal-track2',
			horizontalHandleClass: 'horizontal-handle2'
		});

		/*$(".searchClikFn").click(function(){
			$("html,body").animate({"scrollTop":0},500,function(){
				$(".search-result").css({"z-index":2});
				$(".header-SR").css({"z-index":0});
				$(".personalList, .searchContent").fadeOut().addClass("searhAnimation");		
				$(".searchContent, .personalList").fadeOut();		
				$(".searchDetail").fadeIn().addClass("repoartAnimation");
				$("a.back2search").fadeIn();
			});

			
		});*/

		$(".back2search").click(function(){
			$(".searchDetail").fadeOut().removeClass("repoartAnimation");
			$(".personalList, .searchContent").fadeIn().removeClass("searhAnimation");
			$(this).fadeOut();
			setTimeout (function(){
			$(".search-result").css({"z-index":1});
			$(".header-SR").css({"z-index":2});
			},1000);
			$('.slick-slider .slides').slick({
				prevArrow: false,
				nextArrow: false,
				dots: true,
				infinite: false,
				speed: 300,
				slidesToShow: 1,
				slidesToScroll: 1
			});	
		});	
	},5000)
	function gridLayout(){
		var $win = $(window),
		isoContainer = $('.grid').isotope(),
		contentBox = $(".gutter-sizer");
		isoContainer.isotope({
			itemSelector: '.grid-item',
			//layoutMode: 'fitRows',
			masonry: {
				columnWidth: 100
			}
		});	   
		isoContainer.isotope({
			itemSelector: '.grid-item',
			//layoutMode: 'fitRows',
			masonry: {
				columnWidth: 100
			}
		});
		$(window).smartresize(function(){
			var winWidth = $(window).width();
			isoContainer.isotope({
				itemSelector: '.grid-item',
				//layoutMode: 'fitRows',
				masonry: {
					columnWidth: 100
				}
			});
			$(document).resize();
		});		 
	}
	$('#RFscrollbar,#SLscrollbar,#DSscrollbar,#ANscrollbar').enscroll({
		horizontalScrolling: true,
		verticalTrackClass: 'vertical-track2',
		verticalHandleClass: 'vertical-handle2',
	});


});
$(document).ready(function(){	

	//alert();
	$("select.select-box option").hover(function(){
		$(this).css({"background-color":"red"});
	});
	/*  */
	$(".sort-Menu a").on("click",function(event){
		event.stopPropagation();
		$("ul.dropDown").stop().slideToggle(300);
	});
	/*
	$("ul.dropDown li").click(function(){
		var thisVal = $(this).text();
		//console.log(thisVal);
		$(".sort-Menu a .selectText").text(" ").text(thisVal);
		$(this).parent("ul").slideUp();
	});*/

	$(".nicescroll-rails").find("div").hide();
	$(document).click(function (e){
		var container = $("ul.dropDown");
		var containerSearch = $(".dropdown");
		var searchSelectBox = $(".dd-val").find(".bgm");
		var searchSelectArrow = $(".dd-val").find(".down-arrow");
		if (!container.is(e.target) && container.has(e.target).length === 0 || !containerSearch.is(e.target) && containerSearch.has(e.target).length === 0 || !searchSelectBox.is(e.target) && searchSelectBox.has(e.target).length === 0 || !searchSelectArrow.is(e.target) && searchSelectArrow.has(e.target).length === 0){
			//$(".nicescroll-rails").hide();
			searchSelectBox.removeClass("drop-active");
			searchSelectArrow.removeClass("drop-active-arrow");
			container.slideUp();
			containerSearch.slideUp();
			containerSearch.removeClass("active-drop");	
		};	
		$(".dd-box").slideUp();
	});
		
	$(".personalList .clickFn .dd-val").click(function(event){
		$('#RFscrollbar,#SLscrollbar,#DSscrollbar,#ANscrollbar').scrollTop(0);
		event.stopPropagation();
		$(".dropdown").slideUp();
		$(".bgm").removeClass("drop-active");
		$(".down-arrow").removeClass("drop-active-arrow");

		$(this).next(".dropdown").toggleClass("active-drop");
		$(this).find(".bgm").addClass("drop-active");
		$(this).find(".down-arrow").addClass("drop-active-arrow");
		$(this).next(".dropdown").stop().slideToggle(); 
		if(!$(this).next(".dropdown").hasClass("active-drop")){
			
			$(this).find(".bgm").removeClass("drop-active");
			$(this).next(".dropdown").removeClass("active-drop");
			$(this).find(".down-arrow").removeClass("drop-active-arrow");
		}else {
			$(this).find(".bgm").addClass("drop-active");
		} 
		if ($(this).parent("div").hasClass("dd-report-format")){ 
			$(".dd-service-line").find(".dropdown").removeClass("active-drop");
			$(".dd-data-source").find(".dropdown").removeClass("active-drop");
			$(".dd-account-name").find(".dropdown").removeClass("active-drop");

		}else if ($(this).parent("div").hasClass("dd-service-line")){			
			$(".dd-report-format").find(".dropdown").removeClass("active-drop");
			$(".dd-data-source").find(".dropdown").removeClass("active-drop");
			$(".dd-account-name").find(".dropdown").removeClass("active-drop");
		
		}else if ($(this).parent("div").hasClass("dd-data-source")){
			$(".dd-report-format").find(".dropdown").removeClass("active-drop");
			$(".dd-service-line").find(".dropdown").removeClass("active-drop");
			$(".dd-account-name").find(".dropdown").removeClass("active-drop");

		}else if ($(this).parent("div").hasClass("dd-account-name")){
			$(".dd-report-format").find(".dropdown").removeClass("active-drop");
			$(".dd-service-line").find(".dropdown").removeClass("active-drop");
			$(".dd-data-source").find(".dropdown").removeClass("active-drop");
		}
	});

	setTimeout(function(){
		$(".dropdown ul li").click(function(){
			var thisText =  $(this).text();
			$(this).closest(".clickFn").find("p").text(thisText);
			$(this).closest(".clickFn").find("p").attr("title",thisText);
			$(this).parent("ul").find("li").removeClass("dropdown-active");
			$(this).addClass("dropdown-active");
			$(this).parent("ul").parent("div").parent("div").find(".bgm").removeClass("drop-active");
			$(this).parent("ul").parent("div").parent("div").find(".down-arrow").removeClass("drop-active-arrow");
			$(this).parent("ul").parent("div").removeClass("active-drop");
			$(this).find(".down-arrow").removeClass("drop-active-arrow");	
			$(".dropdown").slideUp();
			
		});
		$(".location-nav .dd-box li:eq(0)").css({"color":"#d62e2d"});
		$(".location-nav .dd-box li").click(function(){
			$(".location-nav .dd-box li").css({"color":"#414143"});
			var LocationName = $(this).text();
			$(this).css({"color":"#d62e2d"});
			$(".location-nav h4 span").text(LocationName);
		});
	},3000);
	/**/
	
	/*
	var reportListWidth = 0;
	$(".left-box-2 ul li").each(function(){
		reportListWidth = reportListWidth + $(this).outerWidth()+10;		
	});
	*/

	

	$(".like-bt").click(function(){
		$(this).find("span").toggleClass("like-acive");
	});

	$(".searchClikFn").click(function(){
		$(".searchContent").css({"transform":"scale(0.80)"},function(){
			$(".searchContent").fadeOut(1000);
		});	
		//$(".personalList").hide();	
	});
	
});