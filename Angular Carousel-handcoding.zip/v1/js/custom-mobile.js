(function () {

    var app = angular.module('clock-app', ['swipe']);

////// Double Tab //////
hmGestures = ['hmHold:hold',
                  'hmTap:tap',
                  'hmDoubletap:doubletap',
                  'hmDrag:drag',
                  'hmDragstart:dragstart',
                  'hmDragend:dragend',
                  'hmDragup:dragup',
                  'hmDragdown:dragdown',
                  'hmDragleft:dragleft',
                  'hmDragright:dragright',
                  'hmSwipe:swipe',
                  'hmSwipeup:swipeup',
                  'hmSwipedown:swipedown',
                  'hmSwipeleft:swipeleft',
                  'hmSwiperight:swiperight',
                  'hmTransformstart:transformstart',
                  'hmTransform:transform',
                  'hmTransformend:transformend',
                  'hmRotate:rotate',
                  'hmPinch:pinch',
                  'hmPinchin:pinchin',
                  'hmPinchout:pinchout',
                  'hmTouch:touch',
                  'hmRelease:release'];

angular.forEach(hmGestures, function(name){
  var directive = name.split(':'),
  directiveName = directive[0],
  eventName = directive[1];
  app.directive(directiveName, ["$parse", function($parse) {
    return {
      scope: true,
      link: function(scope, element, attr) {
        var fn, opts;
        fn = $parse(attr[directiveName]);
        opts = $parse(attr["hmOptions"])(scope, {});
        if(opts && opts.group) {
          scope.hammer = scope.hammer || Hammer(element[0], opts);
        } else {
          scope.hammer = Hammer(element[0], opts);
        }
        return scope.hammer.on(eventName, function(event) {
          return scope.$apply(function() {
            return fn(scope, {
              $event: event
            });
          });
        });
      }
    };
    }
  ]);
});
    

app.controller('clock-tab-controller', function ($scope, $window, $http, $timeout) {
		$scope.selectedImg="/germany/de-de/PublishingImages/risikowippe-deutsche-buroimmobilienuhr/clock-top_left.png";
		$scope.activeQuad = 0;
		$scope.agentWidth = $window.innerWidth;
		$scope.Lightbox = true;

		if($scope.agentWidth >= 768)
		{
			$scope.selectedCity = "München";
		}else{
			$scope.selectedCity = "Select a City";
		}
		var dynImg = ['/germany/de-de/PublishingImages/risikowippe-deutsche-buroimmobilienuhr/clock-top_full.png', '/germany/de-de/PublishingImages/risikowippe-deutsche-buroimmobilienuhr/clock-top_right.png', '/germany/de-de/PublishingImages/risikowippe-deutsche-buroimmobilienuhr/clock-right_full.png', '/germany/de-de/PublishingImages/risikowippe-deutsche-buroimmobilienuhr/clock-btm_right.png', '/germany/de-de/PublishingImages/risikowippe-deutsche-buroimmobilienuhr/clock-btm_full.png', '/germany/de-de/PublishingImages/risikowippe-deutsche-buroimmobilienuhr/clock-btm_left.png', '/germany/de-de/PublishingImages/risikowippe-deutsche-buroimmobilienuhr/clock-left_full.png', '/germany/de-de/PublishingImages/risikowippe-deutsche-buroimmobilienuhr/clock-top_left.png'];
	
		/////////// Tab /////////
        this.tab = 1;
        this.setTab = function (tabId) {
            this.tab = tabId;
        };

        this.isSet = function (tabId) {
            return this.tab === tabId;
        };

		////////// CSV //////////
		$scope.readCSV = function() {
		// http get request to read CSV file content
			$http.get('/germany/de-de/Documents/risikowippe-deutsche-buroimmobilienuhr/clock-redesign/data/clock-data-q2_2016.csv').success($scope.processData);
			$http.get('data/clock-data-q2_2016.csv').success($scope.processData);
		};

		$scope.processData = function(allText) {
			// split content based on new line
			var allTextLines = allText.split(/\r\n|\n/);
			var headers = allTextLines[0].split(',');
			headers.push("Rent1","Rent2");
			var lines = [];
			for ( var i = 1; i < allTextLines.length-1; i++) {
				// split content based on comma
				var clockData = allTextLines[i].split(',');
				
					var tarr = {};
					for ( var j = 0; j < clockData.length; j++) {
					
						tarr[headers[j]]=clockData[j].replace(/\"/g,"");						
					}
					lines.push(tarr);
			}
			$scope.clockData = lines;
		};

			//////// Sorting /////////
		
	$scope.sortData=function(column){
		if($scope.activecolumn == column){
			$scope.sort=$scope.sort == 'ASC' ? 'DSC' : 'ASC';
		}else{
			$scope.activecolumn=column;
			$scope.sort='ASC'
		}
		var unsorted=[];
		var tmpsorted=[];
		var sorted=[];
		angular.forEach($scope.clockData,function(d,i){
			
			if(column != 'City'){
				unsorted.push(parseFloat(d[column]))
			}else{
				unsorted.push(d[column])
			}				
		})
		tmpsorted=unsorted.slice(0,unsorted.length);
		if(column != 'City'){
		
			$scope.sort == 'ASC' ? tmpsorted.sort(function(a,b){return a-b}) : tmpsorted.sort(function(a,b){return b-a})
			
		}else{
			tmpsorted.sort();
			if($scope.sort != 'ASC'){tmpsorted.reverse()};
		}
		
		angular.forEach(tmpsorted,function(l,k){
			sorted.push($scope.clockData[unsorted.indexOf(l)]);
		})	
		$scope.clockData=sorted;
	}
	

	$scope.setIcon=function(ctext){
		if(ctext == $scope.activecolumn)
		{
			return $scope.sort == 'ASC' ? 'glyphiconAsc' : 'glyphiconDesc' ;
		}
		return 'glyphiconArrow';
	}

	///////Get City Click Function //////////
	$scope.getCity = function(id,time){
			$scope.selectedCity = id;
			var Ntime=parseInt(time.split(":").join(""));
			
			if(Ntime == 1200)
			{
				$scope.selectedImg = dynImg[0];
				$scope.setQuadClock(1);
			}
			else if(Ntime == 300)
			{
				$scope.selectedImg = dynImg[2];
				$scope.setQuadClock(2);
			
			}else if(Ntime > 300 && Ntime < 600)
			{
				$scope.selectedImg = dynImg[3];
				$scope.setQuadClock(4);
			
			}else if(Ntime == 600)
			{
				$scope.selectedImg = dynImg[4];
				$scope.setQuadClock(3);
			}
			else if(Ntime > 600 && Ntime < 899)
			{
				$scope.selectedImg = dynImg[5];
				$scope.setQuadClock(3);
			}else if(Ntime == 900)
			{
				$scope.selectedImg = dynImg[6];
				$scope.setQuadClock(1);
			}else if(Ntime > 900 && Ntime < 1200)
			{
				$scope.selectedImg = dynImg[7];
				$scope.setQuadClock(1);
			}else
			{
				$scope.selectedImg = dynImg[1];
			}
		
	};

	/////////// Changeclock ///////////
	$scope.Changeclock=function(){
		if($scope.selectedCity != 'Select a City'){
			angular.forEach($scope.clockData,function(data,index){
				if(data.City == $scope.selectedCity){
					$scope.getCity($scope.selectedCity,data['2016 Q2'])
				}
			})
		}else{
			$scope.hideMobClock = false;
		}
	}

	////////// overlay //////////
	$scope.hidePopup = false;
	$scope.overlay=function(){ 
		$scope.hidePopup = !$scope.hidePopup;
	}

    //////// setQuadClock for Mobile ///////
	if ($scope.agentWidth >= 768) {
	    $scope.hideMobClock = true;
	} else {
	    $scope.hideMobClock = false;
	}
	
	$scope.setQuadClock = function(data){
		
	    if ($scope.agentWidth < 768) { 
	        $scope.activeQuad = data;
	        $scope.hideMobClock = true;
	        $('.tabShow').show();

	        if (data == 1) {
	            $('.mobQuad').animate({ 'top': '-40px', 'left': '23px' }, 300);
	            $scope.selectedImg = dynImg[7];
	        }
	        if (data == 2) {
	            $('.mobQuad').animate({ 'top': '-36px', 'left': '-255px' }, 300);
	            $scope.selectedImg = dynImg[1];
	        }
	        if (data == 3) {
	            $('.mobQuad').animate({ 'top': '-255px', 'left': '23px' }, 300);
	            $scope.selectedImg = dynImg[5];
	        }
	        if (data == 4) {
	            $('.mobQuad').animate({ 'top': '-255px', 'left': '-255px' }, 300);
	            $scope.selectedImg = dynImg[3];
	        }
	    }
	 }

	$scope.changeQuad=function(dir){
		
		if(dir <= 2) /* left right*/
		{
			if($scope.activeQuad == 1 && dir == 1)
			{
				$scope.setQuadClock(2);
			}else if($scope.activeQuad == 2 && dir == 2){
				$scope.setQuadClock(1);
			}else if($scope.activeQuad == 3 && dir == 1){
				$scope.setQuadClock(4);
			}else if($scope.activeQuad == 4 && dir == 2){
				$scope.setQuadClock(3);
			}
			
		}else{ /* top bottom*/
		
			if($scope.activeQuad == 1 && dir == 4)
			{
				$scope.setQuadClock(3);
			}else if($scope.activeQuad == 3 && dir == 3){
				$scope.setQuadClock(1);
			}else if($scope.activeQuad == 2 && dir == 4){
				$scope.setQuadClock(4);
			}else if($scope.activeQuad == 4 && dir == 3){
				$scope.setQuadClock(2);
			}
		}
	}
	$scope.showClock=function()
	{
		if ($scope.agentWidth < 768) {
			$scope.hideMobClock =false;
			$scope.selectedCity = "Select a City";
		}
	}
	
	  var w = angular.element($window);
  
	  w.bind('resize', function () {
	      
	      $timeout(function () {
	       var prevW=$scope.agentWidth;
	         $scope.agentWidth = $window.innerWidth;
	         if ($scope.agentWidth >= 768) {
	     		    if(prevW < 768){
			    	    $scope.hideMobClock = true;
			   		    $scope.selectedCity = "München";
			        }
			    } else {
				    if(prevW >= 768){
			    	    $scope.hideMobClock = false;
			    	    $scope.selectedCity = "Select a City";
			        }
			    }
	         $scope.$apply();
	      }, 500)
	  });
	  w.bind('orientationchange', function () {  });

	  ////////// expandContent/ ////////
	  $scope.showContent = true;
	  $scope.showText = '(weniger)';
		$scope.expandContent = function(){
			$scope.showText = '(mehr)';
			 $scope.showContent = ! $scope.showContent;
		}

	////// PopUp //////////
	$scope.Lightbox = true;
	
	$scope.popUp = function(index){
		$scope.lBox = index;
		$scope.Lightbox =! $scope.Lightbox;
	}


	
    });


    
})();