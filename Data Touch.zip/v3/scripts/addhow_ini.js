<script type="text/javascript">
	var addToHomeConfig ={
		animationIn: 'bubble',
		animationOut: 'drop', 
		lifespan:10000, 
		expire:60, 
		touchIcon:true
	}
</script>