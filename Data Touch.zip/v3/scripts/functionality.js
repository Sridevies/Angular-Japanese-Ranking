var officeArray = new Array(), retailArray = new Array(), residentialArray = new Array(), industrialArray = new Array(), hotelArray = new Array()
var hash	=	window.location.hash.replace("#", "");
//debugger();

function addCommas(nStr)
{
	nStr += '';
	x = nStr.split('.');
	x1 = x[0];
	x2 = x.length > 1 ? '.' + x[1] : '';
	var rgx = /(\d+)(\d{3})/;
	while (rgx.test(x1)) {
		x1 = x1.replace(rgx, '$1' + ',' + '$2');
	}
	return x1 + x2;
}
if((navigator.userAgent.toLowerCase().indexOf('iphone')>0) || (navigator.userAgent.toLowerCase().indexOf('android')>0))	
{
	hideAddressBar();
	function hideAddressBar(){
		if(document.documentElement.scrollHeight<window.outerHeight/window.devicePixelRatio)
		document.documentElement.style.height=(window.outerHeight/window.devicePixelRatio)+'px';
		setTimeout(window.scrollTo(1,1),0);
	}
}
function returmColorCodeClass(clrTxt){
	switch(clrTxt) {
		case "up_red":
			clrCode	=	"arrowUp_Red";
		break;

		case "down_red":
			clrCode	=	"arrowDown_Red";
		break;

		case "both_red":
			clrCode	=	"arrowBoth_Red";
		break;

		case "up_green":
			clrCode	=	"arrowUp_Green";
		break;			

		case "down_green":
			clrCode	=	"arrowDown_Green";
		break;

		case "both_green":
			clrCode	=	"arrowBoth_Green";
		break;

		case "up_black":
			clrCode	=	"arrowUp_Black";
		break;			

		case "down_black":
			clrCode	=	"arrowDown_Black";
		break;

		case "both_black":
			clrCode	=	"arrowBoth_Black";
		break;

		default: 
			clrCode = "";
		break;
	}

	return clrCode;
}

function rentalCapitalValues(currentdata, classname) {

	var numrcv = parseFloat(currentdata);
		var strrcv = numrcv.toFixed(10);
		strrcv = strrcv.substring(0, strrcv.length-9);

		if(currentdata == 'NA'){
			$('.'+classname).html( 'NA');
		} else {
			$('.'+classname).html( strrcv + '%');
		}
}



$(function() {
	if( /BlackBerry/i.test(navigator.userAgent) ) {
		$("head").append( $("<style>").html('@media all and (orientation:portrait){#portrait_top{display:block} #landscape_dropdown{display:none}#landscape-logo{display:none}.titleMainLand{ display: none; }.landscapeView{display:block}.portraitView{display:block}ul.BoxerHeader{margin:0px; padding:0px; float:left; width:100% }li.boxer{float:left; width:45%; overflow: hidden;  border:1px solid #C7C7C7; margin-left:2%; padding:3px; margin-bottom: 5px; box-shadow: 0 8px 6px -6px #888; height:60px;}.bxCnt{ background: #F5F5F5; overflow: hidden; padding:4px; height:52px}.HKD{font-size:10px; color:#bd131c; padding-bottom:3px;}.HKD span.Percent {float: left !important;margin-left: 0 !important; padding-top: 4px !important; width: 100% !important;}}@media all and (orientation:landscape) {#portraitmode{display:none}#portrait_top{display:none}#landscape_dropdown{display:block;}#landscape-logo{display:block}#landscape-reis{display:none}.heightheader{padding-top: 2px;}.navButton{float:left; margin-top:-7px !important;}.titleMainPort{ display: none; }.landscapeView{display:block}.portraitView{display:none}.Values{font-size:7px;padding-top:0px;}.Gross{font-size:7px;}.HKD{font-size:8px;}.capital_value{font-size:8px !important;}.arrowDown_Red{padding-right:20px}.arrowUp_Green{padding-right:20px}.arrowDown_Black{padding-right:20px}.ChartButton{margin-top:-2px}.dataContainers img{width:105px !important; height:105px !important; margin-top:-5px !important}.socialMedia{margin-top:-2px !important}.Overall{font-size:11px;} div.ui-slider-switch{margin-top: -3px;}}') )
	}
	else if (/iPad/i.test(navigator.userAgent))
	{
		if(screen.width == 768){
			$("head").append( $("<style>").html('@media all and (orientation:portrait){.note_txt{font-size:15px; margin-left:20px}#portrait_top{display:block} #landscape_dropdown{display:none}#landscape-logo{display:none}.titleMainLand{ display: none; }.landscapeView{display:block}.portraitView{display:block}ul.BoxerHeader{margin:0px 0px 0px 4%; padding:0px; float:left;width:95%}#homeHeader h1{margin-top:15px}.navButton{padding-top:30px;}li.boxer{float:left; width:45% !important; overflow: hidden;  border:1px solid #C7C7C7; margin-left:2%; padding:3px; margin-bottom: 5px; box-shadow: 0 8px 6px -6px #888;}.Overall{margin-left:25px;}.ui-footer{position:fixed; bottom:0px;}.footer-docs{margin-top:20px}.bxCnt{ background: #F5F5F5; overflow: hidden; padding:4px; }.HKD{font-size:10px; color:#bd131c; padding-bottom:3px;}.HKD span.Percent { margin-left: 20px !important; padding-top: 4px !important; width:100% important;}.ChartButton{margin:55px 15px}li.boxer{margin:10px 0px 20px 10px;height:105px;}.bxCnt{height:105px !important;}#landscape-reis{padding-top:20px;}.dataContainers img{width:400px !important; }.Values, .Gross, .HKD, .capital_value, .HKD span.Percent{font-size:14px !important;}ul.tabs li a{font-size:13px !important;}.Rental{font-size:13px;padding:25px 3px; width:28%; }.hundredper{padding:20px 0px}.valuesCont{padding:20px 0px;}.contentHead{margin:10px 0px; }}@media all and (orientation:landscape) {	#portraitmode{display:none}#portrait_top{display:none}#landscape_dropdown{display:block; padding:20px }.titleMainLand{margin-top:30px;}#landscape-logo{display:block; padding:20px 0px}#landscape-reis{display:none}.heightheader{padding-top: 2px;}.navButton{float:left; margin-top:-7px !important;}.titleMainPort{ display: none; }.landscapeView{display:block}ul.BoxerHeader{margin-left:30px;}.portraitView{display:none}.Values{font-size:7px;padding-top:0px;}.Gross{font-size:7px;}.HKD{font-size:8px;}.capital_value{font-size:8px !important;}.arrowDown_Red{padding-right:20px}.arrowUp_Green{padding-right:20px}.arrowDown_Black{padding-right:20px}.ChartButton{margin-top:25px}.ui-footer{position:fixed; bottom:0px;}.dataContainers img{margin-top:-10px !important}.socialMedia{margin-top:-2px !important}.Overall{font-size:14px; } div.ui-slider-switch{margin-top: -3px;}li.boxer{margin:10px 15px 20px 15px;height:95px;}.bxCnt{height:95px;}.dataContainers img{width:350px !important;}.Values, .Gross, .HKD, .capital_value, .HKD span.Percent{font-size:14px !important;}ul.tabs li a{font-size:13px;}.footer-docs{margin-top:20px}.Rental{font-size:13px;padding:25px 3px; width:30%}.valuesCont{padding:20px 0px;}}') )
		}
		else{
			/*IPAD - MINI */
			$("head").append( $("<style>").html('@media all and (orientation:portrait){#portrait_top{display:block} #landscape_dropdown{display:none}#landscape-logo{display:none}.titleMainLand{ display: none; }.landscapeView{display:block}.portraitView{display:block}ul.BoxerHeader{margin:0px 0px 0px 2%; padding:0px; float:left;width:95%}#homeHeader h1{margin-top:5px}.navButton{padding-top:15px;}li.boxer{float:left; width:45% !important; overflow: hidden;  border:1px solid #C7C7C7; margin-left:2%; padding:3px; margin-bottom: 5px; box-shadow: 0 8px 6px -6px #888;}.Overall{margin-left:20px;}.ui-footer{position:fixed; bottom:0px;}.footer-docs{margin-top:10px}.bxCnt{ background: #F5F5F5; overflow: hidden; padding:4px; }.HKD{font-size:10px; color:#bd131c; padding-bottom:3px;}.HKD span.Percent { margin-left: 20px !important; padding-top: 4px !important; width:100% important;}.ChartButton{margin:25px 15px}li.boxer{margin:10px 0px 20px 10px;height:85px;}.bxCnt{height:85px !important;}#landscape-reis{padding-top:10px;}.dataContainers img{width:350px !important; }.Values, .Gross, .HKD, .capital_value, .HKD span.Percent{font-size:14px !important;}ul.tabs li a{font-size:13px !important;}.Rental{font-size:13px;padding:15px 3px; width:28%; }.hundredper{padding:10px 0px}.valuesCont{padding:8% 0%;}.contentHead{margin:5px 0px; }}@media all and (orientation:landscape) {	#portraitmode{display:none}#portrait_top{display:none}#landscape_dropdown{display:block; padding:5px }.titleMainLand{margin-top:10px;}#landscape-logo{display:block; padding:5px 0px}#landscape-reis{display:none}.heightheader{padding-top: 2px;}.navButton{float:left; margin-top:-7px !important;}.titleMainPort{ display: none; }.landscapeView{display:block}ul.BoxerHeader{margin-left:20px;}.portraitView{display:none}.Values{font-size:7px;padding-top:0px;}.Gross{font-size:7px;}.HKD{font-size:8px;}.capital_value{font-size:8px !important;}.arrowDown_Red{padding-right:20px}.arrowUp_Green{padding-right:20px}.arrowDown_Black{padding-right:20px}.ChartButton{margin-top:5px}.ui-footer{position:fixed; bottom:0px;}.dataContainers img{margin-top:-10px !important}.socialMedia{margin-top:-2px !important}.Overall{font-size:18px; } div.ui-slider-switch{margin-top: -3px;}li.boxer{margin:10px 15px 0px 15px;height:110px;}.bxCnt{height:110px;}.dataContainers img{width:300px !important;}.Values, .Gross, .HKD, .capital_value, .HKD span.Percent{font-size:20px !important; }.HKD{padding-top:7%}ul.tabs li a{font-size:13px;}.footer-docs{margin-top:10px}.Rental{font-size: 20px; padding: 7% 1%;  width: 30%;}.note_txt{font-size: 15px; margin-left:15px;}.logo-reis{width:12% !important; margin-top:20px !important;margin-left:25px !important;}}') )
		}
	}
	else if (/iPhone/i.test(navigator.userAgent))
	{
		if( screen.width < 540 ) {
			var sw = 414;
		} else{
			var sw = 480;
		}
		window.addEventListener("load",function(){calciphoneheight();});
		window.addEventListener("orientationchange",function(){calciphoneheight();});
		function calciphoneheight(){
			if (window.outerHeight > 442)
			{$(".innBox").css({"min-height":"280px"})}
		}
		$("#sec1tab1").css({ "padding-bottom": "0px !important", "float": "left" })
		$("head").append( $("<style>").html('@media screen and (max-width: '+(sw)+'px){#portrait_top{display:block} .ui-footer{position:absolute; bottom:0}#landscape_dropdown{display:none}#landscape-logo{display:none}.titleMainLand{ display: none; }.landscapeView{display:block}.portraitView{display:block}#homeHeader h1{margin-top:3px;}ul.BoxerHeader{margin:0px; padding:0px; float:left; width:100% }li.boxer{float:left; width:45%; overflow: hidden;  border:1px solid #C7C7C7; margin-left:2%; padding:3px; margin-bottom: 5px; box-shadow: 0 8px 6px -6px #888; height:55px;}.bxCnt{ background: #F5F5F5; overflow: hidden; padding:4px; height:52px}.HKD{font-size:10px; color:#bd131c; padding-bottom:3px;}.HKD span.Percent {float: left !important;margin-left: 0 !important; padding-top: 4px !important; width: 100% !important;}.dataContainers img{width:190px}.innBox{min-height:265px;}.titleMainPort{font-size:12px !important;}}@media screen and (min-width: '+(sw+1)+'px) {.HKD span.arrowDown_Red:after {top: 4px;}.valuesCont{padding-top: 3px;}.Rental{padding-top: 3px;}.note_txt{font-size: 11px;padding: 0px 0 0 23px;}#portraitmode{display:none}#portrait_top{display:none}#landscape_dropdown{display:block;}#landscape-logo{display:block; width:12% !important; }.logo-reis{width: 10% !important;margin-top:10px !important;}#landscape-reis{display:none}.heightheader{padding-top: 2px;}.navButton{float:left; margin-top:-12px !important;}ul.BoxerHeader{margin:0px 0px 10px 10px;overflow:hidden;}.titleMainPort{ display: none; }.landscapeView{display:block}.portraitView{display:none}.Values{font-size:7px;padding-top:0px;}.Gross{font-size:7px;}.HKD{font-size:8px;}.capital_value{font-size:8px !important;}.arrowDown_Red{padding-right:20px}.arrowUp_Green{padding-right:20px}.arrowDown_Black{padding-right:20px}.ChartButton{margin-top:5px}.dataContainers img{width:110px; margin-top: -10px !important; margin-bottom: 0px !important; margin-left: 45px;}.socialMedia{margin-top:-2px !important}.Overall{font-size:11px;} div.ui-slider-switch{margin-top: -3px;}.innBox{min-height:180px;}.note_txt{position: absolute;right: 10px; top:44px; padding-top:0}.ui-footer{position:fixed;bottom:0}li.boxer{height: 26px;}}'))
	}
	else if( screen.width < 540 ) {
		var sw = 414;
		$("#sec1tab1").css({ "padding-bottom": "0px !important", "float": "left" })
		$("head").append( $("<style>").html('@media screen and (max-width: '+(sw)+'px){#portrait_top{display:block} #landscape_dropdown{display:none}#landscape-logo{display:none}.titleMainLand{ display: none; }.landscapeView{display:block}#homeHeader h1{margin-top:3px;}.ui-btn{margin:0.5em 0px 0.1em 0px}.portraitView{display:block}ul.BoxerHeader{margin:20px 0px 0px 0px; padding:0px; float:left; width:100% }li.boxer{float:left; width:45%; overflow: hidden;  border:1px solid #C7C7C7; margin-left:2%; padding:3px; margin-bottom: 5px; box-shadow: 0 8px 6px -6px #888; height:60px;}.bxCnt{ background: #F5F5F5; overflow: hidden; padding:4px; height:52px}.HKD{font-size:10px; color:#bd131c; padding-bottom:3px;}.HKD span.Percent {float: left !important;margin-left: 0 !important; padding-top: 4px !important; width: 100% !important;}.Rental{padding:15px 3px 10px 3px}.valuesCont{padding-top:4px}.dataContainers img{width:300px;}.footer-docs{position:fixed; bottom:0px}.innBox{min-height:200px !important;}}@media screen and (min-width: '+(sw+1)+'px) {	#portraitmode{display:none}#portrait_top{display:none}#landscape_dropdown{display:block;}#landscape-logo{display:block; }#landscape-reis{display:none}.heightheader{padding-top: 2px;}.navButton{float:left; margin-top:-7px !important;}.titleMainPort{ display: none; }.landscapeView{display:block}.innBox{min-height:150px !important; }.portraitView{display:none}.Values{font-size:7px;padding-top:0px;}.Gross{font-size:7px;}.HKD{font-size:8px;}.capital_value{font-size:8px ;}.arrowDown_Red{padding-right:20px}.arrowUp_Green{padding-right:20px}.arrowDown_Black{padding-right:20px}.ChartButton{margin-top:-2px}.dataContainers img{width:160px !important;  margin-top:0px !important}.socialMedia{margin-top:-2px !important}.Overall{font-size:11px;} div.ui-slider-switch{margin-top: -3px;}.Rental{padding-top:5px}.valuesCont{padding-top:5px}ul.BoxerHeader{margin:20px 0px 0px 10px;}}') )
	} 
	else if ( screen.width > 540 && screen.width < 900) {
			var sw = 480;
			window.addEventListener("orientationchange",function(){
				$(".innBox").css({"min-height":"200px"});
			});
			$("#sec1tab1").css({ "padding-bottom": "0px !important", "float": "left" })
			$("head").append( $("<style>").html('@media screen and (max-width: '+(sw)+'px){#portrait_top{display:block} #landscape_dropdown{display:none}#landscape-logo{display:none}.titleMainLand{ display: none; }.landscapeView{display:block}#homeHeader h1{margin-top:3px;}.portraitView{display:block}ul.BoxerHeader{margin:20px 0px 0px 0px; padding:0px; float:left; width:100%; }li.boxer{float:left; width:45%; overflow: hidden;  border:1px solid #C7C7C7; margin-left:2%; padding:3px; margin-bottom: 5px; box-shadow: 0 8px 6px -6px #888; height:60px;}.bxCnt{ background: #F5F5F5; overflow: hidden; padding:4px; height:52px}.HKD{font-size:10px; color:#bd131c; padding-bottom:3px;}.HKD span.Percent {float: left !important;margin-left: 0 !important; padding-top: 4px !important; width: 100% !important;}.dataContainers img{width:300px !important;}.footer-docs{position:fixed; bottom:0px}.innBox{min-height:150px !important;}}@media screen and (min-width: '+(sw+1)+'px) {	#portraitmode{display:none}#portrait_top{display:none}#landscape_dropdown{display:block;}#landscape-logo{display:block; width:12% !important }.logo-reis{width: 10% !important;margin-top:10px !important;}#landscape-reis{display:none}.heightheader{padding-top: 2px;}.navButton{float:left; margin-top:-7px !important;}.titleMainPort{ display: none; }.landscapeView{display:block}.portraitView{display:none}.Values{font-size:7px;padding-top:0px;}.Gross{font-size:7px;}.HKD span.arrowDown_Red:after{top: 4px;}.HKD{font-size:8px;    padding-top: 4px;}.capital_value{font-size:8px ;}.arrowDown_Red{padding-right:20px}.arrowUp_Green{padding-right:20px}.arrowDown_Black{padding-right:20px}.ChartButton{margin-top:-2px}.dataContainers img{width:130px !important; margin-top:0px !important}.socialMedia{margin-top:-2px !important}.Overall{font-size:11px;} div.ui-slider-switch{margin-top: -3px;}.footer-docs{position:fixed; bottom:0px}ul.BoxerHeader{margin:20px 0px 0px 10px;}.innBox{min-height:150px !important;}.note_txt{position: absolute;right: 10px; bottom:75px; padding-top:0}}') )
	} 
	else{
		/* to Check whether its inside iframe*/
		if ( window.self === window.top ) 
		{
			/*Not in iframe*/
			$(window).resize(function()
			{
				$("head").append( $("<style>").html('.ui-mobile [data-role=page], .ui-mobile [data-role=dialog], .ui-page{position:relative; width:980px;margin:0px auto;}.ui-footer{width:980px;margin:0px auto;}ul.BoxerHeader{margin-left:20px;} body.ui-mobile-viewport,div.ui-mobile-viewport { overflow-x: visible; }.titleMainPort{margin-left:45px !important}.socialMedia{width:940px; padding:0px 20px}#homeHeader h1{margin-top:15px}li.boxer{margin:10px 15px 0px 15px;height:75px;}.bxCnt{height:75px;}.dataContainers img{width:300px !important;}.Values, .Gross, .HKD, .capital_value, .HKD span.Percent{font-size:12px !important;}.HKD span.Percent{margin-left:20px;}.HKD span.arrowUp_Green:after{bottom:2px;}.Rental{font-size:13px;padding:25px 3px; width:30%;}.contentHead{padding:0px 0px 10px 0px;}.hundredper{padding-bottom:10px;}.Overall{font-size:13px !important; margin-left:23px;}.titleMainLand{display:none;}.valuesCont{padding:20px 0px;}.chartContainer {margin:20px 0px;}#portraitmode, #landscape-reis{display:block !important}#landscape_dropdown, #landscape-logo{display:none !important;}.navButton{float:right !important; padding-top:30px}ul.tabs li a{font-size:13px;}.ChartButton{margin:25px 15px !important;}.ui-slider-label-b{background-color:#bc141a}.ui-slider-label-a{background-color:#333}') );
			})
			var sw = 960;
			$("head").append( $("<style>").html('@media only screen and (min-width : 960px) {.ui-mobile [data-role=page], .ui-mobile [data-role=dialog], .ui-page{position:relative; width:980px;margin:0px auto;}.ui-footer{width:980px;margin:0px auto;}.footer-docs{position:fixed; bottom:0px}ul.BoxerHeader{margin-left:20px;}.titleMainPort{margin-left:45px !important}.socialMedia{width:940px; padding:0px 20px}#homeHeader h1{margin-top:15px}li.boxer{margin:10px 15px 0px 15px;height:75px;}.bxCnt{height:75px;}.dataContainers img{width:300px !important;}.Values, .Gross, .HKD, .capital_value, .HKD span.Percent{font-size:12px !important;}.HKD span.Percent{margin-left:20px;}.HKD span.arrowUp_Green:after{bottom:2px;}.Rental{font-size:13px;padding:25px 3px; width:30%;}.contentHead{padding:0px 0px 10px 0px;}.hundredper{padding-bottom:10px;}.Overall{font-size:13px !important; margin-left:23px;}.titleMainLand{display:none;}.valuesCont{padding:20px 0px;}.chartContainer {margin:20px 0px;}#portraitmode, #landscape-reis{display:block !important}#landscape_dropdown, #landscape-logo{display:none !important;}.navButton{float:right !important; padding-top:30px}ul.tabs li a{font-size:13px;}.ChartButton{margin:25px 15px !important;}.ui-slider-label-b{background-color:#bc141a}.ui-slider-label-a{background-color:#333}}') );
		
		} else 
		{ 
			/*in iframe*/
			$("head").append( $("<style>").html('.ui-mobile [data-role=page], .ui-mobile [data-role=dialog], .ui-page{position:relative !important; width:100% !important; margin:0px auto;} .footer-docs{position:fixed; bottom:0px}.ui-footer{width:100%;margin:0px auto;}ul.BoxerHeader{margin-left:5px;}.titleMainPort{margin-left:5px !important}.socialMedia{width:98%; padding:0px 5px}#homeHeader h1{margin-top:0px}li.boxer{margin:10px 5px 0px 5px;height:50px;}.bxCnt{height:50px;}.dataContainers img{width:220px !important;}.Values, .Gross, .HKD, .capital_value, .HKD span.Percent{font-size:11px !important;}.HKD span.Percent{margin-left:20px;}.HKD span.arrowUp_Green:after{bottom:2px;}.Rental{font-size:11px;padding:5px 3px; }.contentHead{padding:0px 0px 10px 0px;}.hundredper{padding:0px;}.Overall{font-size:13px !important; margin:0px 0px 0px 5px;}.titleMainLand{display:none;}.valuesCont{padding:5px 0px;}.chartContainer {margin:20px 0px;}#portraitmode, #landscape-reis{display:block !important}#landscape_dropdown, #landscape-logo{display:none !important; }.navButton{float:right !important; padding-top:0px}ul.tabs li a{font-size:13px;}.ChartButton{margin:5px 15px !important;}.ui-slider-label-b{background-color:#bc141a}.ui-slider-label-a{background-color:#333}') );
		}
	}
	$.mobile.page.prototype.options.domCache = true;
	$("#country, #country_top").change(function(event, ui) {
		$.mobile.changePage( "#"+$(this).val(), { transition: "flow"} );
		var dataCSV;
		switch( $(this).val() ){

			case "index":
				dataCSV = "data/auckland.csv";
			break;

			case "Bengaluru":
				dataCSV = "data/bengaluru.csv";
			break;

			case "Bangkok":
				dataCSV = "data/bangkok.csv";
			break;

			case "Beijing":
				dataCSV = "data/beijing.csv";
			break;

			case "Brisbane":
				dataCSV = "data/brisbane.csv";
			break;

			/*case "Chengdu":
				dataCSV = "data/chengdu.csv";
			break;*/

			case "Delhi":
				dataCSV = "data/delhi.csv";
			break;

			case "Guangzhou":
				dataCSV = "data/guangzhou.csv";
			break;

			case "Gurgaon":
				dataCSV = "data/gurgaon.csv";
			break;

			case "HoChiMinhCity":
				dataCSV = "data/hochiminhcity.csv";
			break;

			case "HongKong":
				dataCSV = "data/hong_kong.csv";
			break;

			case "Jakarta":
				dataCSV = "data/jakarta.csv";
			break;

			case "KualaLumpur":
				dataCSV = "data/Kuala_Lumpur.csv";
			break;

			/* case "Macau":
				dataCSV = "data/macau.csv";
			break; */

			case "Manila":
				dataCSV = "data/manila.csv";
			break;

			case "Melbourne":
				dataCSV = "data/melbourne.csv";
			break;

			case "Mumbai":
				dataCSV = "data/mumbai.csv";
			break;

			case "Osaka":
				dataCSV = "data/osaka.csv";
			break;

			case "Perth":
				dataCSV = "data/perth.csv";
			break;

			case "Seoul":
				dataCSV = "data/seoul.csv";
			break;

			case "Shanghai":
				dataCSV = "data/shanghai.csv";
			break;

			case "Shenzhen":
				dataCSV = "data/Shenzhen.csv";
			break;

			case "Singapore":
				dataCSV = "data/singapore.csv";
			break;

			case "Sydney":
				dataCSV = "data/sydney.csv";
			break;

			case "Taipei":
				dataCSV = "data/taipei.csv";
			break;

			case "Tokyo":
				dataCSV = "data/tokyo.csv";
			break;

			default:
				dataCSV = "data/auckland.csv";
			break;


			

			
		}

		officeArray = new Array(), retailArray = new Array(), residentialArray = new Array(), industrialArray = new Array(), hotelArray = new Array()
		var tmpCity = $(this).val();

		$("#country, #country_top").val(tmpCity).selectmenu("refresh", false)
		$.ajax({
			url: dataCSV,
			dataType: "html",
			success: function(html){
					//alert("hash");
					data = html.split("\r\n");
					$("body").trigger("prefetchData", [data]);
					if( $("#topCats li.active").hasClass("disabled") ) {
						$("#topCats li:not(.disabled) a").trigger('click')	
					} else {
						$("#topCats li.active a").trigger('click')	
					}
					if( !$("#topCats li.active").hasClass("disabled") ) {
						window.location.hash	=	"#"+tmpCity+"_"+$("#topCats li.active").attr("rel");
					} else {
						window.location.hash	=	"#"+tmpCity+"_"+$("#topCats li:not(.disabled)").attr("rel");
					}
				}
			})
		if((navigator.userAgent.toLowerCase().indexOf('iphone')>0) || (navigator.userAgent.toLowerCase().indexOf('android')>0))	
		{
			hideAddressBar();
			function hideAddressBar(){
				if(document.documentElement.scrollHeight<window.outerHeight/window.devicePixelRatio)
				document.documentElement.style.height=(window.outerHeight/window.devicePixelRatio)+'px';
				setTimeout(window.scrollTo(1,1),0);
			}
		}
		
	});


	if (window.navigator.onLine) {
		if( !$.jStorage.get("AucklandData") ) {
			$.ajax({
				url: "data/auckland.csv",
				dataType: "html",
				success: function(html){
					data = html.split("\r\n");
					//$("body").trigger("prefetchData", [data]);
				}
			})
		}			
	} 
	$("body").bind("prefetchData", function(e, data){
		
		$.each(data, function(key, value){
			if( $.trim(value) != "" ) {
				var column	=	value.split(",");
				switch( column[0].replace('"', '', 'g') ) {
					case "Office":
						officeArray			=	column;
					break;
					case "Retail":
						retailArray			=	column;
					break;
					case "Residential":
						residentialArray	=	column;
					break;
					case "Industrial":
						industrialArray		=	column;
					break;
					case "Hotel":
						hotelArray			=	column;
					
					break;
				}
			}
		})

		$("body").trigger("HongKongDataParse");		
	})

	$("body").bind("SetData", function(e, curData){
		if( curData[1] == undefined ) {
			return false;
		}
		var tmp = curData[1].split("-");
		$(".titleMainPort").html( curData[1]+" - "+curData[2] )
		$(".titleMainLand").html( $.trim(tmp[1])+" - "+curData[2] )

		$(".rental_currency").html( curData[3] )
		$(".rental_value").html( addCommas(eval(curData[4]).toFixed(0)) )
		var arrTmp = new Array();
		if( $.trim(curData[5]) != "" ) {
			arrTmp.push(curData[5]);
		}
		if( $.trim(curData[6]) != "" ) {
			arrTmp.push(curData[6]);
		}
		
		if( arrTmp.length > 0 ) {
			$(".rental_measure").html( arrTmp.join(", ") )
		} else {
			$(".rental_measure").html("");
		}
		
		$(".Gross").html( curData[19] )

	rentalCapitalValues(curData[7], 'rental_change_value');
		 

		$(".rental_changey_arrow, .rental_change_arrow, .capital_change_arrow, .capital_changey_arrow").removeClass("arrowDown_Red arrowUp_Green arrowDown_Green arrowUp_Red arrowDown_Black arrowUp_Black arrowBoth_Black arrowBoth_Green arrowBoth_Red");
		$(".rental_change_arrow").addClass( returmColorCodeClass(curData[8]) ) 

		rentalCapitalValues(curData[9], 'rental_changey_value');

		$(".rental_changey_arrow").addClass( returmColorCodeClass(curData[10]) ) 

		if ((addCommas(eval(curData[11]).toFixed(0)))!= 0)
		{
			$(".capital_value").html( addCommas(eval(curData[11]).toFixed(0)) );
			$(".capital_value").css({'font-size': '10px', 'color': '#bc141a'})
		}
		else
		{
			$(".capital_value").html('NA');
			$(".capital_value").css({'font-size': '11px', 'color': '#000000'})
		}


		if (curData[12]=='NA' )
		{
			$(".capital_currency").html('');
			//$(".capital_currency").html( curData[12] );
			//$(".capital_currency").css({'padding-top': '12px !important', 'font-size': '11px', 'color': '#000', 'font-weight': 'bold !important'})
		}
		else
		{
			$(".capital_currency").html( curData[12] )
			//$(".capital_currency").css({'padding-top': '12px !important', 'font-size': '11px', 'color': '#000', 'font-weight': 'bold !important'})
		}
		


		if (curData[13] =='NA')
			{
				$(".capital_measure").html('');
			}
		else
		{
			$(".capital_measure").html( curData[13].replace("|", ",", "g") )
		};

		rentalCapitalValues(curData[14], 'capital_change_value');
			 
		$(".capital_change_arrow").addClass( returmColorCodeClass(curData[15]) ) 	


			 rentalCapitalValues(curData[16], 'capital_changey_value');

		$(".capital_changey_arrow").addClass( returmColorCodeClass(curData[17]) ) 
		$("#chartImage").attr("src", "gimages/"+(curData[18].replace('"', '', 'g')) )

	})

	$("body").bind("HongKongDataParse", function(){
		//alert("hongkong function");
		$(".disabled").removeClass("disabled")
		if( officeArray.length == 0 ){ $(".officeHD").addClass("disabled") };
		if( retailArray.length == 0 ){ $(".retailHD").addClass("disabled") };
		if( residentialArray.length == 0 ){ $(".residentialHD").addClass("disabled") };
		if( industrialArray.length == 0 ){ $(".industrialHD").addClass("disabled") };
		if( hotelArray.length == 0 ){ $(".hotelHD").addClass("disabled") };
		
		

		//$("#topCats li:not(.disabled):eq(0)").trigger('click');

		//$("body").trigger("SetData", [officeArray]);
	})
	$("#topCats li:not(.disabled) a").live("click tap", function(){
		$("#topCats li.active").removeClass('active');
		$(this).parent("li").addClass('active');

		var curData	=	"";
		switch( $(this).parent("li").attr("rel") )
		{
			case "office":
				curData	=	officeArray;
				$("#RentText").html("RENTAL VALUES");
				$("#CapitalText").html("CAPITAL VALUES");
				$("#HotelHide").show();
				$(".contentHead:last").find(".note_txt").hide();
				$("#HotelHide1").show();
			break;

			case "retail":
				curData	=	retailArray;
				$("#RentText").html("RENTAL VALUES");
				$("#CapitalText").html("CAPITAL VALUES");
				$("#HotelHide").show();
				$(".contentHead:last").find(".note_txt").hide();
				$("#HotelHide1").show();
			break;

			case "residential":
				curData	=	residentialArray;
				$("#RentText").html("RENTAL VALUES");
				$(".contentHead:last").find(".note_txt").hide();
				$("#CapitalText").html("CAPITAL VALUES");
				$("#HotelHide").show();
				$("#HotelHide1").show();
			break;

			case "industrial":
				curData	=	industrialArray;
				$("#RentText").html("RENTAL VALUES");
				$("#CapitalText").html("CAPITAL VALUES");
				$("#HotelHide").show();
				$(".contentHead:last").find(".note_txt").hide();
				$("#HotelHide1").show();
			break;

			case "hotel":
				curData	=	hotelArray;
					$("#RentText").html("Occupancy (MAA)");
					$("#CapitalText").html(" ADR (MAA)");
					$(".contentHead:last").find(".note_txt").empty();
					$(".note_txt").css({"display":"none"});
					$(".contentHead:last").append("<div class='note_txt'><b>Note:</b> MAA - Moving Annual Average<br>Data as at November 2015.</div>");
					$("#HotelHide").hide();
					//var rental=$("#RentText").next().find(".rental_value").text();
					
					$("#HotelHide1").hide();
					
			break;
		}

		$("body").trigger("SetData", [curData]);

		window.location.hash	=	"#"+$("#country").val()+"_"+$(this).parent("li").attr("rel");
		if((navigator.userAgent.toLowerCase().indexOf('iphone')>0) || (navigator.userAgent.toLowerCase().indexOf('android')>0))	
		{
			hideAddressBar();
			function hideAddressBar(){
				if(document.documentElement.scrollHeight<window.outerHeight/window.devicePixelRatio)
				document.documentElement.style.height=(window.outerHeight/window.devicePixelRatio)+'px';
				setTimeout(window.scrollTo(1,1),0);
			}
		}
       if($(this).parent("li").attr("rel") == "hotel")
		{
			var rental=$("#RentText").next().find(".rental_value").text();
		   $("#RentText").next().find(".rental_value").text(""+rental+"%");
		}
		else
		{

			var rental=$("#RentText").next().find(".rental_value").text();
		   $("#RentText").next().find(".rental_value").text(rental);
		}
		
	})

	$( "#slider2" ).on( 'slidestop', function( event ) {
		event.preventDefault();
		var t = this;
		setTimeout(function(){ 
			$(".dataContainers").hide();
			$(".ChartButton .ui-btn-text").html("");
			if( $(t).val() != "Chart" ) {
				$(".chartContainer").fadeIn();
				$(".dataContainer").hide();
				$(".ChartButton .ui-btn-text").html("&lt;")
				//alert($(".ChartButton .ui-btn-text").html());
			} else {
				$(".chartContainer").hide();
				$(".dataContainer").fadeIn();
				$(".ChartButton .ui-btn-text").html("&gt;");
				//alert($(".ChartButton .ui-btn-text").html());
			}
		}, 1000);
		if((navigator.userAgent.toLowerCase().indexOf('iphone')>0) || (navigator.userAgent.toLowerCase().indexOf('android')>0))	
		{
			hideAddressBar();
			function hideAddressBar(){
				if(document.documentElement.scrollHeight<window.outerHeight/window.devicePixelRatio)
				document.documentElement.style.height=(window.outerHeight/window.devicePixelRatio)+'px';
				setTimeout(window.scrollTo(1,1),0);
			}
		}
		
	});

	$(".ChartButton .ui-btn-text").html("&gt;")	
	//alert($(".ChartButton .ui-btn-text").html());
	$(".ChartButton .ui-btn-active").removeClass("ui-btn-active")
	
	if( hash != "" ) 
	{
		hashArr	=	hash.split("_");
		
		$("#country")
			.val(hashArr[0])
			.selectmenu("refresh", false)
			.trigger("change")
						
		$("#topCats li[rel="+hashArr[1]+"] a").trigger("click")
	} else {
		
		$("#country")
			.val("index")
			.selectmenu("refresh", false)
			.trigger("change")
						
		$("#topCats li[rel=office]").trigger("click")
	}
	
	
})