$(document).ready(function(){


$.getScript("PIE.js", function () {
	if (window.PIE) {
		$('.ui-btn-corner-all, .ui-shadow, .ui-btn-up-d, .ui-icon, .ui-icon-arrow-d, .ui-icon-shadow').each(function () {
			PIE.attach(this);
		});
	}
})


var officeArray = new Array(), retailArray = new Array(), residentialArray = new Array(), industrialArray = new Array(), hotelArray = new Array()
var hash	=	window.location.hash.replace("#", "");
//debugger();
function addCommas(nStr)
{
	nStr += '';
	x = nStr.split('.');
	x1 = x[0];
	x2 = x.length > 1 ? '.' + x[1] : '';
	var rgx = /(\d+)(\d{3})/;
	while (rgx.test(x1)) {
		x1 = x1.replace(rgx, '$1' + ',' + '$2');
	}
	return x1 + x2;
}

function returmColorCodeClass(clrTxt){
	switch(clrTxt) {
		case "up_red":
			clrCode	=	"arrowUp_Red";
		break;

		case "down_red":
			clrCode	=	"arrowDown_Red";
		break;

		case "both_red":
			clrCode	=	"arrowBoth_Red";
		break;

		case "up_green":
			clrCode	=	"arrowUp_Green";
		break;			

		case "down_green":
			clrCode	=	"arrowDown_Green";
		break;

		case "both_green":
			clrCode	=	"arrowBoth_Green";
		break;

		case "up_black":
			clrCode	=	"arrowUp_Black";
		break;			

		case "down_black":
			clrCode	=	"arrowDown_Black";
		break;

		case "both_black":
			clrCode	=	"arrowBoth_Black";
		break;

		default: 
			clrCode = "";
		break;
	}

	return clrCode;
}
$("#country, #country_top").change(function(event, ui) {
		var dataCSV;
		switch( $(this).val() ){

			case "index":
				dataCSV = "data/auckland.csv";
			break;

			case "Bangalore":
				dataCSV = "data/bangalore.csv";
			break;

			case "Bangkok":
				dataCSV = "data/bangkok.csv";
			break;

			case "Beijing":
				dataCSV = "data/beijing.csv";
			break;

			case "Brisbane":
				dataCSV = "data/brisbane.csv";
			break;

			case "Chengdu":
				dataCSV = "data/chengdu.csv";
			break;

			case "Delhi":
				dataCSV = "data/delhi.csv";
			break;

			case "Guangzhou":
				dataCSV = "data/guangzhou.csv";
			break;

			case "HoChiMinhCity":
				dataCSV = "data/hochiminhcity.csv";
			break;

			case "HongKong":
				dataCSV = "data/hong_kong.csv";
			break;

			case "Jakarta":
				dataCSV = "data/jakarta.csv";
			break;

			case "KualaLumpur":
				dataCSV = "data/Kuala_Lumpur.csv";
			break;

			/* case "Macau":
				dataCSV = "data/macau.csv";
			break; */

			case "Manila":
				dataCSV = "data/manila.csv";
			break;

			case "Melbourne":
				dataCSV = "data/melbourne.csv";
			break;

			case "Mumbai":
				dataCSV = "data/mumbai.csv";
			break;

			case "Osaka":
				dataCSV = "data/osaka.csv";
			break;

			case "Perth":
				dataCSV = "data/perth.csv";
			break;

			case "Seoul":
				dataCSV = "data/seoul.csv";
			break;

			case "Shanghai":
				dataCSV = "data/shanghai.csv";
			break;

			case "Singapore":
				dataCSV = "data/singapore.csv";
			break;

			case "Sydney":
				dataCSV = "data/sydney.csv";
			break;

			case "Taipei":
				dataCSV = "data/taipei.csv";
			break;

			case "Tokyo":
				dataCSV = "data/tokyo.csv";
			break;

			default:
				dataCSV = "data/auckland.csv";
			break;

			
		}
		officeArray = new Array(), retailArray = new Array(), residentialArray = new Array(), industrialArray = new Array(), hotelArray = new Array()
		var tmpCity = $(this).val();
		//alert(tmpCity);


		$("#country, #country_top").val(tmpCity).selectmenu("refresh", false)
		$.ajax({
			url: dataCSV,
			dataType: "html",
			success: function(html){
					data = html.split("\r\n");
					$("body").trigger("prefetchData", [data]);
					window.scrollTo(0, 70);
					if( $("#topCats li.active").hasClass("disabled") ) {
						$("#topCats li:not(.disabled) a").trigger('click')	
					} else {
						$("#topCats li.active a").trigger('click')	
					}
					if( !$("#topCats li.active").hasClass("disabled") ) {
						window.location.hash	=	"#"+tmpCity+"_"+$("#topCats li.active").attr("rel");
					} else {
						window.location.hash	=	"#"+tmpCity+"_"+$("#topCats li:not(.disabled)").attr("rel");
					}
					//alert("sucess");
				}
			})
	})
	/*if (window.navigator.onLine) {
		if( !$.jStorage.get("AucklandData") ) {
			$.ajax({
				url: "data/auckland.csv",
				dataType: "html",
				success: function(html){
					data = html.split("\r\n");
					alert("sucess");
				}
			})
		}			
	} */
	$("body").bind("prefetchData", function(e, data){
		
		$.each(data, function(key, value){
			if( $.trim(value) != "" ) {
				var column	=	value.split(",");
				switch( column[0].replace('"', '', 'g') ) {
					case "Office":
						officeArray			=	column;
					break;
					case "Retail":
						retailArray			=	column;
					break;
					case "Residential":
						residentialArray	=	column;
					break;
					case "Industrial":
						industrialArray		=	column;
					break;
					case "Hotel":
						hotelArray			=	column;
					
					break;
				}
			}
		})

		$("body").trigger("HongKongDataParse");		
	});
	$("body").bind("SetData", function(e, curData){
		if( curData[1] && curData[1] != undefined ) {
			var tmp = curData[1].split("-");
			$(".titleMainPort").html( curData[1]+" - "+curData[2] )
			$(".titleMainLand").html( $.trim(tmp[1])+" - "+curData[2] )

			$(".rental_currency").html( curData[3] )
			$(".rental_value").html( addCommas(eval(curData[4]).toFixed(0)) )
			var arrTmp = new Array();
			if( $.trim(curData[5]) != "" ) {
				arrTmp.push(curData[5]);
			}
			if( $.trim(curData[6]) != "" ) {
				arrTmp.push(curData[6]);
			}
			
			if( arrTmp.length > 0 ) {
				$(".rental_measure").html( arrTmp.join(", ") )
			} else {
				$(".rental_measure").html("");
			}
			$(".Gross").html( curData[19] )

			$(".rental_change_value").html( curData[7] )

			$(".rental_changey_arrow, .rental_change_arrow, .capital_change_arrow, .capital_changey_arrow").removeClass("arrowDown_Red arrowUp_Green arrowDown_Green arrowUp_Red arrowDown_Black arrowUp_Black arrowBoth_Black arrowBoth_Green arrowBoth_Red");
			$(".rental_change_arrow").addClass( returmColorCodeClass(curData[8]) ) 

			$(".rental_changey_value").html( curData[9] )

			$(".rental_changey_arrow").addClass( returmColorCodeClass(curData[10]) ) 

			if ((addCommas(eval(curData[11]).toFixed(0)))!= 0)
			{
				$(".capital_value").html( addCommas(eval(curData[11]).toFixed(0)) );
				$(".capital_value").css({'font-size': '10px', 'color': '#bc141a'})
			}
			else
			{
				$(".capital_value").html('NA');
				$(".capital_value").css({'font-size': '11px', 'color': '#000000'})
			}


			if (curData[12]=='NA' )
			{
				$(".capital_currency").html('');
				//$(".capital_currency").html( curData[12] );
				//$(".capital_currency").css({'padding-top': '12px !important', 'font-size': '11px', 'color': '#000', 'font-weight': 'bold !important'})
			}
			else
			{
				$(".capital_currency").html( curData[12] )
				//$(".capital_currency").css({'padding-top': '12px !important', 'font-size': '11px', 'color': '#000', 'font-weight': 'bold !important'})
			}
			


			if (curData[13] =='NA')
				{
					$(".capital_measure").html('');
				}
			else
			{
				$(".capital_measure").html( curData[13].replace("|", ",", "g") )
			};

			$(".capital_change_value").html( curData[14] )
			$(".capital_change_arrow").addClass( returmColorCodeClass(curData[15]) ) 
		
			$(".capital_changey_value").html( curData[16] )
			$(".capital_changey_arrow").addClass( returmColorCodeClass(curData[17]) ) 
			$("#chartImage").attr("src", "gimages/"+(curData[18].replace('"', '', 'g')) )

		}
	})
	$("body").bind("HongKongDataParse", function(){
		//alert("hongkong function");
		$(".disabled").removeClass("disabled")
		if( officeArray.length == 0 ){ $(".officeHD").addClass("disabled") };
		if( retailArray.length == 0 ){ $(".retailHD").addClass("disabled") };
		if( residentialArray.length == 0 ){ $(".residentialHD").addClass("disabled") };
		if( industrialArray.length == 0 ){ $(".industrialHD").addClass("disabled") };
		if( hotelArray.length == 0 ){ $(".hotelHD").addClass("disabled") };
		//$("#topCats li:not(.disabled):eq(0)").trigger('click');
		//$("body").trigger("SetData", [officeArray]);
	})
	$("#topCats li:not(.disabled) a").live("click tap", function(){
		$("#topCats li.active").removeClass('active');
		$(this).parent("li").addClass('active');
		var ietabs = $("#topCats li.active").index();
		$("#tabIE li").removeClass('active');
		$("#tabIE li").eq(ietabs).addClass('active');
		var curData	=	"";
		switch( $(this).parent("li").attr("rel") )
		{
			case "office":
				curData	=	officeArray;
				$("#RentText").html("RENTAL VALUES");
				$("#CapitalText").html("CAPITAL VALUES");
				$("#HotelHide").show();
				$("#HotelHide1").show();
			break;

			case "retail":
				curData	=	retailArray;
				$("#RentText").html("RENTAL VALUES");
				$("#CapitalText").html("CAPITAL VALUES");
				$("#HotelHide").show();
				$("#HotelHide1").show();
			break;

			case "residential":
				curData	=	residentialArray;
				$("#RentText").html("RENTAL VALUES");
				$("#CapitalText").html("CAPITAL VALUES");
				$("#HotelHide").show();
				$("#HotelHide1").show();
			break;

			case "industrial":
				curData	=	industrialArray;
				$("#RentText").html("RENTAL VALUES");
				$("#CapitalText").html("CAPITAL VALUES");
				$("#HotelHide").show();
				$("#HotelHide1").show();
			break;

			case "hotel":
				curData	=	hotelArray;
					$("#RentText").html("Rev Par");
					$("#CapitalText").html("ADR");
					$("#HotelHide").hide();
					$("#HotelHide1").hide();
			break;
		}

		$("body").trigger("SetData", [curData]);

		window.location.hash	=	"#"+$("#country").val()+"_"+$(this).parent("li").attr("rel");
	})
		$( "#slider2" ).on( 'slidestop', function( event ) {
		event.preventDefault();
		var t = this;
		setTimeout(function(){ 
			$(".dataContainers").hide();
			$(".ChartButton .ui-btn-text").html("");
			if( $(t).val() != "Chart" ) {
				$(".chartContainer").fadeIn();
				$(".dataContainer").hide();
				$(".ChartButton .ui-btn-text").html("&lt;")
				//alert($(".ChartButton .ui-btn-text").html());
			} else {
				$(".chartContainer").hide();
				$(".dataContainer").fadeIn();
				$(".ChartButton .ui-btn-text").html("&gt;");
				//alert($(".ChartButton .ui-btn-text").html());
			}
		}, 1000);
	});

	$(".ChartButton .ui-btn-text").html("&gt;")	
	//alert($(".ChartButton .ui-btn-text").html());
	$(".ChartButton .ui-btn-active").removeClass("ui-btn-active")
	
	if( hash != "" ) 
	{
		hashArr	=	hash.split("_");
		$("#country")
			.val(hashArr[0])
			.selectmenu("refresh", false)
			.trigger("change")
						
		$("#topCats li[rel="+hashArr[1]+"] a").trigger("click")
	} else {
		$("#country")
			.val("index")
			.selectmenu("refresh", false)
			.trigger("change")
						
		$("#topCats li[rel=office]").trigger("click")
	}
	
	//alert("clear function");
})