$(document).ready(function(){

			/* mouseover parrallex move */
			$("div#makeMeScrollable").smoothDivScroll({ 
			//autoScroll: "onstart", 
			autoScrollDirection: "backandforth",
			autoScrollStep: 1,
			autoScrollInterval: 15,
			startAtElementId: "startAtMe",
			visibleHotSpots: "always" });

			/* Parallex image center on windows size */
			var windowWidth  = $( window ).width();
			var windowHeight  = $( window ).height();
			var boxwidth = $("#mainContent").width();
			var boxheight = $("#mainContent").height();
			var WinwidHei = (windowWidth / 2) - (boxwidth / 2); 
			var WinHeigCen = (windowHeight / 2) - (boxheight / 2); 
			$("#mainContent").css({"position": "absolute", "left": WinwidHei+'px', "top": WinHeigCen+'px' });


			/* Lightbox */
			var ParralexwindowWidth  = $( window ).width();
			var ParralexwindowHeight  = $( window ).height();
			var Parralexboxwidth = $(".lightbox").width();
			var Parralexboxheight = $(".lightbox").height();
			
			var ParralexWinwidHei = (ParralexwindowWidth / 2) - (Parralexboxwidth / 2); 
			var ParralexWinHeigCen = (ParralexwindowHeight / 2) - (Parralexboxheight / 2); 

			$(".lightbox").css({"position": "fixed", "left": ParralexWinwidHei+'px', "top" : ParralexWinHeigCen+'px' });
			$("#overlay").css({"opacity": "0.8"});

			$("#closebut").click(function(){
				$(".lightbox").fadeOut();
				$("#overlay").slideToggle(800);
				$('.dummy').hide();
			})

			$(".caseStudy_scroll").hide();
			$('.dummy').hide();
			$("#overlay").hide();
			$("area").click(function(){
				refresh();
				$('.dummy').hide();
				$(".caseStudy_scroll").show();
				$('#closebut').show("fast");
				$(".lightbox").fadeIn(1500);
				$("#overlay").slideToggle(500);
				var lightb = $(this).attr("href");
				$(lightb).fadeIn();
			})	

			/* nano scroll show on lightbox */
			var timeout;
			$(".nano").nanoScroller({ alwaysVisible: true });
			function refresh() {    
				clearTimeout(timeout);
				timeout = setTimeout(function(){
					$(".nano").nanoScroller();

				}, 200);
			}
			
		})