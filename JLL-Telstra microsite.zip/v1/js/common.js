	
	
	$(document).ready(function() {
		/* Slide Toggle */
		$(".box_main").show();
		$('#box_link').toggle(
			function() {
				$('.box_main').animate({"width": "0"}, 500, function() {
					$('.box_main').hide();
					$('#box_img').attr("src", "images/arrow1.jpg");
				});
			},
			function() {
				$('.box_main').show( function() {
					$('.box_main').animate({"width": '225'}, 500);
				});
				$('#box_img').attr("src", "images/arrow2.jpg");
			}
		)

		$('ul.overview_highlight li:first-child').css('margin-top','0');
		
		
	});	

	

	var overviewPage;
	(function($) {
	var defaultsettings = {
		'size' : 55,
		'donutwidth': 40,
		'textsize': 16
	}
  
	var methods = {
		init : function(options) {
		  
		  var initcanvas=true;
		  
		  if (typeof(options) == "object")
		  {
			this.donutchartsettings = $.extend({}, defaultsettings, options);
		
			// autoscale donutwidth and textsize
			if (options["size"] && !options["donutwidth"])
			  this.donutchartsettings["donutwidth"]=options["size"]/5;
			if (options["size"] && !options["textsize"])
			  this.donutchartsettings["textsize"]=options["size"]/10;
		  }
		  else
		  {
			if (typeof(this.donutchartsettings) == "object")
			  initcanvas=false;
			else
			  this.donutchartsettings = defaultsettings;
		  }
		  
		  if (initcanvas)
		  {
			$(this).css("position","relative");
			$(this).css("width",this.donutchartsettings.size+"px");
			$(this).css("height",this.donutchartsettings.size+"px");
			$(this).html("<canvas width='"+this.donutchartsettings.size+"' height='"+this.donutchartsettings.size+"'></canvas><div style='position:absolute;top:0;left:0;line-height:"+this.donutchartsettings.size+"px;text-align:center;width:"+this.donutchartsettings.size+"px;font-family:Arial,sans-serif;font-size:"+this.donutchartsettings.textsize+"px;font-weight:bold;'></div>");
		  
			var canvas = $("canvas",this).get(0);
		  
			// excanvas support
			//console.log("tyep--->>>"+typeof(G_vmlCanvasManager));
			if (typeof(G_vmlCanvasManager) != "undefined")
			  G_vmlCanvasManager.initElement(canvas);
		  
			var ctx = canvas.getContext('2d');
			methods.drawBg.call(ctx, this.donutchartsettings);

		  }

		},
		
		drawBg : function(settings) {
		  this.clearRect(0,0,settings.size,settings.size);
		  this.beginPath();
		  this.fillStyle = settings.bgColor;
		  this.arc(settings.size/2,settings.size/2,settings.size/2,0,2*Math.PI,false);
		  this.arc(settings.size/2,settings.size/2,settings.size/2-settings.donutwidth,0,2*Math.PI,true);
		  this.fill();
		},
		
		drawFg : function(settings,percent) {
		 //alert(percent)
		var ratio = percent/overviewPage * 360;
		ratio=(ratio>=360)?359.9:ratio
		var startAngle = Math.PI*-90/180;
		var endAngle = Math.PI*(ratio-90)/180;
		

		this.beginPath();
		this.fillStyle = settings.fgColor;
		this.arc(settings.size/2,settings.size/2,settings.size/2,startAngle,endAngle,false);	
		this.arc(settings.size/2,settings.size/2,settings.size/2-settings.donutwidth,endAngle,startAngle,true);
		this.fill();
		}
	  };
	  
	  $.fn.donutchart = function(method) {
		return this.each(function() {
		  
		  methods.init.call(this, method);

		  if (method=="animate")
		  {
			
			var percentage = $(this).attr("data-percent");
			var canvas = $(this).children("canvas").get(0);
			var percenttext = $(this).children("div");
			var dcs = this.donutchartsettings;

			if (canvas.getContext)
			{
			  var ctx = canvas.getContext('2d');
			  var j = 0;
			  
			  function animateDonutChart()
			  {
				j++;

				methods.drawBg.call(ctx,dcs);
				methods.drawFg.apply(ctx,[dcs,j]);
				percenttext.text(j+"%");

				if (j >= percentage)
				  clearInterval(animationID);
			  }
		  
			  var animationID = setInterval(animateDonutChart,120); 
			}
		  }
		})
	  }

	})( jQuery );

	


	$(document).ready(function(){
		function init() {
			$("#donutchart1, #donutchart9, #donutchart16, #donutchart23, #donutchart31").donutchart({'size': 55, 'fgColor': '#CE2E28', 'bgColor': '#f6f6f6', 			'strokeColor' : 'blue' })
			$("#donutchart1, #donutchart9, #donutchart16, #donutchart23, #donutchart31").donutchart('animate')

			$("#donutchart2, #donutchart10, #donutchart17, #donutchart24, #donutchart32").donutchart({'size': 55, 'fgColor': '#E4664D', 'bgColor': '#f6f6f6' })
			$("#donutchart2, #donutchart10, #donutchart17, #donutchart24, #donutchart32").donutchart("animate")

			$("#donutchart3, #donutchart11, #donutchart18, #donutchart25, #donutchart33").donutchart({'size': 55, 'fgColor': '#EA947B', 'bgColor': '#f6f6f6' })
			$("#donutchart3, #donutchart11, #donutchart18, #donutchart25, #donutchart33").donutchart("animate")

			$("#donutchart4, #donutchart12, #donutchart19, #donutchart26, #donutchart34").donutchart({'size': 55, 'fgColor': '#F5C7B7', 'bgColor': '#f6f6f6' })
			$("#donutchart4, #donutchart12, #donutchart19, #donutchart26, #donutchart34").donutchart("animate")

			$("#donutchart5, #donutchart13, #donutchart20, #donutchart27, #donutchart35").donutchart({'size': 55, 'fgColor': '#3497BC', 'bgColor': '#f6f6f6' })
			$("#donutchart5, #donutchart13, #donutchart20, #donutchart27, #donutchart35").donutchart("animate")

			$("#donutchart6, #donutchart14, #donutchart21, #donutchart28").donutchart({'size': 55, 'fgColor': '#97C3DA', 'bgColor': '#f6f6f6' })
			$("#donutchart6, #donutchart14, #donutchart21, #donutchart28").donutchart("animate")

			$("#donutchart36").donutchart({'size': 55, 'fgColor': '#97C3DA', 'bgColor': '#fff' })
			$("#donutchart36").donutchart("animate")

			$("#donutchart7, #donutchart29").donutchart({'size': 55, 'fgColor': '#C5DFED', 'bgColor': '#f6f6f6' })
			$("#donutchart7, #donutchart29").donutchart("animate")

			$("#donutchart8, #donutchart15, #donutchart22, #donutchart30, #donutchart37").donutchart({'size': 55, 'fgColor': '#202020', 'bgColor': '#f6f6f6' })
			$("#donutchart8, #donutchart15, #donutchart22, #donutchart30, #donutchart37").donutchart("animate")

		}
		
		var timeout;
		$(".nano").nanoScroller({ alwaysVisible: true });
		function refresh() {    
			clearTimeout(timeout);
			timeout = setTimeout(function(){
				$(".nano").nanoScroller();
			}, 200);
		}


		$(".posRel_close").hide();
		$(".Close-CaseStudies").hide();
		$(".caseStudy_scroll").hide();
		$(".tabs-cont").hide();
		$(".tabs-cont:eq(0)").show();

		
		$("ul.tabb li").click(function(){
			refresh();
			$("ul.number-click li").show();
			$(".showhidenum").hide();
			$(".Close-CaseStudies").hide();
			$(".posRel_close").hide();
			$("ul.tabb li a").removeClass("active");
			$(this).find('a').addClass("active");
			$(".tabs-cont").hide();
			$(".casestudy_tabs-cont").hide();
			$("ul.tab_casestudy li span").remove();
			$("ul.tab_casestudy li a").removeClass("active_casestudy");
			var TabClick = $(this).find("a").attr("href");
			$(TabClick).fadeIn(1000);

			var leftTabClick = $(this).find("a").attr("rel")
			$("#"+ leftTabClick).fadeIn(1000);

			overviewPage = $(TabClick + " .width85 div").attr("data-percent")
			init();
			return false;


		})
		$("ul.tabb li:eq(0)").trigger("click");

		$("ul.tabb li:gt(0)").click(function(){
			$(".firstchild").show();
		})
		
		
		
		$(".Close-CaseStudies").hide();
		$('a.Close-CaseStudies').click(function(){
			$(".posRel_close").show();
			$(".casestudy_tabs-cont").fadeOut();
			$(".Close-CaseStudies").fadeOut();
			$("ul.tab_casestudy li a").removeClass("active_casestudy ");
			//$(".downarrow").remove();
			$("ul.number-click li").show();
			$(".firstchild").show();
			refresh();
		})


		/* Case Study Year 1, Year 2 etc */
		$(".casestudy_tabs-cont").hide();
		function init_1() {
			$(".Close-CaseStudies").fadeIn(2000);
		}
		$("ul.tab_casestudy li").click(function(){
			refresh();
			$("ul.number-click li").hide();
			$(".posRel_close").show();
			$(".Close-CaseStudies").show();
			$(".caseStudy_scroll").show();
			init_1();
			$(".showhidenum").hide();
			$("ul.tab_casestudy li a").removeClass("active_casestudy ");
			$("ul.tab_casestudy li").removeClass("opened ");
			
			$("ul.tab_casestudy li span").remove();

			//$(this).append( "<span class='downarrow'></span>" );

			//alert($(this).append( "<span class='downarrow'></span>" ).is(":animated"));


			$(this).find('a').addClass("active_casestudy");
			$(".casestudy_tabs-cont").hide();
			$(".casestudy_tabs-cont").css('visibility','visible');
			var TabCaseStudy = $(this).find("a").attr("href");
			$(TabCaseStudy).show();
			return false;

		})



		/* Mapping Hover */

		$(".showhidenum").hide();
		$(".number-click li").mouseover(function () {
			refresh();
			$(".showhidenum").hide();
			
			$(".caseStudy_scroll").show();
			
			var office = $(this).find("a").attr("href");
			$(office).slideToggle();
		});
		$(".mouseoutover li").mouseout(function () {
			$(".showhidenum").hide();
		});
		/*$(".number-click li").mouseout(function () {
			refresh();
			$(".showhidenum").slideUp();
		});*/

		
		
		/* Left Navigation */
		var slideTimer=""
		$(document).ready(function(){
			$('.value-of-telstra td:odd').css({'background':'#FAFAFA', 'opacity':'0.9'});
			$('.value-of-telstra td:even').css({'background':'#DFE1E0', 'opacity':'0.9'});
			$('.width_D').css({'opacity':'0.8'});
			$('.caseStudy_back').css({'opacity':'0.9'});
			$('.casestudy_tabs-cont').css({'opacity':'0.9'});
			

			slideTimer = setInterval(function() {
				$('#man').slideDown(800);
			}, 1000);
			
		});


	})


