var app = angular.module('myApp', [ ]);
// FOR IMAGE WITH HEIGHT CALCULATION
app.directive('resize',function($window){
    return function (scope) {
        scope.width = ($window.innerWidth/20)-1;
        scope.imgMeilleurs = (($window.innerWidth/20)-1)*2;
        scope.imgVoeux2018 = (($window.innerWidth/20)-1);
        scope.logoTop = (($window.innerWidth/20)-1)*4;
        scope.imgManagingDirector = (($window.innerWidth/20)-1)*5;
        scope.img2018Logo = (($window.innerWidth/20)-.9)*9;
        scope.imgAchieveAmbitions = (($window.innerWidth/20)-.9)*10;
        //scope.height = $window.innerHeight;
        angular.element($window).bind('resize', function () {
            scope.$apply(function () {
            scope.width = ($window.innerWidth/20)-1;
            scope.imgMeilleurs = (($window.innerWidth/20)-1)*2;
            scope.imgVoeux2018 = (($window.innerWidth/20)-1);
            scope.logoTop = (($window.innerWidth/20)-1)*4;
            scope.imgManagingDirector = (($window.innerWidth/20)-1)*5;
            scope.img2018Logo = (($window.innerWidth/20)-.9)*9;
            scope.imgAchieveAmbitions = (($window.innerWidth/20)-.9)*10;
                //scope.height = $window.innerHeight;
            });
        });
    };
})

// FOR RANGE REPEAT
app.filter('range', function() {
  return function(input, total) {
    total = parseInt(total);
    for (var i=0; i<total; i++)
      input.push(i);
    return input;
  };
});

// FOR DATA BINDING
app.controller('profileImg',function($scope,$http, $sce, $timeout,$rootScope,$compile){
    $http.get('js/data.json').success(function(data) {
         $scope.profileInfo = data;
         console.log( $scope.profileInfo);
		
    });

  $scope.popVideo = function (id) {//alert(id);
      $scope.currentID = "//players.brightcove.net/1456962682001/default_default/index.html?videoId="+id+"&autoplay=true,loop=true";
      $scope.videoID = $sce.trustAsResourceUrl($scope.currentID);
    }
    
    $scope.random = function() {
       return Math.random();
    }
	$timeout(function(){
		//$scope.liPosition = [];
		$scope.liPosition = document.getElementsByClassName("image-box");
		/*$scope.liPosition[35]="<img ng-click='random()'  class='img-arrow' src='images/Arrow.jpg'/>";
		console.log('List item' + $scope.liPosition[35]);
*/
$scope.liPosition[35].innerHTML = "<img ng-click='random()'  class='img-arrow' src='images/Arrow.jpg'/>";
$compile($scope.liPosition[35] )($scope);
alert($scope.liPosition[35].innerHTML);
		
		

		//document.getElementsByClassName("image-box")[35].innerHTML ="<img ng-click='random()'  class='img-arrow' src='images/Arrow.jpg'/>";  
		/*$scope.liPosition[56].innerHTML="<img class='img-Meilleurs' src='images/Meilleurs.jpg'/>";  
		$scope.liPosition[24].innerHTML="<img class='img-Voeux_2018' src='images/Voeux_2018.jpg'/>"; 
		$scope.liPosition[90].innerHTML="<img class='img-jll-logo' src='images/jll-logo1.jpg'/>";    
		$scope.liPosition[114].innerHTML="<img class='img-managing-director' src='images/managing-director.jpg'/>";  
		$scope.liPosition[195].innerHTML="<img class='img-2018-logo' src='images/2018.jpg'/>";        
		$scope.liPosition[210].innerHTML="<img class='img-Achieve-Ambitions' src='images/Achieve-Ambitions.jpg'/>"; */
		
		/*$scope.myEl = angular.element( document.querySelector( '.image-box' ) );
		$scope.myEl[35].html("<img ng-click='random()'  class='img-arrow' src='images/Arrow.jpg'/>");
		 $scope.divHtmlVar= '<b>main html</b>';  */
	},100);
})
function getPos(e){
     x=e.clientX;
     y=e.clientY;
     cursor= x + " , " + y ;
     //console.log(cursor);
     if(x < 100){
         var i = 0;
         for(i=0; i<20; i++){
            document.getElementsByClassName("img-over")[i].style.top = "0";
         }
     }
     if(y < 100){
         var i = 20;
         for(i=0; i<20; i++){
            document.getElementsByClassName("img-over")[i].style.right = "0 !important";
         }
     }
}


