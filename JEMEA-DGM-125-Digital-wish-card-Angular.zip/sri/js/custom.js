$(window).on('load',function(){
    setTimeout(function() {
        $(".loading-bg").fadeOut();
        $(".image-box").click(function(){
            var vdID = $(this).attr("rel");
			//alert(vdID);
           /* $("#video_1").attr("data-video-id",vdID);
            $(".video-box video").attr("data-video-id",vdID);*/
            $(".popup-overlay").fadeIn();
            $(".video-box").slideDown('slow');
        })
        $(".popup-overlay").click(function(){
            $(".video-box").slideUp('slow',function(){
                $(".popup-overlay").fadeOut();
                $(".video-box video").attr("data-video-id",'')
            });
        });
    },1000);
});
